# Directory retirement batch independent review

Reviewed actual working diff in SecondaryDirectoryHandles.kt, SecondaryDirectoryRetirementTest.kt and SecondaryPreparedMoveTest.kt against recovered HEAD. Read only: no Gradle, source edits, commits or pushes. Parent reports focused execution in progress; this review does not assert its outcome or independently verify red-run evidence.

## Disposition

No concrete introduced production defect established in this narrow batch. Suitable to retain as a partial Task3B prerequisite subject to the parent's actual verification result. The candidate interruption abandonment and prepared-publication lifetime-monitor inversion identified earlier have been corrected in the inspected source.

* withPinned:25–34 and withDirectory:53–59 now hold a whole synchronous borrower scope around consumer work and final binding checks. Individual resource methods enter the same same-thread nested scope. Native operations execute after lifetimeGate exits.
* close:198–238 seals admission, rejects borrower self-close and same-thread Native close reentry, waits through interruption for admitted borrower return, invokes sibling closes after returned failures, retains the exact original failure and suppresses subsequent distinct failures. Duplicate close joins the original completion rather than retrying or manufacturing success. Interruption observed while waiting is restored after real cleanup; it is not treated as successful early completion.
* PreparedReplace.commit:174–181 checks original creating Thread, current same-thread outer borrow, live scope and one-shot use without acquiring lifetimeGate. atomicReplace prepared fast path:156–162 likewise adds no resource monitor under controller/authority gates. Same-thread outer scope protects Native handles until consumer action unwinds. Existing manual prepared-move test now supplies that scope while preserving the Native-only move assertion and one-shot checks.
* closingThread is cleared before completing closeResult, but Native close calls have all returned at that point. A competing duplicate can only wait on completion; it cannot acquire close ownership. Thus this ordering does not create a second release or false success.
* Using thread/counter reads in prepared commit are valid for the admitted same-thread owner: only that thread mutates them until its borrow exits, and closed is volatile. An incorrect other-thread caller is rejected by thread identity first. Concurrent closer cannot release handles while the outer borrow remains held.

## Qualifications and verification gaps

The new tests cover returned close failure, duplicate close pending actual return, closed cached access, close racing actual directory open, Native close self-reentry, interrupted first closer, multiple failure suppression, and direct prepared commit while lifetimeGate is held by another thread. These are meaningful behavioral regressions. Remaining useful narrow coverage:

1. Extend the blocked-lifetime-gate publication test to call pinned.atomicReplace(source,target), the actual DurableSecondaryIo route, in addition to the existing direct PreparedReplace.commit coverage. Current source fastpath inspection is sound, but this would catch accidental future reintroduction of a gate in the production wrapper.
2. Postclose denial currently tests cached open/writeNew/checkBindings, despite its name mentioning new access. Add open(late), syncDirectory/remove/mkdir/prepareAtomicReplace/atomicReplace denial with no Native calls/mutations. Prepared commit after closed is already checked in existing prepared-move test.
3. Hold the consumer's Native use after open returns inside an outer withAccess, and prove close waits until consumer finally returns. Existing held-open regression proves late acquisition return, not the whole consumer wrapper boundary. Also useful: borrower self-close rejection, concurrent borrower denial, and close after borrower action throws.

These are coverage improvements, not an established production defect requiring speculative source changes before checkpoint. Maintain the exact evidence distinction: inspected correctness, parent-observed test results, and still-unverified broader runtime behavior.

## Explicit remaining mandatory obligations

Whole-consumer borrow protection is not universal across all production PinnedDirectories users. MediaUsageStore directly constructs pinned scopes at699 and869, and uses raw returned streams at684/705/812/873. Existing media object/root serialization protects many such usages, but this patch does not establish a general raw-handle borrow guarantee for them. My earlier candidate statement that current consumers all use wrappers was too broad; this inspection corrects it. PinnedDirectories.open returns a raw stream after its individual nested scope exits, so only an outer scope or existing audited caller synchronization protects later use. Do not publish a universal Native borrow completion claim.

No original precreation physical child reservations, independently dispatched hung sibling closes, complete constructor/partial child ownership, or removal of root4 cleanup was implemented here. close remains synchronous and sequential; root-held callers can still block. A failed physical close stays failed; there is no retry success or cleanup reset. The unchanged maps retain references to closed wrapper objects while this PinnedDirectories object remains reachable; successful Native close is evidence of handle retirement, not a proof that every Java graph reference vanished.

All remaining B/C/D findings in resource-completion-review.md remain Task3B obligations, not Task3C deferrals. Fixed16, exact selected generation/identity, original attempt binding, and biometric fixed-denial stay binding. No AndroidX app-owned retirement exception is approved.

## Final source identity check

Re-read final tests and production identifiers after internal parent compatibility restoration. No new finding. parent remains scoped through withAccess; the visibility correction introduces no new cleanup or authorization bypass. Final tests now exercise both direct prepared commit and actual atomicReplace facade while lifetimeGate is held, and cover all closed Native method entry points. Prior coverage recommendations for those two items are satisfied by inspection.

| Source | SHA256 | Git blob identity |
| --- | --- | --- |
| SecondaryDirectoryHandles.kt | a5f7fa5e59680df863124a84c4a66eb36e610b313800941bd06adf109c2beb4d | 8d4543dd5ec27612f4f00614925878cdacc14946 |
| SecondaryDirectoryRetirementTest.kt | 669dc74db285c19dcab18ab8f277808e47fe0728c526810ff5f744d8569a6e3c | 2ea173ecab9dc5ac19af4ee2e2a3c5cbade0ca71 |
| SecondaryPreparedMoveTest.kt | 3ebc00783bc229428e2c7f49681bdfdc9e7187dccd313a489c86a01274512725 | b2b1131ed441ecd4f97a71d68ac898a9eb9e9312 |

Hashes computed directly from final working files with sha256sum and git hash-object. Parent reports actual focused runs37/37 then38/38 (including19 MediaUsageStore and10 OwnedPlaintext), four controlled races repeated10 times each (40passes), and Phase0 Android test Kotlin/Java compilation exit0. These execution results are parent-provided evidence, not commands rerun by this reviewer. The preserved earlier private-parent compile failure remains a real failed attempt. This final check changes neither the partial-only disposition nor any mandatory unresolved B/C/D obligation.
