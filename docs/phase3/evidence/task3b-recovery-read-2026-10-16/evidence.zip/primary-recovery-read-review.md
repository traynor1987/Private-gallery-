# Primary recovery metadata read independent review

Read-only review of working PrimaryKeySlots.kt readPrimaryRecoveryEnvelope and PrimaryRecoveryReadOwnershipTest.kt. No Gradle, repository edits or commits. Parent's active green run has not been independently observed here.

## Required narrow correction

The catch around original.terminalRetirement.await catches InterruptedException without restoring the current thread interrupt flag. CountDownLatch.await clears that flag when throwing. Restore it before rethrowing or suppressing retirement failure, matching the neighboring temporary-key retirement helper. This applies both when read succeeded and when an earlier provider failure is preserved with retirement failure suppressed.

Deterministic test without production hooks: execute helper on a dedicated Thread; inside the read callback set Thread.currentThread().interrupt() immediately before returning record. RetirementAcknowledgement.await delegates CountDownLatch.await, which checks interruption even when already counted down. Assert no returned record, InterruptedException, and true interrupt status in catch/finally; observe eventual authority cleanup from the noninterrupted test thread. Clear that worker flag only after capturing it if needed for test teardown. Repeat with provider throwing a known exception after setting interrupt: original provider exception remains primary, interrupted retirement is suppressed, status restored. No exact retirement-worker pause is needed to expose the missing flag restoration.

## Ownership/authorization assessment

No additional concrete production defect established for this narrow synchronous read:

* Initial authority-gate rejection and BACKUP scope check occur before provider invocation. createOwned reserves the original physical manifest before constructing PrimaryRecoveryReadInvocation or invoking read. Invocation attaches before the second scope/gate checks and provider entry.
* Scope check is original operation bound. The provider executes outside Primary authority gate. Revocation may race after its last check, but this is already admitted original factory work: it remains accounted, cannot admit late output, and must actually return.
* returned() executes in a finally covering provider invocation and its return/throw. The original release child exposes this actual-return future as supported acknowledgement. No prompt/cancel/native-internal retirement inference is introduced.
* createOwned construction completion and final original-operation check are distinct from the invocation acknowledgement. The helper retains the exact ReleaseReservation via its factory scope even when createOwned later rejects a stale result; finally releases that original and waits terminalRetirement plus !failed before successful return.
* Final operation.commit occurs separately after terminal retirement and carries only the encrypted RecoveryWrappedKey. It validates the original operation epoch and cannot substitute a replacement session. Encrypted record arrays are not plaintext key adoption.
* Provider failure is retained; mandatory retirement failure is suppressed rather than converted to success. Retirement timeout/failed release prevents final commit and does not free pending cleanup accounting. If owner.release itself throws, it can mask a prior provider exception and skip the explicit wait; underlying reservation infrastructure marks failed admission. This is undesirable error diagnostics but no success/authority escape established in this helper, and not a new cleanup-completion claim.

Tests inspect meaningful provider-entry denial, scope rejection, capacity16 saturation before acquisition, non-gated held provider/revocation, and original record identity after normal cleanup. A dedicated provider-exception cleanup test would further support the error path. Existing terminal acknowledgement machinery is relied upon; this review does not replace its independent tests with model assertions.

This fixes only an owned synchronous encrypted recovery-record read. It does not close remaining preference writes, queued work, pending setup/display keys, provider partial manifests, root4 IO or other mandatory Task3B B/C/D obligations. Production biometric denial and fixed16 remain unchanged.
