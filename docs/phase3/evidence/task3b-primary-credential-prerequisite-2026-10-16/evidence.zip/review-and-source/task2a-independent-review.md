# Independent Task2 batch A review — 2026-10-16

Reviewed frozen range `abb834abff8bfa8994ac4db646885309e0ab04fd..14307170d7f4909bf581c8d19c7b9eb7e2344935` in `/workspace/scratch/0881340dd615/private-gallery-task3-recovered`. This review performed no source edits, Gradle execution, test rerun, commit or push. The controller separately owns Android compilation.

## Verdict

**Changes required for batch A: one Important introduced lifecycle defect.** No Critical findings. No additional Minor findings requiring correction. A is substantially compliant with its deliberately restricted prerequisite scope, but its precommit partial-construction guarantee is not complete. This is not approval of Task2, an active global writer guard, full Task3B or device/owner acceptance.

## Important: revocation between rollback attachment and linking strands a known-unentered child

**Locations:** `app/src/main/java/uk/co/traynor/privategallery/core/security/PreparedPrimaryPinWrite.kt:60–62`, `:143–145`, `:117–123`, `:192`; current supported assembly is demonstrated in `app/src/test/java/uk/co/traynor/privategallery/core/security/PreparedPrimaryPinWriteTest.kt:26–46`.

`attachRollback` invokes `value.requireBinding(...)` before saving the rollback reference. Binding calls `original.requireNativeUse(1, this)`, which rejects a released original. The independently funded rollback has already been attached to that original before this call. An actual authority revoke between those two operations therefore causes linking to throw after child1 exists. Parent `invocationReturned()` observes `rollback == null`, clears/completes only the write child, and has no path to abandon child1. Child1's `closeAcknowledged()` only returns its never-completed `done`; original release and end-of-construction cannot invent that acknowledgment. No editor or commit need have been entered, yet this original remains pending and physically charged indefinitely, blocking subsequent authentication.

Deterministic source-supported sequence (no test was run by this reviewer): fund two children; attach write; attach rollback; revoke the same authority; call `write.attachRollback(rollback)`; catch its rejection and run the currently documented/tested `write.invocationReturned()` and original release. `ReleaseReservation.attach` deliberately permits attaching an already acquired child during construction after revoke, while `requireNativeUse` rejects released originals; this makes the failure window real, including revocation immediately before child1 attachment. This is not a missing future caller migration: the new assembly API and its current test helper already have the broken partial-construction path.

**Required correction:** provide exact-original, known-unentered rollback abort/ownership linkage on attachment failure so every acquired child can retire normally. Preserve identity/membership checks, revocation denial, separately prefunded rollback, real terminal ACK and sticky entered-provider failures. Add a deterministic regression placing revoke between attachment and link, asserting zero editor/commit acquisition, both physical children positively retire, and a valid independent attempt is subsequently admissible. Do not repair it by dropping a pool, skipping cleanup, forcing an ACK or weakening `requireNativeUse`. Controller notified; fix round pending.

## Scope and positive findings

- The registry retains the exact original's `terminalRetirement`, not the earlier completion stage. Replacement requires explicit durable decision, no ambiguity, and that exact success-only terminal marker (`PrimaryCredentialMutation.kt:13–39`). Inspection of `ReleaseReservation`, `ReleaseTicket`, `ReleaseRetirementGroup` and `RetirementAcknowledgement` confirms this observes actual release-wrapper return and physical slot return. Registry mutation performs only bounded metadata/CAS work, installs no client callback, and waits on nothing.
- Production command creation is hardwired to the singleton. `PreparedPrimaryPinWrite` has a private constructor; synthetic tests reflect into that constructor or the private biometric implementation. Fixtures create genuinely fresh process registries and fresh16 authority pools before any open/operation/original acquisition. I found no clearing of failed state, production singleton reset, ACK override, live-pool substitution or dropped failed ownership in this range.
- Typed command admission checks exact operation/epoch/CREDENTIALS scope, original registry membership, IO partition, original child identity, failed/retiring state, and both pools' mandatory retirement barriers. Direct metadata admission verifies the actual authority gate. The prepared editor is not exposed or replaceable after admission; admission/execution are once-only and bound to the constructing thread. Editor preparation/commit and cleanup occur outside authority/storage/preference gates in the supported command path. Revoke before admission denies; an already admitted synchronous commit can finish but grants no session authority.
- Restore separately reserves/attaches child1 before either editor. Once correctly linked, that child retains the same claim beyond write-child return and requested original release until explicit durable success or exact-record rollback. Mismatching state is preserved; rollback is once-only and can operate as cleanup after revoke. Successful rollback cannot clear an earlier ambiguous original. The partial-link race above is the exception to otherwise sound partial preparation handling.
- Entered false/throw sets sticky mutation ambiguity and completes the write receipt exceptionally. The existing already-owned biometric helper also retains its slot quarantine and fails its original receipt; it propagates failure rather than waiting for an impossible successful terminal marker. A later fake disk-worker return cannot release that failed original. Preparation-only failures otherwise retire normally. No SharedPreferences exception has been invented.
- The actual diff changes only the eight reported production/test files. Existing BIO preparation-failure coverage is retained; entered-failure and false-return cases are strengthened to require failed accounting rather than weakened or removed. Fixed capacity, algorithm/format code, biometric availability gate and the sole Android-internal Keystore exception are unchanged. No source changes to Main, restore repository, protected branch/PR59, or security-negative policy were present.

## Evidence independently inspected

Read the task-2a brief, complete task-2 report, saved review diff, prepared-PIN design report, relevant phase0 authority/security and phase3 lock/capacity contracts, all eight changed source/test files, supporting real reservation/release/authority machinery, and `/root/.cache/private-gallery-task3b/sharedpreferences-commit-retirement-review.md`. Also inspected cached Android14 commit implementation: it enqueues before private-latch await and returns false on interruption without cancellation, supporting the failed-original policy. The older design's reconciliation wording is superseded by the explicit newer batch brief/provider review, and final code uses sticky quarantine.

Parsed actual saved JUnit XML rather than relying on reported counts:

| Saved run | Actual tests/failures/errors/skips | Interpretation |
| --- | --- | --- |
| task2-a-02-terminal-behavior-red | 4/1/0/0 | Genuine held ReleaseInvocation return denial failed. |
| task2-a-06-admission-behavior-red | 21/1/0/0 | Genuine direct unauthorized metadata admission failed. |
| task2-a-08-provider-behavior-red | 25/6/0/0 | Genuine failed-charge, persistent ambiguity and reentrant lifecycle failures. |
| task2-a-10-biometric-provider-behavior-red | 14/2/0/0 | Genuine false/throw normal-retirement defect; XML surfaces teardown's charged-fixture assertion, as report discloses. |
| task2-a-11-focused-green | 68/0/0/0 | Prepared22, mutation5, BIO14, authority14, recovery13. Log says BUILD SUCCESSFUL, 1m34s. |
| task2-a-12-critical-repeat-green | 9/0/0/0 | Prepared6, mutation1, BIO2. Log says BUILD SUCCESSFUL, 1m52s. |

Missing-symbol compile failures and the run09 JUnit initialization failure are not accepted as behavioral RED. Earlier superseded cleanup assumptions are not accepted as final evidence. The saved final suite contains meaningful real authority/reservation and controlled blocking-boundary tests; however, it does not cover the rollback attach/link revocation boundary above. No claim of exhaustive stress, full Android behavior or device acceptance follows from those tests.

## Mandatory later work, not additional introduced A findings

B/C/D remain mandatory: complete producer/provider/input/result/worker census and fixed16 phasing; exact original-attempt/generation admission; coherent migration of every setup/change/recovery/restore/rollback and conflicting biometric/recovery-slot writer; removal of arbitrary callbacks/default bypasses; restore original worker/input/stage/result/final handoff and replacement transaction exclusion before altering root serialization; Android fixture adaptation and focused behavioral acceptance. In particular the legacy `withPrimaryBiometricRecoveryDisable` failure accounting and global recovery check-to-write gap remain open and are accurately disclosed in the report. The new command core does not yet protect those production writers.

Biometrics remain disabled. Main/PR59 and the Keystore-only exception remain outside this batch. After the Important issue is corrected, inspect the new range and actual deterministic RED/GREEN evidence before accepting the A checkpoint; do not silently reuse this report as a pass for another HEAD.
