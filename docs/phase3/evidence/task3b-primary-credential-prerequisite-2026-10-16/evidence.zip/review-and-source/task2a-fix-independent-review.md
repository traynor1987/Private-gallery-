# Independent Task2 batch A fix review — round 1

Prior review remains unchanged at `/root/.cache/private-gallery-task3b/task2a-independent-review.md`.

## Final bounded review status

**Accept batch A as a bounded prerequisite checkpoint at `61189d15774483edec57b63976dab42396097071`, tree `6c16139114ae75fbe8fd1e7b536853307bfb0c6b`.** The one Important finding is fixed and behaviorally verified. No remaining Critical, Important or Minor findings requiring correction were identified within the authorized A scope. Full Task2, B/C/D, the active global writer guard and full Task3B remain OPEN.

Read-only inspection covered the final three-file fix diff against `14307170d7f4909bf581c8d19c7b9eb7e2344935` (41 insertions, one deletion), the final complete nine-file range from `abb834abff8bfa8994ac4db646885309e0ab04fd`, updated implementation report and saved evidence. The final fix matches the previously inspected frozen working diff. Verified exact HEAD/tree and clean working tree. All nine current file SHA256 values match `/root/.cache/private-gallery-task3b/task2-a-review-fix-final-source-sha256.json`. The saved `review-abb834a..61189d1.diff` exactly matches `git diff -U10 abb834a 61189d1` after removing its package header. No source edits, tests, Gradle execution, commits or pushes by this reviewer.

## Source assessment

`ReleaseReservation.requirePreparedPinRollbackCleanupLink` is a narrow typed bounded metadata check. It verifies the exact operation-owned tickets, child1 association in `actualIdentities`, current constructor thread, claimed state, and absence of phase sealing or an in-progress factory. It performs no callback, acquisition, cleanup, ACK mutation or admission, and intentionally allows the original to have been released solely for linking an already-acquired child for cleanup.

`PreparedPrimaryPinRollback.requireBinding` still checks its same operation/original, then uses that exact metadata check. `PreparedPrimaryPinWrite.attachRollback` retains the verified child before calling the original unchanged `requireNativeUse(1,value)`. Thus revoke still rejects live use; parent `invocationReturned()` now has the acquired rollback reference and can run known-unentered abandonment. The fix does not weaken registration, Native-use/revocation checks, failed accounting, terminal ACK, process pool state or sticky ambiguity.

No Critical, Important or Minor new findings in the final inspected diff. The previous Important finding is closed by the exact-source correction and actual RED13/GREEN14 evidence.

## Regression assessment

The new `revokeBetweenRollbackAttachmentAndLinkRetiresBothKnownUnenteredChildren` deterministically exercises revoke both before and after child1 attachment. It explicitly requires `attachRollback` to reject live use, then checks original successful terminal retirement, zero physical occupancy, and successful reopening/new credential operation. It does not reset a failed original or synthesize an ACK.

Read actual `task2-a-13-rollback-link-red-xml/TEST-uk.co.traynor.privategallery.core.security.PreparedPrimaryPinWriteTest.xml`: **1 test, 1 failure, 0 errors, 0 skips**, failure message `both acquired unentered children must retire`, at the new regression's retirement assertion. Log reports BUILD FAILED in49s. This is a genuine behavioral RED reproducing the reviewed lifecycle gap. Other previously copied class XML is segregated under `stale-previous-run` and is not counted as this execution.

Parsed all six actual saved `task2-a-14-review-fix-focused-green-xml/` files: **72 tests, 0 failures, 0 errors, 0 skips**. Every file has this execution's timestamp (2026-10-16T21:39:55–56). Counts are PreparedPrimaryPinWrite23, PrimaryCredentialMutation5, PrimaryBiometricPreferenceWrite14, PrimarySessionAuthority14, PrimaryRecoveryAuthentication13, OriginalTerminalRetirement3. The new `revokeBetweenRollbackAttachmentAndLinkRetiresBothKnownUnenteredChildren` testcase is present and passing; its source executes both revoke timings. The log reports BUILD SUCCESSFUL in1m45s. The nonexistent `OriginalFactoryTest` selector contributes no coverage and is not counted.

Also inspected the separate direct JUnitCore runner script and saved log for the actual `OwnedFactoryScopeTest`: `OK (5 tests)`. This evidence is additional to, not part of, the72 XML tests. Saved SDK-configured source/security log reports25 tests, OK; saved no-secret log reports PASS. These executions were inspected, not rerun by this reviewer.

The acceptance is for the completed A prerequisite core plus the narrow existing BIO failed-provider correction, with the prior review's positive findings and explicit limits retained. It is not acceptance of production PIN writer migration, general recovery callback accounting, provider/secret census, restore worker/input/stage/result ownership, or full-route fixed16 fit. Those are mandatory B/C/D work. Biometrics remain disabled; capacity, cryptographic formats, the sole Keystore exception and protected Main/PR59 scope remain unchanged.

Final-HEAD Android compilation is being handled separately by the controller; this report does not substitute the earlier1430717 Android compiles for final61189d1 evidence. No device/owner acceptance or full Task3B conclusion follows from this review.
