# SharedPreferences commit: persistence versus retirement

Read-only official-source investigation, 2026-10-16. No app edits, Gradle or tests. Raw official source copies are cached beside this report. No SharedPreferences/platform exception is requested; the approved exception remains Android-internal Keystore only.

## Sources and reproducible locations

1. Pinned Android 14: https://android.googlesource.com/platform/frameworks/base/+/android-14.0.0_r1/core/java/android/app/SharedPreferencesImpl.java
   Raw: same URL plus `?format=TEXT` (base64). Cached as `sharedpreferences-android14.java`.
2. Current AOSP main resolved during review to commit `1cdfff555f4a21f71ccc978290e2e212e2f8b168`:
   https://android.googlesource.com/platform/frameworks/base/+/1cdfff555f4a21f71ccc978290e2e212e2f8b168/core/java/android/app/SharedPreferencesImpl.java
   Cached as `sharedpreferences-main.java`; byte-for-byte equality between fetched main and this exact commit verified. SHA256: `a1daeb52d3211428131f08ae236709059b3c46ab8d050a59d09a935e5ca6f8cd`.
3. Public Editor API: https://developer.android.com/reference/android/content/SharedPreferences.Editor#commit()
4. Public SharedPreferences API: https://developer.android.com/reference/android/content/SharedPreferences

Line numbers below are actual decoded Java source lines, not web-renderer offsets. The Android14 HTML fetch failed in the search renderer, but the official raw TEXT endpoint succeeded and was inspected locally.

## Exact source facts

**Android14:** commit, lines595–618, changes memory, schedules disk work, then awaits its private latch. InterruptedException returns false without cancelling the queued write; that catch does not restore interruption. Therefore checking the caller's interrupt flag afterward cannot disambiguate false. enqueueDiskWrite,664–696, executes directly only when its in-flight test permits; otherwise it queues. setDiskWriteResult,398–402, signals the latch. False paths include both interrupted waiting and reported IO failure; they are not distinguishable through the boolean. The failure cleanup at863–875 attempts deleting a partial file but cannot prove every false means successful cleanup.

**Pinned current main:** the same interruption/scheduling behavior appears at603–626 and672–704. Successful writing performs sync/stream close and file bookkeeping before signaling success at849. After signaling,855–879 contains timing/logging work and method return; the outer runnable subsequently decrements mDiskWritesInFlight at683. Consequently a queued commit can return true before that runnable's trailing framework bookkeeping finishes. This inspected normal-success suffix has no remaining preference-file write; it is not evidence that the caller's app invocation already returned. Listener notification at629–654 can post a Main callback when listeners exist. An exception can arise after persistence, so a thrown commit is not a reliable no-write observation either.

**Public contract:** Editor.commit's documented true result establishes successful persistent storage, not a general provider shutdown receipt. SharedPreferences documentation warns that false can occur despite successful writing. Neither public interface exposes this operation's disk latch or runnable-return acknowledgement.

## Concrete counterexample

An earlier preference write is in flight. Our editor updates the in-memory map and queues its write. Our waiting caller is interrupted and returns false while that queued write remains pending. Dropping the editor reference and completing the app's invocation receipt cannot cancel that queued operation. The later disk write may still occur. This is an actual source-supported failure case, not a hypothetical GC concern.

## Required narrow accounting change

- Before commit entry: a known rejected/unentered command can retire its unused prepared app references normally. Do not label it an ambiguous entered write.
- Entered commit returning false or throwing: retain sticky credential ambiguity quarantine AND fail the exact original's cleanup acknowledgement. Its physical charge must remain failed/unavailable; do not complete the receipt successfully merely because the Java call returned. Clear releasable app references after actual return without claiming provider quiescence. Report failure; no retry, compensating write, replacement instance, readback or timeout may silently reset this state.
- Commit returning true: use the public persistent-write acknowledgement together with the separate actual app invocation return/reference cleanup. Describe these exact guarantees. Do not claim framework queue exhaustion, callback quiescence, universal OEM execution behavior or native memory destruction. Trailing inspected framework bookkeeping alone does not justify inventing a new app resource or backend rewrite.
- Never introduce apply as an alternative; the prepared command supports synchronous commit only.

No production preference-listener registration was found by searching app/src/main/java during this review. Keep credential preferences free of app listeners in this supported path. If listeners are introduced, any queued app callback must have its own original lifecycle/return accounting; commit true cannot stand in for that.

Suggested regression: a fake Editor returns false while controlled disk work remains held. Assert actual caller return does not recycle the original, quarantine prevents competing/replacement admission, and releasing fake disk work does not automatically convert the failed original into success. Also cover thrown entered commit and distinguish preparation failure before commit entry. These are proposed tests; none were run here.

## Correction to prior review scope

Earlier narrow reviews treated a returned failed preference call as sufficient to retire the invocation normally. That is valid only for app-call return, not for all pending provider work. The source-supported interrupted queued-write path invalidates that broader inference. The required failed-original charge preserves the owner's no-new-exception rule without presuming a backend rewrite or platform impossibility. It deliberately sacrifices further in-process admission after ambiguous failure instead of asserting unsupported completion.
