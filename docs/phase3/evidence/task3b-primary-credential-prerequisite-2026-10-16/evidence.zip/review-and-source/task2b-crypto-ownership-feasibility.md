# Task2B crypto ownership feasibility — source investigation

Read-only inspection of app PinEnvelope.kt, RecoveryEnvelope.kt, PIN/recovery store call paths, pinned Bouncy Castle1.79 and official Android14 provider/API sources. No implementation, Gradle, tests or device executions. The app declares bcprov-jdk18on:1.79 and minSdk26. Cache: `crypto-provider-source/` beside this report; sources.txt records raw retrieval URLs. Algorithms/parameters/formats remain AES/GCM/NoPadding,128-bit tag,16-byte salt,12-byte nonce,32-byte VDEK,SCrypt N32768/r8/p1/output32.

## Conclusion

A narrow supported adapter can remove the app-created, non-wipeable SecretKeySpec key clone without hand-writing crypto: use a private RAW/AES SecretKey backed by the exact original-owned wrapping-key buffer, retain its borrower through the entire init/doFinal sequence, seal all new use on revoke, and wipe only after actual synchronous return. Pinned Android14 Conscrypt directly retains the returned getEncoded array; it does not clone that array in checkAndSetEncodedKey. This is actionable standard-interface integration, not a new Keystore exception.

Source inspection does NOT establish that arbitrary default-provider/OEM implementations have identical internal storage or cleanup. It establishes no active asynchronous operation surviving the inspected AES-GCM/RAND/SCrypt return paths. The implementation must retain that precise supported-provider qualification and prove app lifecycle/output ownership. Do not claim full provider memory destruction, and do not mistake passive inaccessible internal copies for demonstrated active pending Native work.

## Sources and precise facts

### BC1.79 SCrypt

https://github.com/bcgit/bc-java/blob/r1rv79/core/src/main/java/org/bouncycastle/crypto/generators/SCrypt.java

Cached SCrypt-1.79.java: generate37–72 calls the synchronous implementation; MFcrypt75–114 uses temporary byte/int arrays and clears them in finally; SMix124–177 clears its chunk/work arrays in finally. The comment at101 mentions possible parallelization; this version does not launch threads. PBKDF2 helper116–121 returns a KeyParameter's key bytes. The returned32-byte output becomes an app result and must be immediately attached to its pre-funded original; P/S caller arrays remain caller obligations. Internal SMix chunks are provider-local implementation work, not hundreds of independent app close handles. The largest table is approximately32MiB for the fixed parameters; do not confuse fixed release-child count with heap footprint or claim all digest/HMAC internal state is zeroized.

### Android14 key and IV specifications

https://android.googlesource.com/platform/libcore/+/android-14.0.0_r1/ojluni/src/main/java/javax/crypto/spec/SecretKeySpec.java
https://android.googlesource.com/platform/libcore/+/android-14.0.0_r1/ojluni/src/main/java/javax/security/auth/Destroyable.java
https://android.googlesource.com/platform/libcore/+/android-14.0.0_r1/ojluni/src/main/java/javax/crypto/spec/GCMParameterSpec.java

SecretKeySpec-a14.java98 clones the supplied key; getEncoded183–184 clones again. This class has no destroy override. Destroyable-a14.java58–59's default destroy throws; isDestroyed defaults false. Thus calling inherited destroy is not supported successful clearing of this app-created sensitive clone. GCMParameterSpec-a14.java127 copies the IV,146–147 returns another clone; it has no destruction API. The IV is public nonce material, not a wrapping key. Keep its exact app lifetime bounded, but do not describe dropping its reference as wiping its private byte array.

### Android14 Conscrypt AES-GCM and entropy

https://android.googlesource.com/platform/external/conscrypt/+/android-14.0.0_r1/common/src/main/java/org/conscrypt/OpenSSLCipher.java
https://android.googlesource.com/platform/external/conscrypt/+/android-14.0.0_r1/common/src/main/java/org/conscrypt/OpenSSLAeadCipher.java
https://android.googlesource.com/platform/external/conscrypt/+/android-14.0.0_r1/common/src/jni/main/cpp/conscrypt/native_crypto.cc
https://android.googlesource.com/platform/external/conscrypt/+/android-14.0.0_r1/common/src/main/java/org/conscrypt/OpenSSLRandom.java
https://android.googlesource.com/platform/external/boringssl/+/android-14.0.0_r1/src/include/openssl/aead.h

OpenSSLCipher-a14.java461–480 accepts SecretKey and retains its exact encoded array. OpenSSLAeadCipher54,203 retains previousKey;128–140 resets counts without promising buffer wipe;354–377 invokes JNI and resets on successful return. NativeCrypto-a14.cc3575–3630 constructs a local ScopedEVP_AEAD_CTX, uses it synchronously and unwinds it; aead-a14.h469–471 binds that RAII wrapper to EVP_AEAD_CTX_cleanup. The evpAead field denotes an algorithm descriptor, not a persisted per-message Native context. No async queue/worker appears in this inspected path. Bad-tag/error exits still unwind the local scoped context; Java retained state need not be reset or wiped.

OpenSSLRandom-a14.java38–40 calls RAND_bytes synchronously. NativeCrypto4047–4064 uses a scoped output borrow, calls RAND_bytes and returns. The provider has no per-instance exported app close handle in this implementation. Its global entropy machinery is not an app-owned pending request or a reason to allocate extra emergency workers. A held entropy call still pins the original output and invocation until real return.

### Public APIs

https://developer.android.com/reference/java/security/Key#getEncoded()
https://developer.android.com/reference/javax/crypto/SecretKey
https://developer.android.com/reference/javax/crypto/Cipher
https://developer.android.com/reference/javax/security/auth/Destroyable

Key/SecretKey define encoded bytes and RAW format; they do not require a defensive clone on every getEncoded call. Cipher supplies caller-output doFinal overloads. doFinal is not destroy: its API describes reuse/reset, and Cipher has no close/destroy API. A private borrowing adapter must not be offered as a general-purpose reusable public key.

## Concrete private SecretKey alternative

Use a purpose-specific internal adapter owned by the same original as the funded32-byte wrapping output. Algorithm AES, format RAW, no encoding allocation. getEncoded returns that exact array only during a trusted synchronous provider-use borrow on the admitted invocation thread. Neither adapter nor Cipher escapes; no general callback receives them; no serialization/export/key caching. Repeated legitimate provider reads during that borrow return the same bytes, not unbounded clones.

The borrow spans Cipher acquisition/init AND doFinal, not merely getEncoded/init: Conscrypt retains the array for later seal/open. Revocation seals fresh entry but cannot zero the backing key while those methods are executing. After init/doFinal actually returns or throws, retire the provider facade, clear app references, then finish the key borrow and wipe the backing array. Pinned encodedKey/previousKey aliases are thereby also zeroed. Destroyable.destroy must only report success after actual wipe; it must not return success while an active borrower still exists. Use the existing asynchronous original acknowledgement to defer cleanup rather than pretending synchronous destroy completed.

An alternative custom SecretKey that returns fresh arrays recreates the ownership problem unless every returned copy was separately pre-funded/tracked and wiped. A noncopying bounded adapter is the simpler narrow candidate. No reflection into provider fields, reinitialization-as-wipe, forced GC, custom AES, provider reset-as-destruction or Android-internal exception.

This adapter eliminates the explicit SecretKeySpec clone. It does not erase Conscrypt's private message buffers or a different provider's private copies. That is a residual provider-memory statement, not evidence that an active operation remains executing. If the required acceptance claim demands positive destruction of every private provider byte, this standard API cannot establish that claim; do not quietly reinterpret it. The existing contract already disclaims universal Native-copy zeroization. Active app borrow completion must still be demonstrated independently.

## Exact app-owned inventory and phase plan

| Actual app object/copy | Size/count | Ownership action |
|---|---|---|
| Caller PIN/recovery secret | one char array | Existing input original; wipe after last actual consumer, including rejected entry. |
| New PIN for recovery/change | one char array | Independent existing new-PIN/input original. |
| Recovery normalization | one mutable char buffer, bounded by input | Replace concat/filter String pipeline with compatible mutable transformation; preserve whitespace/Unicode behavior. |
| PIN ASCII / recovery UTF8 input | one byte array per KDF invocation | Reserve before encoding. Avoid immutable plaintext strings; retain through SCrypt return then wipe. |
| Decoded encrypted envelope | salt16 + nonce12 + ciphertext48 | Three exact input arrays, each preowned before decode; can retire after unwrap. |
| SCrypt output |32 bytes | Fund before invocation; immediately attach returned output; borrow into private key adapter; wipe after Cipher actual return. |
| VDEK input/result |32 bytes | Existing owned result/temporary key; immediate bind before another operation. Never raw finally-only ownership. |
| New encrypted envelope | salt16 + nonce12 + ciphertext48 | Own before generation/output use; caller-output doFinal writes exact48 bytes. |
| Decrypted result |32 bytes | Caller-output doFinal to an already owned exact32-byte destination; clear on all failed/authentication-tag paths. |
| Entropy facade |1 active invocation | Preowned before SecureRandom acquisition/call; use one sequential provider, retain outputs through return. |
| Cipher/key-adapter/parameter facade |1 fixed synchronous use lifetime | Reserve before construction, attach partial references immediately, no independent worker/close dependency hidden inside it. Underlying key/output/input buffers retain their own children. |
| Outer worker / exact persistence / rollback |existing separate obligations | Not included by crypto receipt; must fit concurrent phase peak. |

A fixed provider facade can hold bounded passive spec/adapter references without pretending they are independently blocking closeable handles. Its positive acknowledgement is sealed app ingress + actual active-use return + clearing controllable app references, backed by inspected synchronous provider behavior; it is not a Native destroy acknowledgement.

Proposed recovery unwrap phase: existing result/invocation/secret(3), newPIN(1), normalized chars(1), encoded secret(1), decoded envelope(3), wrapping key(1), provider facade(1) =11. The result destination is the existing result cell, not another copied key. Retire normalized/encoding/decoded/wrapping/provider resources before replacement-PIN preparation. Preparation then needs existing authentication/input ownership(4), PIN bytes(1), wrapping output(1), salt/nonce/ciphertext(3), provider facade(1), entropy facade(1) =11 before phasing. Add at most the concretely supported worker/persistence/rollback entries; verify real route peak <=16 before acquisition. This is a proposed typed implementation census, not proof current constructors already obey it.

Do not retain both old-envelope decode state and all new preparation/provider buffers across phases. Reserve each complete phase before constructing any children; actual terminal retirement precedes quota reuse. If an active SCrypt/Cipher/random call stalls, keep its invocation and inputs charged; cancellation is not its return. Physical failure retains the original; no fresh auth/result handoff can bypass it.

## Specific current-code changes needed before claiming B

PinEnvelope.create allocates salt/nonce before its protected try and creates two separate SecureRandom instances. derive allocates PIN bytes and SCrypt result without original attachment. cipher creates anonymous SecretKeySpec/GCMParameterSpec/Cipher references; doFinal allocates its output. Add narrow owner-aware preparation/unwrap entrypoints using the adapter and caller-owned outputs, while keeping legacy vectors/encodings unchanged. Retire all actual partial acquisitions on init/final failure.

RecoveryKey.normalise/RecoveryEnvelope.derive currently create immutable strings containing the recovery secret; RecoveryKey.generate also creates an unowned random32-byte input and immutable Base64 string. Replace these app-created secret copies with owned mutable encoding/normalization for paths in scope. Generation/display remains a distinct lifetime path; do not claim it fixed by migrating unwrap alone.

Retain exact original authority checks before fresh use and separate final admission after cleanup. The typed result must own recovered bytes before preparation of another PIN envelope starts. No generic free key/cipher supplier or no-op provider disposer closes that proof.

## Evidence limits / next acceptance checks

This investigation supports the noncopying SecretKey candidate on the inspected Android14 Conscrypt path and BC1.79 synchronous KDF. It is not a device/provider matrix result. Verify actual default provider identity on supported Android configurations, public-interface compatibility, unchanged crypto vectors, wrong-tag wiping, init failure, revoke while each real invocation is held, no new use after seal, actual callback-return accounting and complete fixed16 peak. A provider exposing an independently active handle would require its real supported retirement, not this source inference. No such outstanding active handle was demonstrated in the inspected specific GCM/RAND/SCrypt paths.
