package uk.co.traynor.privategallery.core.security

/** Original, bounded child manifest; no authority is granted by reservation alone. */
internal class ReleaseReservation(
    private val tickets: List<ReleaseTicket>,
    private val allocateArrayRelease: (Any?) -> CopiedArrayRelease = ::CopiedArrayRelease,
    private val copyArray: (ByteArray) -> ByteArray = { it.copyOf() },
) {
    private val retirementPool = tickets.first().retirementPool
    init { require(tickets.all { it.retirementPool === retirementPool }) }
    private val gate = Any()
    val retirement = RetirementAcknowledgement()
    val terminalRetirement = RetirementAcknowledgement()
    private val claimed = BooleanArray(tickets.size)
    private val phaseSealed = BooleanArray(tickets.size)
    // Keep original identity associations after physical phase slots are returned.
    private val actualIdentities = arrayOfNulls<Any>(tickets.size)
    private val factoryInProgress = BooleanArray(tickets.size)
    private val jobAdapters = arrayOfNulls<ReservedJobRelease>(tickets.size)
    private val nativeAdapters = arrayOfNulls<ReservedValue<*>>(tickets.size)
    private val mainAdapters = arrayOfNulls<OriginalMainValue<*>>(tickets.size)
    private var constructorThread: Thread? = null
    private var constructionAdmitted = false
    private val retirementNotified = java.util.concurrent.atomic.AtomicBoolean(false)
    @Volatile private var strictAccounting = false
    @Volatile private var released = false
    val retiring: Boolean get() = released
    internal fun belongsToPool(pool: ReleasePool): Boolean = retirementPool === pool
    val failed: Boolean get() = tickets.any { it.failed }
    val successful: Boolean get() = tickets.all { it.successful } && (!strictAccounting || retirement.isComplete)
    fun <T> construct(factory: ReleaseReservation.() -> T): T {
        // Repeated/reentrant rejection is not a failure of the original admitted constructor.
        synchronized(gate) {
            check(!released && !constructionAdmitted) { "Original factory reservation unavailable" }
            constructionAdmitted = true
            constructorThread = Thread.currentThread()
        }
        var begun = 0
        try {
            // Pin ALL unused entries too: revoke cannot recycle a constructing factory's budget.
            while (begun < tickets.size) { tickets[begun].beginConstruction(); begun++ }
            val result = factory()
            check(!released) { "Original factory reservation revoked" }
            return result
        } catch (failure: Throwable) {
            release()
            throw failure
        } finally {
            synchronized(gate) { constructorThread = null }
            var index = 0
            while (index < begun) { tickets[index].endConstruction(); index++ }
        }
    }
    private fun hasIdentity(index: Int, value: Any): Boolean =
        actualIdentities[index] === value || nativeAdapters[index] === value || mainAdapters[index] === value ||
            jobAdapters[index] === value || tickets[index].ownsActual(value)

    fun <T : AutoCloseable> attach(index: Int, child: T): T = synchronized(gate) {
        var other = 0
        while (other < tickets.size) {
            check(!hasIdentity(other, child)) { "Actual resource already has its original token" }
            other++
        }
        check(!claimed[index]) { "Original child already claimed" }
        tickets[index].attachReserved(child)
        actualIdentities[index] = child
        claimed[index] = true
        child
    }
    internal fun <T : Any> createValue(index: Int, dispose: (T) -> Unit, factory: () -> T): ReservedValue<T> {
        val release = ReservedValue(dispose)
        synchronized(gate) {
            check(!released && constructorThread === Thread.currentThread()) { "Original native factory unavailable" }
            check(!claimed[index]) { "Original child already claimed" }
            tickets[index].requireAttachmentAdmission()
            claimed[index] = true
            nativeAdapters[index] = release
            factoryInProgress[index] = true
        }
        // Until an actual child exists the original constructing ticket stays pending,
        // with its physical worker idle. No release callback waits for construction.
        try {
            val actual = factory()
            bindValue(index, release, actual)
            return release
        } finally { synchronized(gate) { factoryInProgress[index] = false } }
    }
    /** Fixed Main root: private acknowledgement exists and attaches before Native allocation. */
    internal fun <T : Any> createMainValue(guard: ScopedIoGuard, post: (Runnable) -> Boolean,
        isMain: () -> Boolean, dispose: (T) -> Unit, factory: () -> T): OriginalMainValue<T> {
        guard.requirePresentationOriginal(this)
        val release = OriginalMainValue(guard, this, post, isMain, dispose)
        synchronized(gate) {
            check(tickets.size == 1 && !released && constructorThread === Thread.currentThread()) { "Original Main factory unavailable" }
            check(!claimed[0]) { "Original child already claimed" }
            tickets[0].requireAttachmentAdmission()
            claimed[0] = true
            mainAdapters[0] = release
            factoryInProgress[0] = true
            tickets[0].attachReserved(release)
        }
        var entered = false
        try {
            guard.requireMainNativeConstruction(this, release)
            check(isMain()) { "Original Native construction requires Main" }
            entered = true
            val value = factory()
            synchronized(gate) {
                check(mainAdapters[0] === release && actualIdentities[0] == null) { "Original Main adapter unavailable" }
                actualIdentities[0] = value
                release.bind(value)
            }
            release.finishFactory()
            return release
        } catch (problem: Throwable) {
            release.failFactory(problem, entered)
            throw problem
        } finally { synchronized(gate) { factoryInProgress[0] = false } }
    }
    internal fun requireMainNativeConstruction(owner: Any, cell: OriginalMainValue<*>) = synchronized(gate) {
        check(tickets.size == 1 && tickets[0].belongsTo(owner) && !released &&
            constructorThread === Thread.currentThread() && claimed[0] && mainAdapters[0] === cell &&
            actualIdentities[0] == null && factoryInProgress[0]) { "Original Main construction unavailable" }
    }
    internal fun requireMainNativeUse(owner: Any, cell: OriginalMainValue<*>, actual: Any) = synchronized(gate) {
        check(tickets.size == 1 && tickets[0].belongsTo(owner) && !released && !phaseSealed[0] &&
            !factoryInProgress[0] && mainAdapters[0] === cell && actualIdentities[0] === actual) {
            "Original Main value unavailable"
        }
    }
    private fun <T : Any> bindValue(index: Int, release: ReservedValue<T>, value: T) = synchronized(gate) {
        check(claimed[index] && nativeAdapters[index] === release) { "Original native adapter unavailable" }
        var other = 0
        while (other < tickets.size) {
            check(!hasIdentity(other, value)) { "Actual resource already has its original token" }
            other++
        }
        actualIdentities[index] = value
        release.bind(value)
        // Late revoke may already have retired this original ticket. Attach the actual
        // acquired value immediately, without allocation or a new admission requirement.
        tickets[index].attachReserved(release)
    }
    internal fun createJob(index: Int, factory: ((kotlinx.coroutines.Job) -> Unit) -> kotlinx.coroutines.Job): ReservedJobRelease {
        val release = ReservedJobRelease()
        synchronized(gate) {
            check(!released && constructorThread === Thread.currentThread()) { "Original Job factory unavailable" }
            check(!claimed[index]) { "Original child already claimed" }
            tickets[index].requireAttachmentAdmission()
            claimed[index] = true
            jobAdapters[index] = release
            factoryInProgress[index] = true
        }
        // The preclaimed worker stays idle until the actual Job is immediately bound.
        try { release.create(attachOriginal = { actual ->
            synchronized(gate) {
                check(jobAdapters[index] === actual) { "Original Job adapter unavailable" }
                var other = 0
                while (other < tickets.size) {
                    check(!hasIdentity(other, actual.actualJob)) { "Actual Job already has its original token" }
                    other++
                }
                actualIdentities[index] = actual.actualJob
                tickets[index].attachReserved(actual)
            }
        }, factory = factory)
            return release
        } finally { synchronized(gate) { factoryInProgress[index] = false } }
    }
    fun copyBytes(index: Int, source: ByteArray, readerMutex: Any? = null): ByteArray {
        val ticket = synchronized(gate) {
            check(!released && constructorThread === Thread.currentThread()) { "Original array factory unavailable" }
            check(!claimed[index]) { "Original child already claimed" }
            tickets[index].requireAttachmentAdmission()
            claimed[index] = true
            factoryInProgress[index] = true
            tickets[index]
        }
        // No application or reservation gate is held across allocation/copy.
        try {
            val release = allocateArrayRelease(readerMutex)
            release.requireEmpty()
            val actual = copyArray(source)
            synchronized(gate) {
                var other = 0
                while (other < tickets.size) {
                    check(!hasIdentity(other, actual)) { "Actual array already has its original token" }
                    other++
                }
                actualIdentities[index] = actual
                release.bind(actual)
                // The in-progress marker denies reentrant phase sealing until attachment.
                ticket.attachReserved(release)
            }
            return actual
        } finally { synchronized(gate) { factoryInProgress[index] = false } }
    }
    /** Fixed setup manifest root: bounded asynchronous candidate wipe plus producer Job.
     * The allocating constructor immediately attaches its acknowledged root at index0. */
    internal fun requireAiSetupCandidateConstruction(owner: Any) = synchronized(gate) {
        check(tickets.size == 2 && tickets.all { it.belongsTo(owner) }) { "Setup candidate original unavailable" }
        check(!released && constructorThread === Thread.currentThread() && !claimed[0] &&
            !phaseSealed[0] && !factoryInProgress[0]) { "Setup candidate construction unavailable" }
        tickets[0].requireAttachmentAdmission()
    }

    /** Fixed photo input root plus outer Job. Identity/shape faults are never cancellation. */
    internal fun requirePhotoInputConstruction(owner: Any) = synchronized(gate) {
        check(tickets.size == 2 && tickets.all { it.belongsTo(owner) }) { "Photo input original unavailable" }
        check(!released && constructorThread === Thread.currentThread() && !claimed.any { it } &&
            !phaseSealed.any { it } && !factoryInProgress.any { it }) { "Photo input construction unavailable" }
        tickets[0].requireAttachmentAdmission()
    }
    internal fun requirePhotoInputUse(owner: Any, actual: Any) = synchronized(gate) {
        check(tickets.size == 2 && tickets.all { it.belongsTo(owner) } && constructionAdmitted &&
            constructorThread == null && claimed.all { it } && !factoryInProgress.any { it } &&
            actualIdentities[0] === actual && actualIdentities[1] != null && jobAdapters[1] != null) {
            "Photo input absent from its completed original"
        }
        if (released || phaseSealed.any { it })
            throw kotlinx.coroutines.CancellationException("Original photo input unavailable")
    }

    /** Exact directly attached acknowledged key root; no authority-key wipe exemption. */
    internal fun requireStagingKeyConstruction(index:Int,owner:Any)=synchronized(gate) {
        check(index in tickets.indices && tickets.all{it.belongsTo(owner)}) { "Staging key original unavailable" }
        check(!released && constructorThread===Thread.currentThread() && !claimed[index] &&
            !phaseSealed[index] && !factoryInProgress[index]) { "Staging key construction unavailable" }
        tickets[index].requireAttachmentAdmission()
    }
    internal fun requireStagingKeyGeneration(index:Int,owner:Any,actual:Any)=synchronized(gate) {
        check(index in tickets.indices && tickets.all{it.belongsTo(owner)} && claimed[index] &&
            actualIdentities[index]===actual && nativeAdapters[index]==null && mainAdapters[index]==null &&
            jobAdapters[index]==null) { "Staging key absent from original" }
        check(!released && !phaseSealed[index] && !factoryInProgress[index] &&
            constructorThread===Thread.currentThread()) { "Staging entropy construction unavailable" }
    }
    internal fun requireStagingKeyUse(index:Int,owner:Any,actual:Any)=synchronized(gate) {
        check(index in tickets.indices && tickets.all{it.belongsTo(owner)} && constructionAdmitted &&
            constructorThread==null && claimed.all{it} && !factoryInProgress.any{it} &&
            actualIdentities[index]===actual && nativeAdapters[index]==null && mainAdapters[index]==null &&
            jobAdapters[index]==null) { "Staging key absent from completed original" }
        check(!released && !phaseSealed[index]) { "Original staging key retired" }
    }

    /** Verify exact operation and a preclaimed Native child before allocating its payload. */
    internal fun requireNativeConstruction(index: Int, owner: Any) = synchronized(gate) {
        check(tickets.all { it.belongsTo(owner) }) { "Native child belongs to another operation" }
        check(!released && constructorThread === Thread.currentThread()) { "Original native factory unavailable" }
        check(index in tickets.indices && claimed[index] && !phaseSealed[index] &&
            nativeAdapters[index] != null && actualIdentities[index] == null && factoryInProgress[index]) {
            "Native child construction absent from this original"
        }
    }
    /** Original and child retirement are visible before a delayed release callback starts. */
    internal fun requireNativeUse(index: Int, actual: Any) = synchronized(gate) {
        check(!released && !phaseSealed[index] && !factoryInProgress[index] &&
            actualIdentities[index] === actual) { "Original Native child unavailable" }
    }

    /** Cleanup linkage only: revoke may follow attachment before the constructor links
     * its unentered rollback child. This grants no acquisition or live Native use. */
    internal fun requirePreparedPinRollbackCleanupLink(owner: PrimaryOperation, child: PreparedPrimaryPinRollback) = synchronized(gate) {
        check(tickets.size > 1 && tickets.all { it.belongsTo(owner) } &&
            constructorThread === Thread.currentThread() && claimed[1] &&
            !phaseSealed[1] && !factoryInProgress[1] && actualIdentities[1] === child) {
            "Prepared PIN rollback absent from original constructor"
        }
    }

    /** Atomically seal pending-buffer ingress against this exact original's retirement.
     * begin changes bounded metadata only; no callback, allocation, provider work or wait. */
    internal fun beginPendingBuffer(index: Int, buffer: PendingSetupBuffer, production: Boolean) = synchronized(gate) {
        check(!released && index in tickets.indices && claimed[index] && !phaseSealed[index] &&
            !factoryInProgress[index] && actualIdentities[index] === buffer) { "Original pending buffer unavailable" }
        buffer.begin(production)
    }

    /** Typed input roots must already belong to this scope before generic result verification. */
    internal fun requireNativeRoot(root: ReservedValue<*>) = synchronized(gate) {
        check(!released && constructorThread === Thread.currentThread()) { "Original input factory unavailable" }
        check(claimed[0] && nativeAdapters[0] === root && actualIdentities[0] != null &&
            !factoryInProgress[0] && tickets[0].owns(root)) { "Input root absent from this original native factory" }
    }

    fun verifyResult(index: Int, child: AutoCloseable) = synchronized(gate) {
        val original = tickets[index]
        check(!claimed[index] || original.owns(child)) { "Original child already claimed" }
        var other = 0
        while (other < tickets.size) {
            val ticket = tickets[other]
            check(ticket === original || !hasIdentity(other, child)) { "Actual resource already has its original token" }
            other++
        }
        original.verifyResult(child)
    }
    /** Original validation and producer admission share one metadata critical section. */
    internal fun beginTemporaryKey(key: OriginalTemporaryKey) = synchronized(gate) {
        check(tickets.size == 1 && !released && constructorThread == null && claimed[0] &&
            actualIdentities[0] === key && !phaseSealed[0] && !factoryInProgress[0]) {
            "Original temporary key unavailable"
        }
        key.begin()
    }
    /** Narrow key-only handoff; all other original children really retired first. */
    internal fun consumeAuthenticationHandoff(attempt: Any, key: OriginalAuthenticationKey): ByteArray = synchronized(gate) {
        check(key.hasAuthenticationLayout(tickets.size) && tickets[0].belongsTo(attempt) && !released &&
            constructorThread == null && actualIdentities[0] === key &&
            (1 until tickets.size).all { phaseSealed[it] && tickets[it].successful }) {
            "Original authentication handoff unavailable"
        }
        key.take()
    }

    /** Finish only declared secondary children; entry0 pins this enclosing factory. */
    internal fun retirePhase(indices: IntArray, absent: Boolean, cancelIfReleased:Boolean=false) {
        synchronized(gate) {
            check((!released || cancelIfReleased) && constructorThread === Thread.currentThread()) { "Original factory phase unavailable" }
            require(indices.isNotEmpty() && indices.size < tickets.size) { "Invalid original phase" }
            var position = 0
            while (position < indices.size) {
                val index = indices[position]
                require(index in tickets.indices) { "Child absent from original manifest" }
                check(index != 0) { "Original factory lifetime cannot retire inside construction" }
                check(!phaseSealed[index] && claimed[index] != absent && !factoryInProgress[index]) { "Original child phase unavailable" }
                if(!absent) {
                    check(actualIdentities[index]!=null) { "Original child construction incomplete" }
                    // Disposal clears only the ticket pointer; this original's permanent
                    // actual association above remains mandatory even after release.
                    if(!released)check(tickets[index].hasAttachedResource) { "Original child construction incomplete" }
                }
                var earlier = 0
                while (earlier < position) { require(indices[earlier] != index) { "Duplicate phase child" }; earlier++ }
                position++
            }
            // Exact metadata decision under this original gate, after validating
            // phase shape/identity/constructor. A released producer cannot advance,
            // including cancellation between its guard check and this admission.
            // Do not derive neutrality by catching an arbitrary Native/consumer fault.
            if(released)throw kotlinx.coroutines.CancellationException("Original factory phase unavailable")
            // Every index was validated before any original child state changed.
            position = 0
            while (position < indices.size) {
                val index = indices[position]
                phaseSealed[index] = true
                if (absent) claimed[index] = true
                position++
            }
        }
        try {
            retirementPool.beginRetirementDispatch()
            try {
                // Dispatch the WHOLE phase before waiting: transport may unblock input close.
                var position = 0
                while (position < indices.size) { tickets[indices[position]].endConstruction(); position++ }
                position = 0
                while (position < indices.size) { tickets[indices[position]].release(); position++ }
            } finally { retirementPool.endRetirementDispatch() }
            var position = 0
            while (position < indices.size) {
                val ticket = tickets[indices[position]]
                do {
                    var candidate = 0
                    while (candidate < indices.size) {
                        if (tickets[indices[candidate]].failed) throw java.io.IOException("Original child release failed")
                        candidate++
                    }
                } while (!ticket.terminalRetirement.await(1, java.util.concurrent.TimeUnit.SECONDS))
                check(ticket.successful) { "Original child terminal unavailable" }
                position++
            }
        } catch (problem: Throwable) {
            // A failed phase cannot be caught and used to create the next native child.
            try { release() } catch (releaseProblem: Throwable) { problem.addSuppressed(releaseProblem) }
            throw problem
        }
    }

    fun owns(child: AutoCloseable): Boolean = tickets.any { it.owns(child) }
    /** Legacy observation may be late; it grants no owning retirement acknowledgement. */
    fun onSuccessfulRetirement(accounting: () -> Unit) {
        tickets.forEach { ticket -> ticket.onSuccessfulRetirement { if (successful && retirementNotified.compareAndSet(false, true)) accounting() } }
    }
    /** Register actual owning metadata before releasing or exposing the factory. */
    fun onRetirementAccounting(onAcknowledged: () -> Unit = {}, accounting: () -> Unit) {
        val group = ReleaseRetirementGroup(tickets.size, retirement, terminalRetirement, accounting, onAcknowledged)
        strictAccounting = true
        tickets.forEach { it.onRetirementAccounting {} }
        tickets.forEach { it.onOwningRetirement(accounting = {}, publication = {}, group = group) }
    }
    fun release() {
        // Process-visible before local revocation, including normal disposal outside
        // an authority. The counter never holds the pool gate across child dispatch.
        retirementPool.beginRetirementDispatch()
        try {
            synchronized(gate) {
                released = true
                // Controllable result bytes are invalidated before cancellation returns.
                // This does not acknowledge a Native invocation or recycle any slot.
                (actualIdentities.firstOrNull() as? OriginalAuthenticationKey)?.invalidate()
                (actualIdentities.firstOrNull() as? OriginalTemporaryKey)?.invalidate()
            }
            var index = 0
            while (index < tickets.size) { tickets[index].release(); index++ }
        } catch (failure: Throwable) {
            retirementPool.failRetirementAdmission()
            throw failure
        } finally { retirementPool.endRetirementDispatch() }
    }
}
