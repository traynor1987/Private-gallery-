# Task 2 implementation report

Base: `abb834abff8bfa8994ac4db646885309e0ab04fd` (controller-verified Task 1 checkpoint).

## Scope and internal batches

Task 2 remains OPEN. This first batch A is a tested prerequisite, **not an active global writer guard**. No production PIN writer is switched until the complete writer migration is coherent. A additionally corrects the existing already-owned biometric preference helper's ambiguous-provider failure accounting, as required by the updated task-2a brief.

1. **A — exact prepared PIN command core.** One process-wide bounded CAS claim, preowned exact preference commands, exact operation admission, actual original terminal-ACK retention, retained typed restore decision/rollback, and ambiguous-write quarantine. No raw rollback lambda or general callback executor. The command's preparation performs no crypto and does not claim to own provider children.
2. **B — producer and crypto ownership.** Exact original-attempt contexts; bind recovered VDEK to its funded result before subsequent blocking preparation; thread/lifetime/one-use sealing; own and phase all actual PIN buffers/provider references before acquisition. Preserve the three-child branded final handoff and fixed physical capacity 16.
3. **C — complete non-restore integration.** Setup/change/recovery plus every conflicting biometric/recovery-slot writer must share A's claim; remove the arbitrary commit callbacks and defaults. Setup storage eligibility and recovery generation + authority admission must authorize only the already-prepared exact sequence. No writer bypass may be described as a global guard.
4. **D — restore integration and fixtures.** Migrate actual original attempt/worker/input/result/open and archive stage/verification ownership, then switch installer and rollback together. Keep root exclusion until a concrete replacement transaction excludes competing installers and accounts for protected storage work. Retain the same claim through durable completion or exact-owned rollback. Adapt Android fixtures and run focused behavioral races/compilation.

## Source-grounded dependencies

`PinVaultKeyStore` currently performs create/change/recovery/restore writes and owns a raw rollback closure. `PrimaryKeySlots.recover` passes a generic mutation callback through Main's generation gate; the preparation-to-write gap remains. `RecoveryVaultKeyStore` and `RecoverySetupLifecycle` contain separate writer/rollback state and preference-held commits. `PrimaryBiometricPreferenceWrite` has its own separate slot. All are mandatory C/D migration sites.

`MainActivity.restoreEncryptedBackup` currently creates raw lifecycleScope IO work, opens an unowned input stream, hands back raw key bytes, and calls `open`; `AndroidVaultRepository.restoreBackup` holds the root lock through archive IO, preference commits and rollback. These are concrete D prerequisites, not permission to remove serialization. The ordinary framework Continue action is the accepted fallback if staged asynchronous restore requires a later final handoff without an outer-worker exemption.

`PinEnvelope` additionally constructs SecretKeySpec and GCMParameterSpec copies, Cipher and SecureRandom references, and SCrypt intermediates. A wrapper receipt around PinEnvelope does not fund those resources. B must establish the actual supported boundary/census and phase before exceeding 16. Algorithms, parameters, serialized fields and legacy readability remain unchanged.

## Batch A evidence

### Implemented prerequisite and narrow production correction

- `PrimaryCredentialMutation.kt`: fixed process registry, opaque purpose/original claim, metadata-only retained terminal marker and two flags. A claim becomes replaceable only after explicit durable decision AND the same original's positive terminal actual-return ACK. No hook, completion callback, queue or wait under its CAS. Sticky ambiguity survives rollback and reconstructed command/store objects. The retained marker does not retain operation/key/Editor graphs.
- `PreparedPrimaryPinWrite.kt`: fixed legacy three-field encrypted record; attached write obligation before claim/editor acquisition; exactly one prepared editor and typed admission; same invocation thread, exact operation/original, one execution; no crypto implied. Editor preparation, commit and cleanup run outside authority/storage/preference gates. Reentrant commit cannot declare invocation return. True persistence plus actual return completes the command's normal receipt; entered false/throw completes it exceptionally and retains the original physical charge.
- Restore independently prefunds child1 before either editor. Its exact clear editor, installed fixed record and SAME mutation survive child0 return until explicit installed success or exact-owned rollback. Undecided restore retains a pending physical child even after write-child return and requested release. Precommit partial construction seals known-no-write cleanup normally. Mismatched record is preserved and cleanup fails. Rollback after revoke is cleanup, not new authority; rollback success cannot erase an earlier failed provider original. Reentrant rollback cannot repeat or finish itself on its provider stack.
- `PrimarySessionAuthority.kt`: typed command admission requires exact operation epoch/scope/original membership and attached child, checks mandatory incomplete/failed cleanup across both existing pools, and runs only bounded metadata under the authority gate. Generic pool behavior and healthy live-original admission remain unchanged. This is not yet the original authentication attempt/generation integration required by B/C.
- `PrimaryBiometricPreferenceWrite.kt`: existing owned helper now quarantines its existing slot and fails its original cleanup receipt on entered commitfalse/throw. Repeated old close cannot release quarantined state. The helper propagates the persistence failure without waiting for an impossible success receipt. Preparation-only failure still retires normally. This helper still uses its separate existing guard; A does not claim a shared active global guard.

### Source manifest

Production: `app/src/main/java/uk/co/traynor/privategallery/core/security/PrimaryCredentialMutation.kt`, `PreparedPrimaryPinWrite.kt`, `PrimarySessionAuthority.kt`, `PrimaryBiometricPreferenceWrite.kt`.
Tests: `app/src/test/java/uk/co/traynor/privategallery/core/security/PrimaryCredentialMutationTest.kt`, `PreparedPrimaryPinWriteTest.kt`, `PrimaryBiometricPreferenceWriteTest.kt`, `PrimaryCredentialProcessFixture.kt`.

All paths after the first in each list use the same respective directory. No PinEnvelope algorithm/parameter/encoding change, production writer switches, Main/restore/root changes, capacity/ACK semantics change, biometric enablement, new thread pool or platform exception.

### Public provider boundary and historical correction

Independent official-source review: `/root/.cache/private-gallery-task3b/sharedpreferences-commit-retirement-review.md`; raw `sharedpreferences-android14.java` and `sharedpreferences-main.java` alongside. Android14_r1 commit595–618 and enqueue664–696 show false on interrupted private-latch wait without cancelling queued disk work. Pinned main `1cdfff555f4a21f71ccc978290e2e212e2f8b168` has the same path at603–626/672–704; SHA256 `a1daeb52d3211428131f08ae236709059b3c46ab8d050a59d09a935e5ca6f8cd`.

Sources: https://android.googlesource.com/platform/frameworks/base/+/android-14.0.0_r1/core/java/android/app/SharedPreferencesImpl.java ; https://android.googlesource.com/platform/frameworks/base/+/1cdfff555f4a21f71ccc978290e2e212e2f8b168/core/java/android/app/SharedPreferencesImpl.java ; https://developer.android.com/reference/android/content/SharedPreferences.Editor#commit() ; https://developer.android.com/reference/android/content/SharedPreferences .

Public false/throw does not expose a supported original disk-work ACK. Clearing app references, app-call return, later readback/rollback or a fake worker later finishing cannot positively retire the failed original. It stays failed/charged and unavailable this process. True acknowledges persistence, separately from actual app invocation return; it does not assert universal framework queue/OEM/native quiescence. No listener/apply support is introduced. No production listener registration was found in the source review. Any future app listener requires separate lifecycle ownership.

Earlier A green runs05/07 incorrectly treated returned false/throw as normal cleanup and used reflection-based slot resets during exploratory fixture work. Those parts are explicitly disqualified by the official source investigation and superseded by runs08–12. Historical logs/XML are preserved, not relabeled as final evidence. Existing BIO test's precommit-failure assertion is preserved; its entered-throw case is split and strengthened to require failed charge. Existing false-return case is strengthened rather than removed.

### Test isolation and real ownership

`PrimaryCredentialProcessFixture` invokes ONLY app-private constructor/private helper by reflection to provide a fresh synthetic process registry. The production prepared-command factory and biometric wrapper hardwire their fixed singleton; no caller-selectable registry overload is exposed. No failed mutation/receipt/charge is reset. Existing `ReservedAuthorityFixtures.testPrimaryAuthority` installs fresh synthetic pools; the new two test classes substitute their fresh16 pool immediately after construction and BEFORE open/operation/original acquisition. This is initial fixture construction, never replacement of a live/failed pool. Production fixed capacity/admission remain unchanged.

Held-return tests use real ReleaseReservation/ReleaseInvocation and the existing test allocator to hold the original release wrapper AFTER internal completion. Both the synthetic pool charge and terminal marker remain unavailable until actual return. Controlled fake disk workers are joined; releasing them never alters failed original ACK. Failure fixtures retain failed accounting through teardown. No Android-private reflection, native cleanup reflection, ACK overrides or reflective slot clears remain.

### TDD and focused verification

Evidence directory: `/root/.cache/private-gallery-task3b/`. Each executed behavioral run below has its exact log `<name>.log` and copied JUnit directory `<name>-xml/`. Compilation-only runs have no behavioral XML claim. Counts are tests/failures/errors.

| Run name | Result | Evidence qualification |
|---|---:|---|
| task2-a-01-missing-api-red | compile failure | Missing registry API, not behavioral RED. |
| task2-a-02-terminal-behavior-red | 4/1/0 | Genuine held original ReleaseInvocation return failure. |
| task2-a-03-terminal-green | 4/0/0 | Terminal barrier correction. |
| task2-a-04-command-api-red | compile failure | Missing command API, not behavioral RED. |
| task2-a-05-command-first | 16/0/0 | Early command coverage; failed-provider retirement assumption superseded. |
| task2-a-06-admission-behavior-red | 21/1/0 | Genuine unauthorized direct metadata admission. |
| task2-a-07-admission-green | 61/0/0 | Typed gate correction; ambiguous cleanup/fixture qualifications above. |
| task2-a-08-provider-behavior-red | 25/6/0 | Genuine false/throw charge, retained ambiguity and reentrant-return/rollback failures. |
| task2-a-09-biometric-provider-red | 28/1/0 | 27 core tests passed; BIO JUnit initialization failure (two inferred non-Unit methods), not BIO behavioral RED. |
| task2-a-10-biometric-provider-behavior-red | 14/2/0 | Genuine existing BIO false/throw normal-retirement defect. Teardown reported the charged-fixture assertion; final fixture now preserves primary assertion and suppresses teardown errors. |
| task2-a-11-focused-green | 68/0/0 | Fresh coherent selected suite; exit0, BUILD SUCCESSFUL1m34s. |
| task2-a-12-critical-repeat-green | 9/0/0 | Controlled repeat on final source, exit0; held actual return, revoke, restore/partial decision, provider uncertainty. |

Exact run11 command:
```sh
python3 /root/.cache/private-gallery-task3b/run.py task2-a-11-focused-green :app:testDebugUnitTest --tests uk.co.traynor.privategallery.core.security.PreparedPrimaryPinWriteTest --tests uk.co.traynor.privategallery.core.security.PrimaryCredentialMutationTest --tests uk.co.traynor.privategallery.core.security.PrimaryBiometricPreferenceWriteTest --tests uk.co.traynor.privategallery.core.security.PrimarySessionAuthorityTest --tests uk.co.traynor.privategallery.core.security.PrimaryRecoveryAuthenticationTest
```
Copied XML run11: PreparedPrimaryPinWrite22, PrimaryCredentialMutation5, PrimaryBiometricPreferenceWrite14, PrimarySessionAuthority14, PrimaryRecoveryAuthentication13; zero failures/errors/skips. Unit-test task compiled production Kotlin and tests. Existing unrelated compiler warnings remain. Android instrumentation compilation and device acceptance are not claimed by this run. Source was frozen during every Gradle execution; one Gradle at a time.

Exact final critical repeat command (run12 XML copied alongside its log):
```sh
python3 /root/.cache/private-gallery-task3b/run.py task2-a-12-critical-repeat-green :app:testDebugUnitTest --tests '*PreparedPrimaryPinWriteTest.actualReleaseWrapperReturnStillBlocksReplacementAfterCommitAndCloseStageComplete' --tests '*PreparedPrimaryPinWriteTest.admittedCommitSurvivesRevokeButRetainsClaimAndChargeUntilActualReturn' --tests '*PreparedPrimaryPinWriteTest.restoreRetainsSameClaimAfterWriteReturnUntilExplicitInstalledDecision' --tests '*PreparedPrimaryPinWriteTest.partialRestorePreparationBeforeAnyEnteredWriteRetiresBothChildrenAndSealsTheDecision' --tests '*PreparedPrimaryPinWriteTest.falseCommitCanReturnWhileDiskWorkIsHeldAndLaterUnobservedReturnCannotFreeOriginal' --tests '*PreparedPrimaryPinWriteTest.successfulRollbackCannotAcknowledgeEarlierAmbiguousProviderWork' --tests '*PrimaryCredentialMutationTest.finishedBodyAndCompletedCloseStageCannotReleaseClaimBeforeActualOriginalReturn' --tests '*PrimaryBiometricPreferenceWriteTest.enteredProviderThrowKeepsFailedOriginalAndExistingSlotUnavailable' --tests '*PrimaryBiometricPreferenceWriteTest.failedPreferenceCommitNeverReturnsSuccessAndCannotAcknowledgeHeldDiskWork'
```
Run12 tests: PreparedPrimaryPinWrite6, PrimaryCredentialMutation1, PrimaryBiometricPreferenceWrite2; zero failures/errors/skips. The only source difference after run11 is correction of the BIO ownership comment to explicitly distinguish entered false/throw from known-no-write/true success. Run12 recompiled final production/test source. `git diff --check` is clean. No entire-suite rerun was performed. Run12 is one additional execution of nine controlled cases, not N-loop stress.

SDK-free checks: `python3 -m unittest discover -s scripts/tests -p 'test_*.py'` ran18 tests, OK with1 existing skip, exit0 (`task2-a-python-security.log`). `bash scripts/no_secret_scan.sh` returned PASS/exit0 (`task2-a-no-secret-scan.log`). The first Python run lacked ANDROID_HOME and skipped SDK checks; it is not the final source/security result. Re-run with `ANDROID_HOME=/root/.cache/private-gallery-task3b/sdk python3 -m unittest discover -s scripts/tests -p 'test_*.py'`:25/25 pass, exit0, log `task2-a-python-security-with-sdk.log`. SDK Platform-Tools/license warnings remain in Gradle output; no SDK reinstall or runtime/device claim.

### Self-review and bounded capacity

A standalone normal write uses one independently accounted child; restore reserves two before either editor. This is only A's preference-command census, not a full-route16 proof: B must account provider/input/result/worker temporaries and phase live work. No receipt around hidden crypto construction is presented as sufficient. The fixed registry retains bounded terminal identity/flags; command/rollback explicitly clear their app reference fields on supported completion. No charged tombstone is created on known unentered preparation failure. Ambiguous or failed cleanup deliberately remains charged.

Security self-review checked original identity, typed authority gate, no arbitrary callback/editor replacement after admission, actual release-wrapper barrier, no staged callback finalizer exemption, stale rollback denial, physical pending restore decision, mandatory unrelated failed cleanup denial, and absent source resets. Recovery generation and all-writer exclusion remain implementation obligations, not conclusions from these tests.

### A handoff status

A is a prerequisite-only coherent implementation pending independent review. Full Task2 remains OPEN. No push performed; controller owns checkpoint and Android compilation. Report is the specified ignored local handoff document, consistent with prior reports; controller will preserve it with evidence.


## Remaining obligations

All B/C/D obligations above remain mandatory. The next bounded slice is B: source-supported provider/secret census and owned phased PIN-envelope preparation, followed by exact original-attempt producer contexts. It must map SecretKeySpec copies, GCMParameterSpec, Cipher, SecureRandom, SCrypt intermediates and encoded outputs to supported cleanup/actual return; distinguish app-owned live resources from residual JVM/provider-internal copies after supported synchronous completion. Investigate supported noncopying/destroyable key interfaces before assuming unsupported cleanup. No hand-written crypto, algorithm/format rewrite or extension of the Keystore exception.

Specific remaining production gaps: PinVaultKeyStore create/change/recovery/install+rollback still bypass the new claim; PrimaryKeySlots/Main recovery still uses generic callback/generation rather than prepared exact attempt admission; RecoveryVaultKeyStore/RecoverySetupLifecycle writer and rollback paths need migration; withPrimaryBiometricRecoveryDisable remains an unowned callback path whose false/throw provider accounting is NOT repaired by the narrow already-owned BIO helper correction. All must share one complete transaction guard in C/D. Restore's raw worker/input/result/open and root-held IO/commits still require the documented D prerequisites. No root exclusion removal or automatic-finalizer exemption is authorized by A.

 Biometrics stay disabled; Task 3A, formats, capacity and the sole Android-internal Keystore exception remain unchanged. No Task3C–H, Phase3 Tasks4–8, main/protected refs, PR59, release/signing or device acceptance work is included.

## Independent A review round1 — rollback attachment correction

Pre-review local commit `14307170d7f4909bf581c8d19c7b9eb7e2344935`; independent report `/root/.cache/private-gallery-task3b/task2a-independent-review.md` found one Important introduced defect. A revoke between separately attaching rollback child1 and linking it to write makes the live-original check fail before the write retains the child reference. Known-unentered cleanup then completes only child0, permanently stranding child1. Earlier run11/12 and controller Android compiles are valid for that earlier source but do not cover this missing interleaving.

Fix round preserves strict live Native admission while adding exact-original cleanup linkage for an already attached child during the original constructor. This is a ninth source file, `app/src/main/java/uk/co/traynor/privategallery/core/security/ReleaseReservation.kt`, not a relaxation of its generic live-use/attachment/release rules. No new acquisition, registration or Native work is permitted by cleanup linkage.

Behavioral RED command:
```sh
python3 /root/.cache/private-gallery-task3b/run.py task2-a-13-rollback-link-red :app:testDebugUnitTest --tests '*PreparedPrimaryPinWriteTest.revokeBetweenRollbackAttachmentAndLinkRetiresBothKnownUnenteredChildren'
```
On unchanged production at1430717:1 test/1failure/0errors/0skips, assertion `both acquired unentered children must retire`. Exact log/XML preserved. The Gradle test-result directory retained two stale prior class XML files; these were preserved under the copied run13 `stale-previous-run/` subdirectory, explicitly excluded from this run's count. Fresh RED failed the first loop case (revoke after child1 attach); final test also exercises revoke immediately before child1 attach and explicitly asserts that linking still rejects live use after revoke.

Correction: `requirePreparedPinRollbackCleanupLink` checks fixed child1 `actualIdentities`, exact operation owning all tickets, current original constructor thread, claimed/non-phased/non-factory child metadata. It works after release solely to retain the already-attached child for cleanup. `attachRollback` saves that validated child reference before the unchanged `requireNativeUse(1, value)` check. Revocation therefore still rejects live use, while `invocationReturned` can seal this known-unentered child's normal cleanup. No callback, provider operation, receipt write, new registration, pool change or generic admission relaxation occurs in the new check.

Review-fix coherent GREEN command:
```sh
python3 /root/.cache/private-gallery-task3b/run.py task2-a-14-review-fix-focused-green :app:testDebugUnitTest --tests uk.co.traynor.privategallery.core.security.PreparedPrimaryPinWriteTest --tests uk.co.traynor.privategallery.core.security.PrimaryCredentialMutationTest --tests uk.co.traynor.privategallery.core.security.PrimaryBiometricPreferenceWriteTest --tests uk.co.traynor.privategallery.core.security.PrimarySessionAuthorityTest --tests uk.co.traynor.privategallery.core.security.PrimaryRecoveryAuthenticationTest --tests uk.co.traynor.privategallery.core.security.OriginalFactoryTest --tests uk.co.traynor.privategallery.core.security.OriginalTerminalRetirementTest
```
Actual fresh XML:72 tests/0failures/0errors/0skips across PreparedPrimaryPinWrite23, PrimaryCredentialMutation5, PrimaryBiometricPreferenceWrite14, PrimarySessionAuthority14, PrimaryRecoveryAuthentication13, OriginalTerminalRetirement3. All six XML timestamps are from this run and copied to `task2-a-14-review-fix-focused-green-xml/`. Exit0, BUILD SUCCESSFUL1m45s. The extra `OriginalFactoryTest` selector was a misnamed nonexistent class, so it is NOT counted or claimed as coverage. To cover the intended existing original factory tests without another Gradle rebuild, ran `python3 /root/.cache/private-gallery-task3b/task2-a-review-fix-factory-check.py`, which invokes JUnitCore OwnedFactoryScopeTest using the saved complete debug test classpath and current compiled classes:5/5 pass, exit0, exact script/log retained.

On review-fix source, SDK-configured Python source/security checks25/25 pass (`task2-a-review-fix-python-security.log`) and no-secret scan PASS (`task2-a-review-fix-no-secret-scan.log`). `git diff --check` passed. The new real-authority regression runs both revoke timings, requires live-link denial, observes original terminal positive ACK/zero occupied children/zero editor or commit calls, and successfully opens an independent authority attempt afterward. Existing held-wrapper, pending restore, false/throw charge, unrelated-cleanup and stale-owner tests all remain green. No test or production source changed after run14.

Fresh nine-file source SHA256 manifest: `/root/.cache/private-gallery-task3b/task2-a-review-fix-final-source-sha256.json`. Source is frozen for independent re-review and controller checkpoint. Full Task2 and production caller migration B/C/D remain open; no active global guard claimed.

Frozen review-fix local HEAD: `61189d15774483edec57b63976dab42396097071`; tree `6c16139114ae75fbe8fd1e7b536853307bfb0c6b`. Preceding A implementation commit: `14307170d7f4909bf581c8d19c7b9eb7e2344935`. Working tree clean after removal of generated Python bytecode. No push. No Gradle active; source/Gradle lease returns to controller for re-review/checkpoint.

Run14 printed “Detected multiple Kotlin daemon sessions”; process inspection at freeze found 0 active Java Gradle/Kotlin daemon or worker processes. This warning alone is not evidence of competing writers/test contamination. The run held the sole source/Gradle lease.

## Next accepted implementation slice B1 — typed owned Primary PIN unlock

Planning only against frozen61189d1 plus `/root/.cache/private-gallery-task3b/task2b-crypto-ownership-feasibility.md`; no B source/Gradle edits before verified remote BASE and controller lease. Controller accepted this concrete production slice while A checkpoint completes.

### Production migration and exact result ownership

1. Replace the normal-unlock branch of MainActivity.installPinAuthenticatedKey's `authenticatePin(pin) { keys.unlock(pin) }` with a purpose-specific authority/store entry. The setup branch remains the current writer until C can migrate every conflicting writer. Do not accidentally route create through unlock or describe setup as fixed. PrimaryKeySlots.changePin and Main.verifySecretPin still call raw unlock and are mandatory B2/C integration sites; no broad replacement of these call contracts in B1.
2. In the existing authentication-key machinery, add a fixed typed Primary PIN producer context, constructed only for its original authority/attempt/result/input. Seal it to the invoking thread and one production operation; expiration/revoke/foreign attempt deny fresh preparation. Keep the exact three-child branded final original (`result`, `invocation`, `input`) and completeAuthentication's existing sole-original barrier. Do not add a public key getter, generic payload consumer, arbitrary factory authorization or selectable production backend.
3. Allocate the32-byte output into the already attached result cell BEFORE Cipher acquisition/doFinal; use the caller-output Cipher overload. The typed result has an exact internal decrypt method that invokes only the specific prepared PIN cipher against its private destination. Neither destination nor Cipher escapes in a callback/return. On success the very same array later crosses the existing authority admission once; on failure/bad tag/cancel it remains owned and is wiped after actual consumer return. This also establishes B2's required ability to bind recovered VDEK before subsequent blocking replacement preparation. No use of `result.bind(factory())` around a factory that already performs later PIN preparation.
4. PinVaultKeyStore exposes the exact encrypted snapshot needed by this typed unlock. Read getAll once outside app monitors; fund the read/phase invocation before read. Decode each salt/nonce/ciphertext into its own pre-funded child before further acquisition. No KDF or Cipher under preference/storage/authority gates. Keep the existing raw method only for explicitly unmigrated C/D callers and disclose those sites.
5. Typed crypto runs standard BC1.79 SCrypt and AES/GCM/NoPadding with N32768/r8/p1/output32,128-bit tag, salt16/nonce12/ciphertext48 for produced records. Preserve Base64 NO_WRAP field names/encoding and existing envelope vectors. Public encrypted snapshot strings/map can be bounded metadata; this does not treat plaintext PIN/key arrays as metadata.

### Conservative original census for the actual B1 route

The final-result original reserves3 physical children first. One separate exact-attempt unwrap phase reserves8 before acquisition: (0) phase coordinator/synchronous encrypted snapshot read, (1) decoded salt, (2) decoded nonce, (3) decoded ciphertext, (4) encoded ASCII PIN, (5) SCrypt wrapping output, (6) synchronous KDF facade, (7) Cipher/key-adapter/parameter facade. Peak11 of the existing physical16. The32-byte plaintext destination occupies the existing result cell, not an extra unowned result allocation. No entropy is needed for unwrap. The facade references are attached before provider/spec acquisition; returned SCrypt output binds immediately to its funded cell before any next blocking/throwing provider operation. Partial acquisition clears each actual buffer; known never-created entries follow existing original cleanup.

The phase coordinator keeps the exact synchronous callback active until all accesses cease. KDF/Cipher facade acknowledgements distinguish sealed ingress, actual synchronous app-call return and reference clearing; underlying arrays remain independent obligations. Phase original must reach actual positive terminal retirement before final result handoff; held callback return and failed cleanup deny it. If phase return/cancellation cleanup is incomplete, preserve charge and deny fresh authentication rather than treating the result's own receipt as sufficient. The actual B1 Main call is synchronous; no worker quota is invented. Outer UI queue/input capture ownership stays a separate Task3B obligation, not exempted by B1.

### Standard noncopying key and provider limit

Use a private standard javax.crypto.SecretKey adapter (`AES`, `RAW`) whose getEncoded returns the exact funded wrapping array only on its authorized synchronous invocation thread while its borrow is active. Repeated legitimate provider reads during that borrow return the same array; do not create SecretKeySpec or clone key bytes. Borrow spans Cipher acquisition/init AND doFinal. Revoke seals new entry; it cannot wipe an active borrow. After actual return/throw, clear facade references and retire/wipe backing bytes in the supported order. No serialization/export/cache/public reusable key, provider reflection, forced GC, reinit-as-wipe or custom cryptography. Do not claim Destroyable success while a borrower is active.

The inspected Android14 Conscrypt getEncoded alias and synchronous JNI RAII return support this boundary. Actual app borrow-return ACK and controllable-reference cleanup are positive observations; passive inaccessible provider/JVM memory residues are separately documented, not claimed zeroized. Cipher has no public destroy method. No active provider/app operation gets a Keystore-style exception; an actually active handle would require its supported retirement. GCMParameterSpec private IV copy is public nonce material with bounded lifetime, not a secretly wiped key. Tests on host providers establish interface compatibility, not an Android/OEM provider matrix.

### Compatibility policy and race boundary

Current PinEnvelope.derive accepts all ASCII chars (`code<=0x7f`) with no minimum, digit-only restriction or maximum. PinEnvelopeTest explicitly creates/opens four-digit vaults. B1 must preserve that policy, including shorter/longer ASCII legacy values accepted by the existing provider; do not impose UI six-digit policy or an arbitrary PIN length cap in crypto/unlock. Allocation failures/invalid non-ASCII must clear caller inputs through their original lifetime. New credential UI validation remains where it currently exists. Recovery whitespace/UTF8 compatibility is B2, not approximated by PIN ASCII encoding.

An encrypted snapshot is consistent input for this producer, NOT proof of immutable credential revision. Existing writers still mutate without A's shared claim until C/D. B1 must not claim predecessor CAS, global writer exclusion or repaired recovery check-to-write. Preserve exact original attempt/epoch/Primary vault final authority admission, and document the remaining credential-revision race rather than masking it with an unsupported generation check.

### B1 TDD order and meaningful focused acceptance

- First behavioral RED against the existing production unlock path: hold a real provider-facing invocation using an app-private synthetic fixture; cancellation must retain exact PIN/wrapping/result ownership until actual return and deny stale final auth. Missing API compilation is not behavioral RED. A separate deterministic ordering test observes the exact result destination attached BEFORE init/doFinal and no raw result interval.
- Legacy crypto compatibility: decrypt records produced by existing PinEnvelope with4-digit, ordinary6-digit, long ASCII and non-digit ASCII PINs; new unwrap retains fixed formats and wrong-tag InvalidPinException behavior. Cover empty/short values according to actual legacy provider behavior instead of inventing new policy. Cross-check new wrapping path later against old unwrap. Non-ASCII failure still wipes owned inputs.
- Capacity exhaustion denies snapshot/provider acquisition before any constructor; count actual maximum11, separate each decoded/key array, partial decode/KDF/init/doFinal failure and bad-tag output wipe. Use real original reservations and actual callbacks; no count/ACK reset.
- Thread/lifetime/one-use/foreign-attempt rejection; revoke before provider yields zero entry; held SCrypt and Cipher calls deny fresh admission, retain inputs, and finish cleanup only after real return. Same-secret/new-attempt identity does not resurrect old context.
- Private RAW key tests prove exact array identity/no clone, bounded same-borrow repeat reads, no foreign-thread/new-use after seal, no wipe before init/doFinal return. Production factory remains fixed; any synthetic fixture uses a private app-only seam and does not expose alternate production admission.
- Final-focused run: new typed PIN producer tests plus existing PinEnvelope, PrimaryPinSnapshot, AuthenticationHandoff, PrimarySessionAuthority and relevant actual-retirement tests. One Gradle at a time with frozen source; copy fresh selected XML and source hashes. No full-suite reruns for small edits.

### Next B2/C order after B1 checkpoint

B2 extends the same typed producer to recovery normalization/UTF8 and replacement wrapping; binds recovered key in the existing result cell immediately, retires all unwrap-specific children at actual terminal return, then prepares replacement PIN using only a fixed internal result method. Conservative wrap phase is9 children: coordinator, PIN bytes, wrapping output, salt, nonce, ciphertext, KDF facade, Cipher facade, entropy facade. With existing3 result children plus separately owned newPIN1, peak13 before persistence/outer workers. Retire/encode crypto outputs before acquiring the complete persistence/rollback family when combined route would exceed16; do not stack two full phases or silently exempt an outer worker. Recompute actual Main recovery/restore peaks against final source rather than reuse this B1 census as proof. Recovery normalization must preserve Char.isWhitespace and UTF8 replacement behavior without immutable secret strings.

C then migrates setup/change/recovery and every biometric/recovery-slot writer together, extending A's typed command to original-attempt and Main generation admission as needed; eliminate default arbitrary callbacks only when all production callers are switched coherently. D retains restore root exclusion until raw worker/input/stage/result/open dependencies are actually owned. No B1 outcome is acceptance of these later obligations.
