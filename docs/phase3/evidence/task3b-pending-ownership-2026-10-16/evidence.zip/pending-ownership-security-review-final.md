# Final independent pending-ownership security review
Repository: /workspace/scratch/0881340dd615/private-gallery-task3-recovered. Read-only source/test inspection; no Gradle, edits, or device execution. Root's run70608 was active; this report is conditional on fresh passing verification, not a test-pass claim.

Disposition: no remaining introduced blocking defect established in this scoped batch after P1 correction. The original P1 replacement-publication ordering defect is source-corrected.

Reviewed production paths:
- app/src/main/java/uk/co/traynor/privategallery/core/domain/PendingSetupResources.kt: two original attempt-owned cells precede master/secret creation; replacement uses one session-owned secret without unused copied master. Facade-construction failure now closes the already-created original in both factories.
- app/src/main/java/uk/co/traynor/privategallery/core/security/PendingSetupBuffer.kt and ReleaseReservation.kt beginPendingBuffer: exact child identity/index and unreleased original atomically admit a producer/borrower. Original release seals new ingress; active borrowers and late-returned arrays remain owned until actual return, then wipe. Release/close performs no Native work or joins under caller locks.
- app/src/main/java/uk/co/traynor/privategallery/core/domain/DomainSnapshot.kt PendingSetup: no longer owns raw pending master/secret fields; one-time display consumption borrows the original secret and disposes it on every exit. Copies exposed for confirmation remain separate obligations below.
- app/src/main/java/uk/co/traynor/privategallery/core/domain/SecondaryStore.kt create/resumePending/replaceRecovery/confirm/confirmReplacement: creation failures close original resources. Both confirmation forms now await pending retirement outside root serialization. Replacement additionally rechecks the exact operation after the wait; nonreplacement rejects failed retirement and closes its authenticated result before escape.
- app/src/main/java/uk/co/traynor/privategallery/core/domain/SecondaryController.kt: final replacement publication still checks sequence and original epoch; original selected-store/attempt promotion remains after nonreplacement cleanup.

Observable verification design:
PendingSetupOwnershipTest covers exact-array wipe, actual blocked producer/borrow preservation, cancellation/late return, denied original ingress and partial generation failure. PendingReplacementRetirementTest now arms its selected-file atomicReplace observation only after replacement creation, awaits actual confirmation selection, then proves another root reader can complete while exact pending consumption remains held. It captures observer Throwable and joins/asserts observer termination. Confirmation must remain unfinished until actual borrow return, with both positive and authority-revoked variants; the latter rejects success. This closes the earlier test-ordering/uncaptured-assertion gaps. SecondaryControllerTest retains the actual original-buffer wipe assertion using the new private holder and awaits real authority cleanup before deleting fixture files. Direct-store host/Android fixture overloads use genuine owned pending resources rather than restoring a raw production bypass.

Evidence status: root reported initial migration compile failure from two obsolete raw PendingSetup fixtures, followed by 45 executed tests/43 passed/2 failed from stale reflection and missing teardown acknowledgment. Those historical failures remain failures; the revised tests/source require the current run's result before scoped verification can be claimed.

Still mandatory B obligations in these exact surrounding paths:
- DomainSnapshot.PendingSetup.masterCopy/recoverySecret and SecondaryStore.confirm/confirmReplacement secretSnapshot/result copies are not fully premanifested by the two pending cells.
- SecondaryController.takeRecoveryDisplay still allocates the output CharArray without a complete display-resource manifest; synchronous original-byte disposal does not fund the UI-held copy.
- SecondaryController.submit still queues generic Executor work and captured input before a complete outer-work admission/return contract; the pending cells do not own its callback/queue lifetime.
- Store/provider/KDF/Native directory children and their complete simultaneous fixed16 accounting remain outside this scoped buffer proof. Existing root-held Native IO/cleanup obligations remain blocking, unchanged.
These are remaining Task3B requirements, not accepted deferrals or broadened exceptions. No biometrics are re-enabled; full A-D/Task3B remains PARTIAL.

Scoped source acceptance is conditional on green verification of the exact reviewed final files. No full Task3B, Android/runtime, device, encryption-format, or product acceptance claim.

Post-review execution update supplied by root: exact final JVM selection 89/89 passed (0 failures/errors/skips); race selection 45/45 passed, including five replacement-test repetitions with both revocation variants. Root states no production edits since the final source review. Android test compilation for both configurations remains running in session92324; no Android compilation/device pass is claimed here. These results satisfy the stated scoped host-verification condition only; full Task3B remains PARTIAL.

