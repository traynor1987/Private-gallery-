# Final narrow source review — Primary biometric preference write batch

## Scope and verdict

Read-only independent review of the final working-tree PrimaryBiometricPreferenceWrite.kt, BiometricVaultKeyStore.kt, PrimaryKeySlots.kt and PrimaryBiometricPreferenceWriteTest.kt in /workspace/scratch/0881340dd615/private-gallery-task3-recovered. No source edits and no Gradle/test executions. Root reports preserved initial RED and earlier GREEN evidence; its final run was active when this review was requested. This report establishes source review, not an independently observed final test result.

**No remaining introduced Critical/Important defect identified in this narrow batch.** The previously identified delayed/foreign recovery callback issue is addressed at the actual pre-PIN call site. This conclusion does not accept whole Task3B, restore biometric acquisition, or close existing legacy Native-under-gate/provider/transaction obligations.

## Exact command ownership and admission

The new Primary preference helper checks inherited authority-gated entry and credentials scope before preparation. Its one-child IO manifest reserves physical capacity and attaches an inert OriginalBiometricPreferenceWrite before slot claim, encoding and editor construction. The original construction remains active throughout the synchronous preparation, admission and actual commit invocation.

The short operation.commit block checks the same original for retirement/failure and marks only its already-bound editor admitted. It does not encode, construct an editor, persist, wait or perform Native work. commitExact invokes exactly that editor once outside the authority gate. A command admitted before revoke can finish, consistent with SECURITY_CONTRACT.md:17; revocation during preparation instead prevents admission and therefore prevents editor.commit. No new operation/session or replacement command is authorized by this flag.

The receipt does not complete on cancellation request. Actual synchronous preparation/commit unwinds, editor references clear, and the exact slot token closes before the receipt completes. The enclosing original must then finish construction/accounting and reach terminal retirement. Normal return performs a separate original-operation check after that cleanup. A caller that later queues UI work still needs its own original-epoch publication check.

The manifest's single child is coherent for this sequential app-controlled invocation plus Java Editor reference: no separate independently blocking supported Editor.close exists. Caller workers/providers/envelope obligations remain independently owned elsewhere; this helper does not claim to fund them. No inaccessible Keystore-retirement exception is used or enlarged.

## Failure and cleanup semantics

False commit results and preparation/commit exceptions propagate instead of reporting persistence success. An actual returned Native failure is not automatically a failed cleanup: references can be cleared and capacity returned honestly after that call has returned. Conversely, slot cleanup failure completes the receipt exceptionally and cannot produce successful original retirement. Await timeout or interruption denies successful return; interruption restores status. A false commit does not establish rollback of platform in-memory/disk state, and this batch does not promise such rollback.

The editor is not exposed by the production facade and the command is not retried. The generic internal preparation callback is used only before admission, not as a delayed supplier during commit. Actual production preparation binds the fixed existing Primary preferences and unchanged NONCE/CIPHERTEXT encodings.

## Slot exclusion and recovery refinement

PrimaryBiometricPreferenceSlot uses exact identity CAS. close is idempotent; a second old close cannot release a replacement token. requireHeld checks both returned state and current identity. All affected production biometric preference mutations use the same process-wide slot, so competing store instances are rejected rather than queued.

The refined withPrimaryBiometricRecoveryDisable captures its invocation thread and checks that identity before local one-shot state. Both enter and disable require the exact still-held token. enter is once-only; disable requires entry and is once-only; completed is set only after disableExact returns true. Therefore a scope whose action returns without disabling, or catches a false/throwing disable and returns, cannot report success. Finally always releases the original slot token.

Most importantly, PrimaryKeySlots.recover calls enter() FIRST inside the callback passed to commitAttempt, before pin.replacePinForRecoveredVault. A captured callback invoked after scope exit or on another thread now rejects before PIN mutation, and a repeat invocation rejects before a second PIN write. BiometricVaultKeyStore.withRecoveryDisable supplies a fixed preference-removal callback whose Native invocation occurs only after these guards. disable() uses the same entry sequence.

Claiming the slot before commitAttempt/PIN mutation prevents the new conflict failure where PIN replacement could succeed and only then discover a competing enrollment. This does not make two independent preference mutations transactional: real disable failure may still follow successful PIN persistence. Existing recovery/save Native-under-authority behavior and broader resource/key retention remain explicitly outside this narrow fix.

## Regression source inspection

The final test class contains 13 cases. In addition to the original six, it now covers revocation while preparation is held (zero editor commits), conflict denial before preparation and stale-token versus replacement behavior, actual preparation/commit exceptions with terminal original retirement, interrupted retirement, same-thread/once-only recovery entry, escaped callbacks denied before synthetic PIN effects while a replacement slot remains held, and swallowed disable failure remaining failure.

These cases directly address the review's concrete races and failure distinctions. The actual PrimaryKeySlots source places the guarded entry before its real PIN mutation, matching the synthetic callback ordering. Fake SharedPreferences.Editor tests do not establish Android filesystem durability or physical biometric lifecycle evidence. Final test success must be reported from the root's completed captured run, not inferred from this review.

## Remaining scope limits

- Primary legacy save/recovery Native work beneath authority gates is not generally migrated by this batch.
- PIN replacement and biometric disable are not a multi-store atomic transaction.
- Whole worker/provider/envelope and UI publication ownership, complete A–D cleanup-before-final-admission, and actual Android biometric lifecycle remain separate Task3B obligations.
- Biometric acquisition remains disabled unless separately authorized and implemented; no Task3C or product acceptance follows from this finding.
