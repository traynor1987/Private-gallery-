# Independent intermediate review — Primary biometric preference command

Read-only review of the uncommitted PrimaryBiometricPreferenceWrite.kt, BiometricVaultKeyStore.kt, PrimaryKeySlots.kt and PrimaryBiometricPreferenceWriteTest.kt in private-gallery-task3-recovered. No edits or Gradle executions. Root reports preserved six-case RED (four security failures/two passes); active GREEN execution was not independently verified here.

## Verdict

The exact synchronous one-child preference-write helper has no identified blocking defect in the reviewed scope. Recovery callback sealing remains a concrete fix before this batch is accepted. This is narrow C review, not complete Task3B or whole caller ownership acceptance.

## Required closure fix

BiometricVaultKeyStore.withRecoveryDisable currently allows its callback to escape and execute after its mutation token was closed, or on another thread while the token is nominally held. Its local `invoked` flag is neither lifetime validation nor a thread-confinement check. Root already plans Mutation.requireHeld plus invocation-thread validation before preference access. Check thread identity before reading/writing `invoked`, and require the exact current token and not-returned state. Keep one-shot rejection.

PrimaryKeySlots.recover also passes a callback to `commitAttempt` whose first effect is `pin.replacePinForRecoveredVault`, followed by `disable()`. A validation only inside disable is too late to deny a delayed/foreign execution of that entire callback before PIN mutation. If sealing this internal callback surface, validate the same held token and invocation thread at entry to the callback, before replacing PIN, or supply a synchronous guarded whole-mutation method. Current production commitAttempt is reported synchronous, so this is an API sealing issue rather than evidence of a current asynchronous caller. Do not claim that validating only disable seals all recovery Native work.

## Why the narrow helper is coherent

- `requireNativeOutsideAuthorityGate` rejects inherited authority-gated entry before reservation/preparation. Credentials scope is checked before any editor work.
- One exact IO original is reserved and its inert receipt attached before slot claim, encrypted encoding or editor preparation. The original constructor remains active across the whole synchronous preparation/admission/commit sequence.
- The editor is prepared and bound before the short `operation.commit`. That action only checks exact-original retirement/failure and marks the same bound command admitted. No preference operation runs under that authority gate.
- `commitExact` is once-only and cannot select a new editor. It runs outside the gate. Revocation after admission may allow this exact command to finish: SECURITY_CONTRACT.md:17 explicitly permits a commit linearized before revoke to finish. It does not grant a replacement command, new session or stale UI authority.
- closeAcknowledged returns only the actual-invocation future; it cannot falsely cancel/acknowledge an executing commit. `invocationReturned` clears editor references, releases the identity-protected slot, then completes the receipt. Constructor accounting and terminal retirement remain required. No separate supported Editor.close exists, so no omitted independently blocking disposal child is evident.
- Native/preparation failure and false commit result propagate. A failure to persist is distinct from failure to retire the app invocation: a returned failed persistence call can legitimately release capacity after reference cleanup. Actual cleanup failure instead completes the receipt exceptionally and prevents successful retirement. No Keystore exception is invoked or expanded.
- The finally block releases the exact original and awaits its terminal retirement. Timeout/interruption never reports completion; interruption restores thread status. Separate original-epoch authorization follows cleanup before successful function return. This is not final authorization for any later queued UI callback; that callback still needs its own current original identity check.

## Slot and legacy ordering

The process-wide CAS guard prevents concurrent mutation across store instances. Mutation.close is idempotent and compare-and-clears only its own identity, so an old repeated close cannot release a newer token. Claim is before legacy save's cipher/provider work and before disable work. Recovery now claims before invoking commitAttempt and before PIN replacement, eliminating the newly introduced case where busy enrollment would reject disable only after PIN mutation.

This does not make PIN replacement plus disable transactional: actual disable persistence failure can still follow PIN replacement, and legacy recovery/save still have their existing Native/gate/ownership obligations. Those are not fixed by the CAS and must not be described as closed. The shared slot provides rejection, not a queue; callers must propagate rejection and not publish success.

## Focused evidence still needed

The six inspected tests cover outside-gate work, inherited-gate denial, capacity rejection, held actual commit across revoke with new-authority denial, false commit, and insufficient scope. They do not establish preparation-held revocation denial, preparation/commit thrown-failure release of the shared slot, cross-instance conflict behavior, late/foreign/duplicate recovery closure rejection, or an old token's inability to clear a replacement. Add focused tests for the concrete lifetime sealing change and verify relevant failure paths before claiming this batch accepted. No new broad Android/platform success is inferred from fake Editor tests.
