# Enrollment wrapper extension — final narrow review addendum

Read-only inspection of latest working-tree PrimaryKeySlots.enrollBiometric, BiometricVaultKeyStore and PrimarySecondaryBiometricAdaptersTest in private-gallery-task3-recovered. No edits or Gradle executions. Root reports 35 focused tests passed; this addendum does not independently claim execution or instrumented device evidence.

## Verdict

No introduced Critical/Important defect identified in this extension. It addresses the prior review's specific cleanup ordering and fixture ownership conditions. This extends the narrow preference-write source review only, not whole Task3B acceptance.

## Production wrapper

- Entry rejects an inherited authority gate before preparing an envelope or invoking Cipher work, and requires credentials scope.
- The encrypted envelope is owned before production; producePrimaryBiometricEnvelope uses the existing owned temporary key snapshot path. Persistence uses the reviewed exact preowned preference command outside authority gates.
- The finally block closes the same envelope, requires its terminal retirement and checks releaseFailed. Timeout is not treated as retirement.
- Cleanup exceptions are suppressed onto the original production/persistence exception when one exists. Without an earlier exception, cleanup failure propagates. Interrupted retirement restores the interruption flag.
- A separate operation.commit occurs only AFTER envelope cleanup. Thus a revoke during this final cleanup denies successful wrapper return rather than relying on persistence's earlier postcheck.
- The former raw saveAuthenticated production leaf is absent from BiometricVaultKeyStore. The wrapper no longer performs Cipher/persistence Native work inside operation.commit.

The passed Cipher's provider/request lifetime still belongs to the enclosing caller. This wrapper does not claim to create or retire a biometric prompt/provider or authorize a queued future UI publication. Existing recovery PIN/disable Native-under-gate and transaction obligations remain open.

## Instrumentation fixture

The fixture now exercises PrimaryKeySlots.enrollBiometric with a real credentials operation and the same synthetic pCipher. authority.open receives pMaster.copyOf(), preserving the independent comparison buffer while transferring ownership of the copy. Existing Primary roundtrip, wrong-key rejection, Secondary roundtrip, Primary-to-Secondary substitution rejection and Secondary-to-Primary rejection assertions remain present and unchanged in purpose.

The finally block closes the operation, revokes the authority and waits for actual cleanupComplete before clearing the isolated preference file. A timeout fails rather than deleting preferences during outstanding authority cleanup. The outer finally wipes both synthetic master arrays even when cleanup fails. The fixture continues to state accurately that it does not establish hardware authentication behavior.

Android compile/runtime results must be reported from the root's actual completed checks; source inspection cannot establish them. No broader biometric enablement, Task3B acceptance or Task3C authorization follows from this addendum.
