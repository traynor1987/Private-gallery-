import org.junit.runner.*;
import org.junit.runner.notification.Failure;
public class RepeatJUnit {
  public static void main(String[] args) throws Exception {
    Class<?> testClass = Class.forName(args[0]);
    int iterations = Integer.parseInt(args[2]);
    for (int i = 0; i < iterations; i++) {
      Result result = new JUnitCore().run(Request.method(testClass, args[1]));
      System.out.println("iteration=" + (i+1) + " tests=" + result.getRunCount() + " failures=" + result.getFailureCount());
      for (Failure failure : result.getFailures()) System.out.println(failure.getTrace());
      if (!result.wasSuccessful()) System.exit(1);
    }
  }
}
