import java.lang.reflect.*;
import java.util.concurrent.*;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import org.junit.runner.*;
import org.junit.runner.notification.Failure;
public class HeldPriorFixture {
  static Object field(Object object,String name)throws Exception {Field f=object.getClass().getDeclaredField(name);f.setAccessible(true);return f.get(object);}
  static Object call(Object object,String name)throws Exception {Method m=object.getClass().getDeclaredMethod(name);m.setAccessible(true);return m.invoke(object);}
  public static void main(String[] args)throws Exception {
    Class<?> fixtureClass=Class.forName("uk.co.traynor.privategallery.core.domain.SecondaryControllerBiometricTest$Fixture");
    Constructor<?> constructor=fixtureClass.getDeclaredConstructor();constructor.setAccessible(true);Object previous=constructor.newInstance();
    CountDownLatch entered=new CountDownLatch(1),release=new CountDownLatch(1);
    Object authority=field(previous,"authority");
    try {
      call(previous,"create");
      long until=System.nanoTime()+TimeUnit.SECONDS.toNanos(10);
      while (!(Boolean)call(authority,"getCleanupComplete")) {if(System.nanoTime()>until)throw new AssertionError("initial cleanup");Thread.yield();}
      Object controller=field(previous,"controller");call(controller,"prepareBiometricEnrollment");
      Object backend=field(previous,"backend");Method setter=backend.getClass().getDeclaredMethod("setBeforeDelete",Function0.class);setter.setAccessible(true);
      setter.invoke(backend,(Function0<Unit>)()->{entered.countDown();try{if(!release.await(15,TimeUnit.SECONDS))throw new AssertionError("held cleanup timeout");}catch(InterruptedException e){throw new RuntimeException(e);}return Unit.INSTANCE;});
      call(previous,"close");
      if(!entered.await(10,TimeUnit.SECONDS))throw new AssertionError("actual provider cleanup not entered");
      System.out.println("priorFixture.close returned; actual provider close HELD; cleanupComplete="+call(authority,"getCleanupComplete"));
      Result r=new JUnitCore().run(Request.method(Class.forName("uk.co.traynor.privategallery.core.domain.SecondaryControllerBiometricTest"),"cancellationDuringPointerPromotionCannotDeleteTheSelectedBiometricAlias"));
      System.out.println("controlled original tests="+r.getRunCount()+" failures="+r.getFailureCount());
      for(Failure f:r.getFailures())System.out.println(f.getTrace());
      if(r.getFailureCount()!=1 || !(r.getFailures().get(0).getException() instanceof IllegalStateException))throw new AssertionError("did not reproduce original failure");
    } finally {release.countDown();long until=System.nanoTime()+TimeUnit.SECONDS.toNanos(10);while(!(Boolean)call(authority,"getCleanupComplete")){if(System.nanoTime()>until)throw new AssertionError("cleanup did not acknowledge");Thread.yield();}}
  }
}
