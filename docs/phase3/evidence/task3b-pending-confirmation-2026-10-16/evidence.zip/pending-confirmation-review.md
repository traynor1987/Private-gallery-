# Pending initial confirmation borrow review

Read-only inspection of actual DomainSnapshot.kt, SecondaryStore.confirm and PendingConfirmationBorrowTest.kt. No Gradle, source edits or commits. Parent reports preserved genuine red and active focused green; this review does not independently assert those execution outcomes.

No new concrete production defect established in the narrow initial confirmation change.

* PendingSetup.withMaster now delegates to exact PendingSetupResources original admission and active-buffer borrow. Store.confirm holds that exact master through verification, possession check, preparation, selected publication and readback. Native use receives the same array, not an early unaccounted master copy.
* The production controller invokes confirm only within prepareVerified(auth, secret) -> prepareThreadAuthenticationKey. Its prefunded input child retains the exact supplied secret until actual authentication worker return. Removing confirm's secretSnapshot copy is safe for that production path. Public direct store tests remain compatibility evidence, not proof of production ownership.
* pending.close seals ingress but does not wipe this admitted active borrow. Thus calling close before final result copying is safe: this callback still owns the original bytes until its finally returns. No new authority is granted by the retained borrow; final exact-attempt and store-selection checks remain outside it.
* The one fresh result copy is created only after successful selected publication/readback. resultMaster captures it immediately; exceptions during AuthenticatedDomain construction or unwinding withRetirement wipe that exact array. On a later pending retirement failure, result.close wipes the same owned result. The pre-existing authentication result token was funded before the whole factory and cannot admit until actual worker return and mandatory retirement.
* pending.awaitRetirement is outside both synchronized(root) and pending.withMaster. No self-wait on the master borrower is introduced. The original selected winner is never deleted as cancellation rollback.

The new regression exercises the production authentication worker/result handoff, holds the actual selected Native call, waits until the actual pending cell is marked retired under its real monitor, verifies original bytes survive while borrowed, then requires wiping, successful exact-result admission and a PIN round trip. This directly distinguishes borrower lifetime from merely provider callback arrival. Reflection is limited to the app-owned test cell, not platform/private Native APIs. It also demonstrates that explicit pending.close does not independently revoke the authentication attempt; admission remains governed by original attempt checks.

Useful additional failure coverage, without speculative source changes: revoke actual attempt while selection/provider is held and require no final admission; injected post-selection retirement failure must close the result; constructor/unwind failure after the final copy must wipe that exact copy. Existing larger auth/store suites may cover portions of these scenarios.

Scope remains partial: replacement input ownership and its secretSnapshot copy are unchanged; confirmPossession's transient unwrapped master, provider/KDF/file child manifests, outer queued inputs, display material and production test-only recoverySecret getter remain mandatory separate obligations. This review does not make a full B/C/D acceptance claim, change fixed16, enable biometrics or grant an AndroidX exception.

## Final getter removal and source check

The production recoverySecret copying getter has now been removed; that item above is resolved by API narrowing. Production PendingSetup exposes borrowed withMaster, consumeRecoverySecret and discard only, with neither masterCopy nor recoverySecret. rg over app/src/main found no remaining .recoverySecret or masterCopy calls.

Identical fixture-only extension properties in test/androidTest SecondaryPendingStoreFixture reflect only PendingSetup's own resources field, then use the actual resources.withSecret borrow to copy synthetic test input. No production seam, alternate retirement/authority path, Android private API or Native cleanup reflection was added. Two out-of-package instrumentation imports follow package declarations; the Phase2DomainAdaptersTest file annotation remains before package. This fixture-only adaptation is appropriate; no new production defect established.

Parent reports the first green attempt actually ran39 tests with38 passing and1 fixture failure: the new lifetime/key assertions passed, but the final PIN-roundtrip assertEquals compared distinct opaque DomainIdentity instances. Source now uses matches(container,master), preserving both namespace components. Parent reports corrected expanded selection75/75 passed. These are parent-observed execution results; this reviewer did not run Gradle. Final getter-consumer verification remains active at this inspection, so no outcome is asserted for it.

Current SHA256 fingerprints, computed directly from working files:

| File | SHA256 |
| --- | --- |
| DomainSnapshot.kt | 5613d1623977248bbcc9991909a18c9f9ffb71320363134c8d7eb33aa79ba02e |
| SecondaryStore.kt | 8f1de2f14d60d843005e67f37751147c4f4a5dc1a1b0cfe4b9d6afb985fab0c9 |
| PendingConfirmationBorrowTest.kt | 1ffb976def6f6973be5c4993335c4be3450d25801ab7e3fa343c71b89a0af828 |
| test/SecondaryPendingStoreFixture.kt | 584ad7c4fbaf45e28e34199eb40f4f7ff757dc5079c57a3c724fea2d450010d7 |
| androidTest/SecondaryPendingStoreFixture.kt | 584ad7c4fbaf45e28e34199eb40f4f7ff757dc5079c57a3c724fea2d450010d7 |

All other mandatory B/C/D dependencies above remain open. Narrow no-new-finding disposition remains unchanged. Only this cache report was updated; production/test sources and build state were not modified.
