from pathlib import Path
import subprocess
base=Path('/root/.cache/private-gallery-task3b')
classpath=(base/'debug-test-classpath.txt').read_text().strip()
command=[str(base/'jdk/bin/java'),'-Djava.library.path=app/build/host-staging-entropy','-cp',classpath,'org.junit.runner.JUnitCore','uk.co.traynor.privategallery.core.security.OwnedPrimaryPinUnlockTest','uk.co.traynor.privategallery.core.security.OwnedPlaintextTest']
with (base/'task2-b1-critical-repeat-and-task3a.log').open('w') as log:
 result=subprocess.run(command,cwd='/workspace/scratch/0881340dd615/private-gallery-task3-recovered',stdout=log,stderr=subprocess.STDOUT)
print('OwnedPrimaryPinUnlockTest + OwnedPlaintextTest exit',result.returncode)
raise SystemExit(result.returncode)
