# Independent review — narrow Primary recovery input/result migration

Read-only inspection of PrimaryRecoveryAuthentication.kt, MainActivity.recoverWithOfflineKey, PrimaryRecoveryAuthenticationTest.kt and the existing authentication original/attempt machinery in private-gallery-task3-recovered. No edits or Gradle/test execution. Root reports a preserved missing-symbol preimplementation compile failure and an active focused execution; this review does not relabel that compile failure as a behavioral RED or claim its active run passed.

## Verdict

No introduced Critical/Important defect identified in the supported synchronous production flow. The migration safely precedes the prepared durable-mutation refactor, with the stated Native-under-generation/preference locks and provider manifests remaining open. It establishes a narrower input/result ownership improvement, not complete B/C/D or Task3B acceptance.

## Actual ownership and final admission

The helper creates one PrimaryAuthAttempt, then reserves/attaches one new-PIN input original under that attempt before invoking the existing prepareAuthentication factory. The recovery secret and output remain in the unchanged branded three-child authentication layout. The new input is not added to or exempted from the handoff layout.

RecoveryPinInput begins in borrower-active state. Revocation marks it retired but cannot wipe it until returned() marks the actual synchronous preparation finished. The producer remains synchronous; no new unjoined worker or coroutine is introduced. prepareAuthentication independently retains its secret and candidate result through actual factory return. Returned invalid/stale candidate keys follow the existing rejected-result wipe path.

On the success path the new-PIN original is closed and awaited through terminal retirement, with releaseFailed checked, before completeAuthentication(current, handoff). Existing completeAuthentication still requires the exact attempt and exactly one remaining result original, and still performs the branded transfer. There is no raw-key copy/open alternative or outstanding-input exemption. Revocation/expiry/replacement during the producer or retirement cannot gain a new session through this helper.

## Partial construction and failures

If createAttemptOwned attaches the RecoveryPinInput but throws before returning OwnedResource (for example its post-construction current-attempt check fails), `input` is already recorded. The helper's finally calls input.returned(). createAttemptOwned itself releases the failed original in its catch, so the receipt can finish when its asynchronous release arrives. `owned` is null and no local await occurs on this path, but no key admission is attempted; the original stays in authority accounting until actual terminal retirement, blocking replacement admission. This is not an uncharged orphan or a false acknowledgement.

If preparation fails before its factory enters, the new-PIN borrower is still finished; there is no executing borrower to race. If preparation throws after acquiring its result original, that existing factory machinery releases it. On later retirement/completeAuthentication failure, the captured handoff is closed and the same attempt is cancelled. The successful result path is unchanged.

The explicit new-PIN wait denies incomplete retirement. Interruption restores the thread's interrupt flag. A retirement wait failure is suppressed onto an earlier producer failure rather than replacing it. Normal provider failure is distinct from failure to retire its original. Main's outer finally ensures both supplied arrays are wiped even for route or minimum-PIN-length rejection.

## Main production migration

Main still captures its original generation attempt and passes that exact token to the existing durable mutation callback. It now invokes retained.authority.authenticateRecovery and checks the boolean result, rather than receiving a naked key, copying it, and using authority.open. Only accepted authentication is followed by binding/Browser/UI/session work. This matches the existing synchronous PIN-install structure and does not introduce a new authority-held Native callback.

Main clears primaryEpoch before authentication and refreshes it from the accepted authority binding afterward. There is no mutable vault selector: the factory calls the fixed PrimaryKeySlots and the handoff targets the same retained Primary authority. Both user inputs are covered by the new Main finally even when authentication is never entered.

The existing AuthenticationAttemptAuthority generation monitor still encloses recovery PIN/biometric persistence, and PinVaultKeyStore still performs KDF/save under its preference monitor. This review does not count those as migrated. Snapshot/provider/input descendants, persistence command admission, two-store transactionality, outer UI synchronization and full path capacity remain separate obligations.

## Evidence limits

The five inspected tests cover successful exact-key admission/input wiping, provider exception, held-producer revocation with live inputs and replacement denial, producer expiry, and malformed key rejection/wiping. They test the core helper, not Android recovery stores or actual Main UI lifecycle. The partial createAttemptOwned-return case above is a source-traced conclusion, not a dedicated observed test in this five-case suite. Final execution evidence must come from the root's completed captured run.

## Addendum — nine-case scheduling review

Inspected the four added cases and ReleasePool/ReleaseTicket scheduling, without executing them. No scheduling defect identified in the added cases.

`cleanupCallbackMustActuallyReturnBeforeFinalAdmission` targets the first allocated ReleaseInvocation, not whichever worker happens to run first. The new-PIN original is the helper's first reservation; ReleaseTicket allocates its invocation during reservation, so the atomic sequence selects that exact child deterministically. The wrapper executes the real release action first and only then holds before the worker's `next.returned()` call. At that point the input's future can be complete and its PIN wiped, but ReleaseTicket.invocationReturned is still false and its terminal retirement cannot complete. The latch supplies visibility for the PIN assertion. The authentication thread must still be awaiting new-PIN retirement, with no accepted result or binding. Revocation during the hold then denies the eventual handoff; the finally releases the hold and joins the actual worker. This is genuine callback-return evidence, rather than a synthetic delayed future or an assumed scheduler ordering.

`insufficientCompleteResultCapacityDeniesBeforeFactoryAndReturnsInputSlot` reserves 15 physical tickets in an isolated 16-slot pool. Those unreleased foreign raw reservations count as occupied but not unacknowledged retirement, so initial attempt preparation is not rejected merely by cleanup state. The one new-PIN reservation can succeed; the following atomic three-child result reservation cannot. The test observes no producer entry, both inputs wiped and occupancy returned to exactly 15 before releasing the fixture's held tickets. This covers failure AFTER acquiring the separately returned new-PIN original but BEFORE result factory entry. It does not cover post-attachment failure before createAttemptOwned returns its OwnedResource.

`failedAttemptCreationWipesBothInputsBeforeFactory` injects clock failure during beginAuthentication, before provider entry, and checks both inputs. `beginAuthentication` cancels its pending attempt on that failure; no resource original has been allocated on this route.

`repeatedRecoveryCyclesReturnAllCapacityAndWipeOriginals` exercises twenty complete success/revoke/cleanup cycles. cleanupComplete gates the next cycle and the transferred key is checked wiped. It provides repeated reuse evidence, not measured whole-path capacity fit or a concurrent stress proof.

The explicit post-attachment/pre-OwnedResource-return branch remains source-traced rather than independently isolated by these nine tests. The tests also do not exercise Main route/minimum-length rejection, Android recovery stores, or the still-open Native-under-gate/provider paths. No completed nine-test execution result is claimed by this read-only review.

## Addendum — corrected stale-handoff fixture expectation

Root reported an expanded 65-case run with one failure in the cleanup-return case's post-join expectation: the actual result was false rather than an exception with an unset result. Root preserved that run's failure log/XML. Inspected the corrected test source and existing completeAuthentication implementation; no test execution performed here.

The corrected `accepted == false`, `failure == null` expectation matches this deterministic schedule. The recovery result factory and its post-production checks have ALREADY completed when the new-PIN release invocation is held. Revocation during that final input-retirement wait makes pendingAttempt differ from the original. Once the real release returns, authenticateRecovery reaches completeAuthentication with its captured handoff, and that method explicitly returns false for a stale pending attempt. It closes the handoff in finally. In contrast, the separate held-PRODUCER test revokes before prepareAuthentication's post-factory check and therefore legitimately expects an exception there.

This is a fixture expectation correction, not a production authorization fix or a weakened success condition. The corrected case retains no-binding/no-result/charged-capacity assertions before release, requires false acceptance with no binding afterward, and retains candidate wipe and pool-zero checks. No production change is needed to turn this existing false denial into an exception. My preceding source review correctly described denial but did not flag the old post-join exception assertion; that assertion assessment is corrected here. Fresh rerun results remain for the root to report from captured completed evidence.
