# Task 3B API35 request-process boundary — PROPOSAL, NOT ACCEPTED

## Revision 3 — implementation decision / replaces earlier protocol and manifest

Supported capability-retirement conclusion: a genuinely remote, strongly static endpoint whose isBinderAlive() returns false is positively dead. Once every app-issued RPC actual Thread has returned/joined, temporary Parcel recycle/client close have returned and all app references are detached, its application capability is retired. This does NOT claim BinderProxy Java/native allocator reclamation, GC, kernel memory wiping, or internal Keystore retirement. There is no remaining usable endpoint. No extra platform exception is needed for allocator bytes that expose no application authority. A live/death-unknown endpoint cannot receive this acknowledgement.

Final parent-callback-free protocol: open endpoint synchronously via owned unstable ContentProviderClient (Bundle onlyBinder); arm(originalId, operationHandle); show(originalId); readTerminal(originalId) -> fixed NONE/SUCCESS/ERROR metadata; terminate(originalId) one-way; observe exact endpoint isBinderAlive false. No parent DeathRecipient/receipt/ServiceConnection callback. readTerminal is bounded NONBLOCKING: do not pin a child Binder thread waiting for biometric completion, which could strand termination behind thread starvation. Parent actual producer Thread paces polling; pacing/timeouts are not retirement acknowledgements. Child static endpoint admits one attempt for its entire process lifetime, exact caller UID/id/handle only. Separate child :biometric process must not initialize vault/session authorities or obtain fresh cleanup quotas. No operationHandle in Intent/Bundle/savedstate. Only opaque locator in child Activity launch Intent; handle traverses exact private Binder transaction.

One candidate AUTH-phase physical manifest (16 maximum) is:

0 result key; 1 temporary input; 2 actual producer invocation; 3 actual producer Thread;
4 retained parent Cipher/provider reference; 5 ContentProviderClient;
6 exact remote endpoint capability/death obligation; 7 child callback plus fixed invocation cell;
8 child platform prompt/CancellationSignal graph; 9 child Activity lifetime;
10 arm/readTerminal Parcel.data; 11 arm/readTerminal Parcel.reply;
12 independent terminate invocation; 13 actual terminate Thread; 14 terminate Parcel.data;
15 fixed parent Main terminal/admission invocation with same-Looper FIFO actual-return barrier.

One-way terminate has no reply Parcel. Producer3 performs endpoint/RPC/death observation and actual Cipher consumption sequentially: no extra arm/observer/coroutine worker. Worker12/13 is independent and must be reserved/created before producer start. Children6/7/8/9 remain independently charged until positive remote-process death; process death supplies their common factual acknowledgement, not a cancelled-signal claim. If implementation creates another independently blocking child, this fit is invalid and must deny or phase-retire before acquisition. Parent token must not hide additional provider objects/keys/buffers. Same-Looper barrier only proves the preceding actual Main application callback returned; barrier itself must be bounded internal metadata accounting with no client/native callback/authority promotion.

PREPARATION is a separately audited phase: explicitly claim SecretKey/provider construction temporaries, Cipher partial handle, construction invocation/actual Thread before getKey/getInstance/init/handle extraction. Retain the original owned Cipher, positively retire construction worker/key/temp obligations before AUTH-phase acquisition where combined peak would exceed16. Complete AUTH manifest must be funded before client/RPC/helper auth acquisition. No implicit registration or capacity expansion. Provider construction and normal app-reference quarantine rules remain part of Task3B B; this design is not an exemption.

First implementation batch: pure typed request-process state/protocol model and private platform helper endpoint/Activity, disabled at production admission. Deterministic tests prove single arm, exact id/handle, no reuse, terminal metadata only, cancelled/stale/duplicate denial, explicit process-death facts and no acknowledgment on kill dispatch/timeout. Independent review before parent Native integration.

Second batch: owned synchronous parent endpoint/Parcel/provider phases integrated into existing actual authentication producer; separately funded termination, real Thread join, fixed Main receipt and final original authority admission. Controlled blocking tests hold provider/client/RPC/borrow/termination and verify independent dispatch, charged failures and no Native under ranked locks. Runtime/instrumentation remains mandatory for actual API35 operation-handle auth, remote death, OEM lifecycle and accessibility. Do not automatically enable production from model/compile success or before other Task3B B/C/D acceptance.

## Revision 2 — actual-return correction, supersedes callback protocol below

The initial DeathRecipient/parent receipt callback design below is NOT accepted: a posted Main barrier can execute before a Binder callback actually returns, and finally/in-flight decrement is not positive actual return. A process-wide metadata-only listener cannot silently excuse exact-attempt callback lifetime ownership. Do not implement that protocol as written.

Use a callback-free parent protocol instead:

1. A non-exported ContentProvider in :biometric provides its strongly static one-attempt Binder synchronously through ContentProviderClient.call. The returned Bundle contains only endpoint Binder, never operation handle/key/secret. Exact providerclient and temporary RPC containers have precreation claims; close client after endpoint extraction, outside gates, before further acquisition. No ServiceConnection or parent Binder receipt callback.
2. Existing prefunded actual key-producer Thread performs endpoint acquisition, exact arm/show RPC, synchronous awaitTerminal RPC, process-death observation and original Cipher consumption in sequential phases. Do not add an unowned coroutine/worker to wrap it. Child platform callbacks signal only child-local fixed state. No Main authority references cross the process boundary.
3. Child awaits/replies with a fixed terminal enum, nonce and operation handle. Parent receives this from its own synchronous RPC call; no inbound app callback exists in parent. Child platform callback-return/queue cleanup still requires process death, not receipt.
4. Independent prefunded terminate invocation/actual Thread uses an exact Binder termination transaction. Child terminates its own process. No saved remote PID. Parent uses its original remote Binder's public isBinderAlive(): false documents hosting process not alive. A bounded pacing wait is only scheduling; only observed false is death evidence. No timeout/interrupt turns true/unknown into acknowledgement. Retain charge until observation and worker termination.
5. Producer actual Thread returns; independent cleanup joins it. This establishes actual return of all attempt-bearing parent RPC/provider/Cipher work using existing Thread ownership. A DeathRecipient may not be introduced merely as an optimization without a separate full callback lifetime proof.

Official additional support: https://developer.android.com/reference/android/os/IBinder#isBinderAlive() specifies false if hosting process is not alive; https://developer.android.com/reference/android/content/ContentProviderClient documents supported close(), synchronous call and client thread-safety limits; https://developer.android.com/reference/android/os/Bundle supports putBinder/getBinder. Prefer isBinderAlive over pingBinder because the latter allows an overridden ping return value. Genuine remote/static endpoint identity is mandatory.

Capacity must be re-inventoried for this revision. Do not copy the earlier candidate16 uncritically: arm/await RPC data+reply Parcels and independent cancel data Parcel are real temporary children. A plausible fit uses the existing four-child actual key producer as the sequential IPC/provider producer rather than adding a second arm worker, retires providerclient phase before auth and reserves cancellation invocation/Thread/Parcel independently. Every Parcel.recycle/close return and child construction must be covered; any extra independent children deny admission or require verified sequential phase retirement, never a quota increase. Binder callback omission is a structural elimination, not a generic-owner shortcut.

No runtime evidence has been obtained. Review and implementation acceptance remain pending.

Read-only design investigation against preserved checkpoint 1eabc5875b9c1fd805fb2f699fda9e86684754af. No application source changes or Gradle execution by this reviewer.

## Official supported API evidence

- https://developer.android.com/reference/android/hardware/biometrics/BiometricPrompt.CryptoObject.html : API35 getOperationHandle() and CryptoObject(long) expressly support constructing the CryptoObject in one process, propagating its operation handle, and authenticating in another. Parent retains Cipher; helper receives no Cipher/key/PIN/plaintext.
- https://developer.android.com/reference/android/os/IBinder.DeathRecipient : binderDied reports the process hosting the exact remote IBinder has gone away; callback runs on Binder threads, not necessarily Main.
- https://developer.android.com/reference/android/os/IBinder : linkToDeath remote-process death notification; RemoteException if already dead. Local Binder linkToDeath is a no-op, so production must verify a genuinely remote endpoint, not a same-process fake.
- https://developer.android.com/reference/android/os/Process : public killProcess(myPid()) permits self termination; dispatch is not death acknowledgement.
- https://developer.android.com/guide/components/processes-and-threads : manifest android:process selects separate component processes.
- https://android.googlesource.com/platform/frameworks/base/+/HEAD/core/java/android/hardware/biometrics/BiometricPrompt.java : platform prompt itself retains mCryptoObject, mAuthenticationCallback, mContext; late service callbacks execute through mExecutor. Replacing AndroidX in the same process with a sealed Executor alone does not prove graph retirement.

## Selected candidate

Non-exported plain Activity plus bound Service in one dedicated app-private process :biometric. No AndroidX prompt dependency in helper. One process-global, strongly retained request Binder and exactly one claimable attempt for that process lifetime. No WeakReference/GC retirement. Parent cannot launch a replacement until original process death plus parent-owned callback/worker cleanup are acknowledged.

API26–34 acquisition remains denied before provider construction; minSdk remains26. API35+ is a support candidate, not an enabled path until independent review and runtime verification.

Parent keeps exact original Cipher/operation and creates CryptoObject(cipher).operationHandle on a funded worker. Only a positive nonzero handle is eligible. Neither handle nor credentials go in Intent extras, savedInstanceState, files, logs or notification state. Intents contain only an opaque one-shot random locator. Binder setup carries locator, handle and fixed display enum; no arbitrary prompt data. Helper uses CryptoObject(handle). Parent validates original id/handle/epoch/vault again at actual final admission, never trusts a boolean IPC result alone.

## Exact interface sketch (small fixed transactions)

ParentIngress.offerEndpoint(locator, remoteRequestBinder) -> ACK/REJECT
RemoteRequest.arm(locator, operationHandle, parentReceiptBinder) -> ACK/REJECT
RemoteRequest.show(locator) -> ACK/REJECT
RemoteRequest.terminate(locator) -> never relied on to return; child self-kills
ParentReceipt.terminal(locator, operationHandle, terminalEnum) -> ACK/REJECT

No bytes/arrays/Parcelable CryptoObjects and no exported endpoints. Enforce caller UID, exact attempt id and Binder identity. Retain endpoint Binder statically in child until death; do not allow a temporary Binder to be collected/unexported and mistaken for process death. Parent linkToDeath must complete before arm/show. A death before valid terminal receipt is failure, never success.

Child allows one arm/show only. Additional requests reject and do not create prompt/jobs. All queued child main actions use one prefunded fixed cell; no per-callback Handler post. Platform callback runs through a sealable bounded Executor with at most one accepted invocation, direct duplicate ingress rejection, actual invocation-return accounting and a detachable callback bridge. Saturation fails the attempt and triggers process termination. No timers/queue-delay estimates used as cleanup proof.

Parent terminal transaction only records bounded enum/id metadata, with no authority callback under its gate. A fixed admission cell marshals to Main after its Binder invocation return barrier; it does not allocate an unbounded message stream. A stable process-wide parent Binder ingress may remain, but its exact original target is detached and all in-flight original invocations drain before that original retires. Late old identifiers cannot target replacement records. Do not claim a posted Runnable's finally proves its actual dispatch return.

## Candidate maximum parent physical manifest: 16, must be validated against final source

1 producer result; 2 temporary input; 3 producer invocation; 4 actual producer Thread;
5 app provider/Cipher reference lifetime;
6 detachable original bridge; 7 independent cancel control; 8 parent callback invocation/return; 9 helper host/process-death lifetime;
10 service connection/bind/unbind lifecycle; 11 exact remote death registration;
12 arm/show RPC invocation; 13 actual arm/show RPC Thread;
14 terminate RPC invocation; 15 actual terminate RPC Thread;
16 fixed Main admission/dispatch cell.

All sixteen claims atomically funded BEFORE provider creation, binding, thread creation, handle acquisition, callback publication or launching Activity. No on-demand Thread/Job/executor construction. Arm/show share a single actual worker and sequential bounded command phases, not two independently blocking RPCs. Termination has a different worker/slot and never waits behind arm/show or Main. Host-death waiter must not occupy the cancel worker. Returned workers retire normally and acknowledge actual Thread termination. If an existing production factory needs another independent child, this proposed fit fails: phase it with positively acknowledged retirement first, or deny before creation; never enlarge capacity or hide it in an outer token.

The existing four UI obligations remain separately charged. The child process is the physical retirement boundary for its Activity, prompt reference graph, callback bridge and queued invocation, not a claim that Cancel retires those objects. The final implementation must explicitly inventory them against the four obligations and ensure no further independent cleanup action is concealed. If reviewers find additional independently blocking children, the sixteen-slot proposal is not accepted.

## Cancellation, failure and partial construction

- Parent revoke first seals/detaches authority and records cancelled; it dispatches terminate on its separately funded actual worker outside ranked locks. It retains ownership until exact binderDied and all parent callback/RPC/worker acknowledgements finish.
- Child terminate validates exact locator and calls Process.killProcess(Process.myPid()) from the original Binder transaction thread. Never kill a stored remote PID: replacement PID reuse is unsafe. Do not depend on Main processing cancellation or CancellationSignal.cancel returning.
- Child successful callback posts only bounded terminal metadata; parent receipt does not grant authority. Once received, child terminates itself. Parent uses its Cipher only after required original helper/callback cleanup barriers. Interrupted terminal delivery or premature death denies success.
- bindService false/throw before any dispatch must be distinguished from uncertain entered dispatch. A known no-acquisition path can release unused claims only after exact owned invocation return. Unknown launch/bind outcome remains charged; no timeout-based fake success.
- Late onServiceConnected after revoke must never arm/show. It attaches the exact late endpoint to original ownership, links death if possible and requests that exact helper terminate. It cannot cancel a replacement endpoint.
- linkToDeath failure before arm/show means no authentication starts. RemoteException indicates endpoint death, but original still requires owned bind/IPC/callback cleanup acknowledgement. Do not infer success or silently start without death watch.
- If helper starts but endpoint never arrives, no authentication is allowed. Keep uncertain process/bind ownership charged and deny replacement. Cleanup is a concrete missing acknowledgement, not an excuse to reuse capacity.
- Any failed terminate call without exact death remains charged. Parent app death naturally removes all parent authority; helper monitors exact parent Binder death and self-terminates. No persistent credentials/handles are restored across either process restart.

## Activity and lifecycle

Helper Activity is non-exported, secure-window, translucent and uses supported platform system biometric UI. Activity receives opaque locator only, claims once from helper static state and calls super.onCreate(null); saved/recreated instances fail closed. No ViewModel or Fragment restoration. Plain Activity avoids AndroidX graph.

Transparent launch can pause Main. Do not broadly bypass vault lock or ignore arbitrary backgrounding. Only the exact admitted one-shot host may explain a pause while Main remains STARTED; Main onStop still revokes and terminates. Unexpected helper onStop, configuration replacement, screen-off/actual background or parent death cancels original. Helper Activity onDestroy alone is not retirement: require process death. Test OEM Fold/multiwindow/accessibility behavior; do not assume translucency always keeps Main started.

## Admission and lock rules

No bind/unbind, Binder RPC, process termination, provider calls, Thread join or callback dispatch while ranked root/controller/authority gates are held. Gates only detach bounded state and recheck exact original revision/epoch/selected vault. Final authorization additionally requires valid terminal receipt, original Cipher still owned/borrowable, helper death, all mandatory app-owned retirement complete/nonfailed, bounded capacity and correct current vault. A stale success receipt cannot promote credentials.

## Required verification before ENABLED

Deterministic host tests: late endpoint after revoke, failed death link before show, old endpoint and duplicate/replaced receipt, actual RPC worker held while independent terminate runs, death before receipt, receipt before death, missing death retaining charge, parent callback held across death, Main admission cell held across revoke, cancellation/failed cleanup/capacity denial, no self-join or Native under ranked locks.

Android instrumentation/runtime is necessary for genuine remote Binder identity, actual death-versus-callback ordering, operation-handle cross-process authentication, framework/OEM terminal behavior, child Activity lifecycle, Main translucency/background auto-lock, accessibility and repeated process restarts. JVM fakes and Android compile cannot demonstrate these. With no supported runtime environment, keep production gate disabled and report implementation unaccepted; do not widen the Keystore exception.

Residual risk: Android-internal Keystore operation lifetime remains platform-managed under the sole approved exception. Process death proves child app graph retirement, not Keystore or biometric system-service internal hardware retirement.
