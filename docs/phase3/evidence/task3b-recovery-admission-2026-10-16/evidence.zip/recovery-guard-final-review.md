# Independent recovery guard / PIN snapshot final source review

Repository: /workspace/scratch/0881340dd615/private-gallery-task3-recovered. Reviewed current working production and tests; read-only, no Gradle or device execution. Root's focused run was still active. Root reports earlier Debug1340 and Phase01347 JVM passes but loss of execution before lint; those earlier results are not a current complete validation PASS.

## Scoped disposition

No introduced blocking defect established in the new exact-attempt recovery guard or PIN snapshot seam. Source acceptance is conditional on verification of these exact files; full Task3B A–D remains unaccepted.

PrimaryRecoveryAuthentication.kt now creates a mutate(action) capability only inside its original branded preparation callback. It binds the exact PrimaryAuthAttempt and invoking Thread, rejects foreign Thread use before reading active state, marks one use before checking preparation/invoking the action, and seals the capability in finally on every factory exit. This prevents repeated, reentrant, late and foreign-thread invocation. An already-revoked/expired original fails checkPreparation before the callback's effects. MainActivity.recoverWithOfflineKey invokes it inside the existing original UI-attempt commit, so both checks refer to their captured original identities; there is no ambient replacement lookup. The actual action runs after the Primary authority check has returned, so this adds no Native execution under the Primary gate.

Input/result cleanup remains unchanged: the actual recovery/new-PIN buffers are retained through the synchronous producer, positive new-PIN retirement precedes the sole-result authority boundary, and late/invalid results are denied and wiped. The four new regressions observe zero effects on expired/revoked-original rejection, one valid effect with late/repeated/foreign callbacks rejected, and the explicit residual check-to-write case. The last case intentionally observes a mutation finishing after revocation while final session admission fails; this is honest evidence of a remaining limitation, not a test proving full durable-command authorization.

PrimaryPinSnapshot.kt reads one preferences.all record, builds the encrypted envelope from that record and executes unwrap outside the application's preferences monitor. PinVaultKeyStore.unlock delegates to it. It rejects an inherited monitor before read/KDF and wipes the caller PIN on every exit. PinEnvelope.unwrap already consumed/wiped the caller PIN, so this does not introduce a new successful-path ownership change. Actual callers reviewed include Main authentication, sensitive temporary-key verification and PrimaryKeySlots.changePin's copied old PIN.

The snapshot tests observe one read, original record consistency across a concurrent writer, monitor-free KDF, writer progress while KDF is held, malformed/missing record rejection and input cleanup on read/unwrap failure. They explicitly use a detached-map fake corresponding to the inspected Android SharedPreferencesImpl behavior; no general detached-map guarantee or Android/OEM runtime pass is inferred. Returning the original snapshot's key while a writer updates preferences is intentional at this leaf; the leaf itself supplies no final authentication authority.

## Mandatory limitations retained

- mutate still checks before a legacy action that creates its PIN envelope/KDF/editor and performs persistence afterward. Revocation between check return and actual write remains possible; exact prepared-command ownership, overlapping writer exclusion and defined durable completion/restart semantics are still Task3B D requirements. Native preference work under the existing UI-attempt/preferences monitors also remains a separate C obligation. Do not present the new guard as full D.
- PrimaryPinSnapshot's encrypted decoded arrays, snapshot/provider/KDF/Cipher children and partial-construction cleanup are not a complete prefunded manifest. This is a monitor/snapshot improvement, not full B, and the code comment says so. Caller original result ownership does not automatically own all implicit children.
- Existing pending copies/display buffers, outer queued work, complete fixed16 capacity proof, root-held Native cleanup and unsupported AndroidX lifetime remain mandatory. Biometric production admission stays disabled. No exception beyond inaccessible Keystore-internal retirement is introduced.

## Reviewed file fingerprints

| File | SHA256 |
| --- | --- |
| MainActivity.kt | ef7edb3aa4a92184513f26b2955d56dfc388efc8a404f41db97c7eb034af1a2f |
| PrimaryRecoveryAuthentication.kt | 5afda78131c615c5e8f0140a5147a2699e74b9e8cf5b7d9a0e226ff6c7d99e3e |
| PrimaryPinSnapshot.kt | 27abc3d02c447dae1dc83006dcc0de24f19119b10f38ecd7202581ce3871c909 |
| PinVaultKeyStore.kt | 57d34cb689a5d77450d9aae277936cf89c598ae55ffadda796eeca588d14c0a9 |
| PrimaryRecoveryAuthenticationTest.kt | 15610aec537a697d2ca6475abda2eb8f765dd2fca91154991d972679acae0afd |
| PrimaryPinSnapshotTest.kt | 1f57f9405f16a02e0e0b02f46e72ec6bd35001d4499abc950261c82ee0eb6dfc |

No source/test edits were made by this reviewer. Current focused execution, broader required checks and production Android runtime evidence must be attributed separately when available.
