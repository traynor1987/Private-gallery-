# Task3B current independent acceptance review

Repository: /workspace/scratch/0881340dd615/private-gallery-task3-recovered.
Reviewed HEAD ffe15fffba00857caa31c564ccee8d59c3c2d3f4 plus the current uncommitted Primary recovery input/result delta. Read-only production/test inspection; no Gradle, device execution or production edits. This report is an acceptance assessment, not a new passing test result.

Delta fingerprints:
- MainActivity.kt: a1c0bca2e9c99f32d6ab5d3500c08ed3818dc8b926deaa0e18fa4ae5758540e3
- core/security/PrimaryRecoveryAuthentication.kt: 90a6ad999ab8f09d46f0c49af948bd93ff18e7f91a73022ae7ca1ed9b494bbee
- PrimaryRecoveryAuthenticationTest.kt: bc8b0fe62e360db69524dc4566a10e05b0e9f2621740d8d3aac9e202ce38378c
Paths below are relative to app/src/main/java/uk/co/traynor/privategallery unless marked otherwise.

## Acceptance by blocker

| Blocker | Actual implementation | Acceptance |
| --- | --- | --- |
| A: isolated, acknowledged production prompt lifetime | Fresh dedicated host/slot/core original exists; unsupported AndroidX acquisition is fixed-denied before Cipher/Keystore creation | NOT ACCEPTED. Safe containment and biometric unavailability, not working lifecycle retirement |
| B: every application resource preowned, fixed16, actual cleanup | Branded authentication key/input/worker, pending originals, temporary Native input, some exact invocation and directory lifetime units implemented | PARTIAL/BLOCKED. Outer queues, copies, provider/store children and whole-path capacity remain |
| C: Native cleanup outside prohibited ranked gates | Prompt leaf/worker cleanup, pending waits, prepared selection rename, recovery record read and biometric preference write improved | PARTIAL/BLOCKED. Root-held Native directory IO/cleanup and broader credential persistence still remain |
| D: exact original final admission after mandatory cleanup | Sole branded key result barrier, selected-store proof, original attempt/epoch checks, pending/provider retirement waits implemented | PARTIAL/BLOCKED. Unmanifested surrounding obligations and recovery durable mutation boundary remain |

Only inaccessible Android-internal Keystore retirement has the owner's exception. AndroidX Handler tasks, application wrappers, queues, arrays, provider calls and actual worker returns have no exception. No requirement below is deferred to Task3C.

## A: contained unresolved AndroidX lifetime

core/security/AndroidXBiometricRetirementSupport.kt fixes available=false. OriginalBiometricLifecycle.kt rejects nonacknowledging backends before state/manifest/acquisition; OriginalBiometricActivity.kt's Android backend and attachment also deny. Main and Primary/Hidden provider entrypoints check before new Cipher/Keystore work.

The reason is substantive: cached AndroidX biometric1.1.0 BiometricFragment delayed tasks strongly retain fragment/model/CryptoObject beyond Activity destruction. Framework callback executor ingress is not publicly quiesceable. ViewModelStore.clear, a timer, a weak reference, or an old bridge's inability to affect replacements does not prove application graph retirement. Device/runtime evidence is absent. Completion requires a supported audited adapter controlling queue ingress, actual return and reference detachment, then cancellation/recreation/background/old-callback/partial-acquisition tests on the production runtime. Keep current denial until then.

## B: scoped ownership does not establish the complete manifest

Implemented and preserved:
- core/security/OwnedAuthenticationKey.kt and both authorities preown original result/input/invocation/actual Thread; actual join and secondary-child retirement precede sole-result admission.
- core/domain/PendingSetupResources.kt, security/PendingSetupBuffer.kt, ReleaseReservation.beginPendingBuffer, DomainSnapshot.PendingSetup preclaim initial master+secret or replacement secret, seal exact ingress, preserve active borrowers, and wipe/ack after actual return.
- Primary/Hidden enrollment temporary-key leaves copy under exact operation admission, borrow outside the gate, and await positive wipe acknowledgment.
- Recovery record read and PrimaryBiometricPreferenceWrite have prefunded synchronous invocation receipts.
- New PrimaryRecoveryAuthentication.kt: one new-PIN input original plus the existing branded three-child result/recovery-input preparation; both caller inputs retire before final exact key admission. No raw recovered key is returned to Main for a later open.

Still mandatory:
1. core/domain/SecondaryController.kt:563 submit constructs and queues generic Executor work/captured inputs outside a complete original-work contract; prepareVerified:502 owns the leaf Thread, not the enclosing Runnable's actual return.
2. MainActivity.kt biometric lifecycleScope orchestration remains unfunded (currently unreachable by fixed biometric denial); backup/restore and other authentication preparation must also retain exact complete worker/input ownership.
3. DomainSnapshot.PendingSetup.masterCopy/recoverySecret, SecondaryStore.kt:112/187 confirmation copies, and controller takeRecoveryDisplay:157 output CharArray are not covered by the pending two-cell manifest. Their copied arrays need their own actual preattached owners or elimination.
4. SecondaryStore credential KDF/Cipher/record/readback children, SecondaryDirectoryHandles.kt:63/112 actual directory acquisition, and Primary recovery PIN-envelope/provider/editor/derived buffers remain incomplete. Passing a callback to a funded result factory does not fund all implicit children.
5. No complete per-production-route fixed16 manifest or worst-case concurrent capacity proof was found. Current bounded child counts are scoped evidence; capacity rejection must happen before every unowned acquisition, with partial-construction and late-return failures retaining the same charge.

## C: improved source must not be described using obsolete defects

PrimaryKeySlots.persistBiometricEnrollment now calls persistPrimaryBiometricPreferences rather than wrapping preference commit in operation.commit. PrimaryBiometricPreferenceWrite.kt:30 prepares outside authority, admits exact editor metadata briefly, performs commit outside authority, retires actual invocation and separately rechecks epoch. Legacy enrollment wrapper now uses owned envelope/temporary input and checks after cleanup. These prior scoped defects are fixed; do not continue reporting the old direct gated biometric doFinal/save path as current.

SecondaryStore.confirm/confirmReplacement now await pending originals after leaving root serialization; replacement rechecks its original operation. SecondaryDirectoryHandles has improved scoped access/retirement handling, while prepared rename keeps only the relative publication inside inner gates.

Remaining C: SecondaryStore still holds root rank4 around calls into directory/channel opening, verification, sync and close (e.g. create/resume/confirm/mutate/withOriginalSelected); SecondaryDirectoryHandles.withPinned:21, withDirectory:38, open:105 and close:198 do not acquire complete per-handle originals and move Native teardown outside root. A short inner authority gate does not excuse its outer root gate. Primary credential persistence still includes PinVaultKeyStore.replacePinForRecoveredVault:49 and save:76, recovery preference provider paths and inherited synchronous UI-attempt commit. Completion requires held actual Native-close/provider tests proving no root4/controller6/authority7/8 inheritance, without weakening selected-predecessor serialization.

## D: key admission is stronger; durable recovery mutation is still separate

SecondaryController.promote:514 uses store.withOriginalSelected plus exact sequence/attempt and branded handoff admission. Both authorities require the sole original result after other funded children retire. Pending replacement confirmation now waits outside root before success. These scoped barriers remain correct.

Current recovery delta improves final session-key admission but does not bind the durable PIN mutation to its exact PrimaryAuthAttempt:
- MainActivity.recoverWithOfflineKey:839 calls authority.authenticateRecovery, whose attempt is private to the helper.
- Its factory calls PrimaryKeySlots.recover:75 with only authenticationAttempts.commit(UI attempt).
- That callback executes PIN-envelope replacement and biometric disable before the helper's post-factory authority/deadline check.

Thus a Primary attempt may expire (or be revoked independently) during recovery work while the UI token stays current; credential mutation can execute before final key admission is denied. The helper's timeout test uses a synthetic factory returning a key, so it proves rejected session admission, not rejected durable credential mutation. This is a concrete remaining D/persistence requirement, not a claim that final owned-key admission bypasses its check. Expose a narrow exact-attempt mutation admission integrated with prepared durable commands and nonoverlapping mutation ownership; do not solve it by moving Native persistence back under an authority gate or by treating post-return rejection as rollback of durable writes.

Required tests: block preparation, expire/revoke exact authority while keeping UI token current, release, and assert no unadmitted durable command; separately race revocation after command admission, require defined durable state without stale retry, deny success and prevent replacement overlap until actual return. Hold actual release callbacks after their internal stage completes to verify final success remains denied. Final whole-path D also cannot pass until the B resources are actually owned and retired.

## Evidence and next seam

Previous narrow checkpoint reports record passing component/race tests and Android test compilation for pending ownership; those are scoped historical evidence. Current PrimaryRecoveryAuthenticationTest covers input/result wiping, held borrow/revocation, timeout, invalid key, capacity rejection, held cleanup callback return and repeat capacity recovery. It does not execute real PrimaryKeySlots durable persistence. No new run was executed by this reviewer, and no device/OEM acceptance is implied.

Safely implementable next seam: eliminate or explicitly preown Hidden confirmation master/secret copies at SecondaryStore.confirm/confirmReplacement and DomainSnapshot.PendingSetup accessors, using the established typed original borrower/result patterns. Fund before copying, preserve the actual input through Native return, retire nonresult copies outside root before promotion, and retain selected-generation plus exact attempt/epoch admission. Add held-copy/Native-consumer cancellation, late result, partial-construction, failed cleanup and fixed16-capacity tests. Keep display CharArray/outer queue explicitly open until separately migrated.

The recovery durable-mutation issue above should receive its own prepared-command/transaction seam and real-store test before any full D claim; it must not be hidden by completing the narrower copy seam. The larger async queue ownership and AndroidX boundary require separate rigorous work. Do not re-enable biometrics, advance Task3C, or claim full Task3B acceptance from this review.

Overall: Task3B PARTIAL; A, B, C and D each retain acceptance blockers.

