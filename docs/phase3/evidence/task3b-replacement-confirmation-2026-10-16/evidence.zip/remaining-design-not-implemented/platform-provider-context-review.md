# Task3B provider-only API35 biometric host — source review

Decision: SUPPORTED implementation candidate with conditions below. No helper Activity or startActivity is required by the public platform API. This is source/API review, NOT Android/OEM runtime acceptance. Production admission remains disabled.

## Exact primary-source evidence

1. Public Builder(Context), with no Activity/UiContext restriction:
https://developer.android.com/reference/android/hardware/biometrics/BiometricPrompt.Builder
Pinned Android15_r1 BiometricPrompt.java179–182 merely stores Context. Native authenticate passes package/user/receiver to AuthService; it does not request an Activity window token. Use helper Application Context, platform system biometric UI and BIOMETRIC_STRONG only.

2. Exact process foreground restriction exists:
Pinned Android15_r1 AuthService.java273–299 captures callingUid and callingPid and checks Utils.isForeground(uid,pid). Utils.java524–545 requires exact PID and UID plus importance<=IMPORTANCE_FOREGROUND_SERVICE. SameUID foreground Main alone is NOT enough.

3. Keeping a provider dependency supplies the supported process relationship:
https://developer.android.com/guide/components/activities/process-lifecycle
The guide documents provider-host process classification as at least as important as its using client process. Pinned OomAdjuster.java3154–3174 maps TOP provider client to BOUND_TOP and raises provider procState. ActivityManager.java3904–3923 maps that state to FOREGROUND, satisfying the biometric threshold. This relationship requires a LIVE client; closing the client immediately after endpoint extraction could drop it.

4. Public cross-process handle use:
https://developer.android.com/reference/android/hardware/biometrics/BiometricPrompt.CryptoObject.html
API35 getOperationHandle / CryptoObject(long) explicitly support cross-process authentication. No Cipher, PIN, key or plaintext enters helper.

5. Unstable provider client and supported close:
https://developer.android.com/reference/android/content/ContentResolver#acquireUnstableContentProviderClient(android.net.Uri)
https://developer.android.com/reference/android/content/ContentProviderClient
Use UNSTABLE client: helper death must not kill dependent parent. Keep the original owned client alive throughout authentication and exact helper-death observation; close it only after its RPC calls have returned, on the original owned actual worker, outside ranked locks. Do not close concurrently with a client operation. Actual close return retires this application client connection; it does not prove child death.

6. Exact process death:
https://developer.android.com/reference/android/os/IBinder#isBinderAlive()
https://developer.android.com/reference/android/os/Process
Exact genuinely remote static endpoint isBinderAlive false proves hosting process not alive; own actual worker return/join retires parent uses. Helper kills only Process.myPid(), never stored remote PID. It does not use Activity.finish, cancellation dispatch, callbacks or GC as death acknowledgement. Android-internal Keystore lifetime remains the sole approved platform-managed exception.

## Minimal shape

- Non-exported ContentProvider android:process=":biometric"; no Activity, ServiceConnection or ViewModel. Endpoint is a process-static strongly retained Binder, admits exactly one opaque attempt during that process lifetime. No vault/session authority or new resource partition initialized there.
- Parent funds exact preparation/AUTH phases before acquisition. It synchronously obtains an UNSTABLE client and endpoint, retains client, arms exact id+nonzero operationHandle over Binder, invokes show/readTerminal and independently invokes terminate. Endpoint Bundle contains only Binder. Handle never enters Intent/Bundle/savedstate/log/files.
- Helper builds platform BiometricPrompt(applicationContext), explicit title/negative Cancel, allowed authenticators BIOMETRIC_STRONG, operationHandle-only CryptoObject, owned CancellationSignal and bounded callback Executor. API35 USE_BIOMETRIC is a normal manifest permission. No device-credential fallback or advanced/private permissions.
- Bounded direct Executor is acceptable in child if its callbacks only update original fixed primitive metadata and never block/reenter Native/provider/authority. If posting instead, use an explicitly inventoried fixed cell; no per-callback allocation/fan-out. Child app callback/prompt/queued graph remains charged until exact process death, even after callback success.
- readTerminal is bounded metadata snapshot, not a child Binder-thread blocking wait. Parent's original actual producer Thread paces polls. Separate funded terminator invocation/Thread/one-way Parcel never waits behind producer or Main. Parent has no receipt Binder callback, DeathRecipient, callback subscription or launch Intent.
- Parent Main remains in existing foreground/session lifecycle. No onStop bypass. Actual Main background/recreation/session revoke invalidates attempt and independently terminates helper; final original epoch/vault/sequence checks remain mandatory. System biometric overlay/OEM Activity behavior must be tested rather than assumed.
- Retain provider-client dependency through childdeath. An AuthService foreground rejection is ordinary failed authentication, never a permission/foreground bypass or reason to start a foreground-service workaround.

## Capacity effect

Remove the earlier helper Activity child and all Activity launch/locator/recreation obligations. Retaining providerclient does not add a child: it was already explicit in candidate16. Keep separate remote endpoint lifetime, prompt/CancellationSignal, child callback/queue, parent producer/key/input/result, actual terminate worker/Parcel, parent RPC data/reply and fixed Main admission cell accounting. Re-inventory provider partial construction and secret copies; the freed Activity slot is not permission to hide a child or expand quotas.

## Runtime gates and limitations

Public API shape and pinned AOSP code support the candidate. No physical/emulator runtime test has occurred. Required instrumentation: parent TOP process actually promotes retained unstable-provider helper, platform API35 cross-process operation-handle success, Main remains correctly lifecycle-gated under system overlay, screen-off/background revokes, helper kill does not kill parent, old Binder cannot attach to restarted helper, queued callbacks cannot escape childdeath, repeated cancel/retry, accessibility/TalkBack, Samsung Fold multiwindow. OEM denial is safe failure. Do not claim these passed or enable production solely from JVM/compile success.

## Pinned source preservation

Fetched exact official tag android-15.0.0_r1 (commit4e43ad12e1b211f15152e9c5b16b0fe88e6b93f3) through Googlesource ?format=TEXT; decoded bytes retained at api35-platform-source/ under this cache directory:

- BiometricPrompt.java SHA25625a81188ea9f2b23c28c4fe614ace1b2fe35a009b4afd011f1608ea7d6873dea,65567 bytes
- AuthService.java SHA25628d0b91df53d106517aef4c556f2423a113925ba330c93b7e6bd86ada5a62dd0,45880 bytes
- Utils.java SHA2568a8a5367698aa71e743d5727d699484e81f0c52d98b5de7aa199529d3880b331,26403 bytes
- OomAdjuster.java SHA256b18d7e6340235c82c6b73c5e53b703fa0070ce8043d112afd13f3d6a9e1b495f,195257 bytes
- ActivityManager.java SHA2561f87c9df2f0b6ae818a3e28bed8b6aaf1493768efd691470d3a1a440dca6f2e4,253618 bytes

URL prefix: https://android.googlesource.com/platform/frameworks/base/+/refs/tags/android-15.0.0_r1/ followed by core/java/android/hardware/biometrics/BiometricPrompt.java; services/core/java/com/android/server/biometrics/AuthService.java; services/core/java/com/android/server/biometrics/Utils.java; services/core/java/com/android/server/am/OomAdjuster.java; core/java/android/app/ActivityManager.java respectively.
