# Task5 bounded provider-process integration design — NOT ACCEPTED / DISABLED

Source-only review of current recovered app. No application source edits, Gradle, runtime tests or acceptance claim. Read with platform-provider-context-review.md and task3-coordinator-design.md. This supersedes my earlier suggestion of automatic result-owned Main admission: that suggestion has no established contract exemption and must not be implemented as accepted.

## Current source that cannot simply be wrapped

- MainActivity.unlockWithBiometrics creates Cipher before prompt ownership, creates old UI original4, then an unowned lifecycleScope IO coordinator, then exact ThreadAuthenticationKeyFactory4. enrollBiometrics/authenticateSensitive likewise have outer coroutine/withContext obligations. Those jobs are not owned by the inner actual worker.
- SecondaryController.prepareBiometricUnlock/enrollment retain exact provider/slot[/operation] request originals3; unlock retires its envelope child before request publication. completeBiometric uses another generic Executor submit around prepareVerified, which itself creates exact auth4. Full implicit provider/snapshot/store children are not covered by the outer request wrapper.
- OriginalAuthenticationKey.hasAuthenticationLayout accepts only private synchronous3 or ThreadAuthenticationKeyFactory4. consumeAuthenticationHandoff requires original nonresult children successful and final authorities require only this result original. Do not append process children to this four-child original or exempt a live coordinator.
- Old OriginalBiometricLifecycle four-child AndroidX UI original is replaced for this new path, not retained alongside it. The old test/compatibility backend may remain isolated; production availability stays false.

## Supported platform boundary

API35+ private non-exported ContentProvider in :biometric process; no helper Activity, Intent, ServiceConnection, ViewModel, inbound parent Binder callback or DeathRecipient. Helper has a process-static strongly retained one-attempt endpoint; no vault/session authority, key, PIN/plaintext, separate cleanup partition, restartable request, or generic job executor.

Parent opens UNSTABLE ContentProviderClient synchronously on its funded actual producer and retains it until helper death. Application Context is supported by platform BiometricPrompt.Builder. Active provider-client dependence promotes helper PID appropriately while Main is foreground: see exact Android15 source and official URLs in platform-provider-context-review.md. Same UID alone is not foreground authority. Keep all existing Main onStop/session-lock revocation; no lifecycle bypass.

Endpoint Bundle contains only IBinder. Parent sends exact nonce and nonzero operationHandle through fixed private Binder transactions. Parent Cipher remains in its own preowned quarantine cell. Child CryptoObject(operationHandle) invokes BIOMETRIC_STRONG only; no device credential or private APIs. App-controlled child callback/prompt graph retires only at exact helper process death; Keystore internal exception unchanged.

Protocol: openEndpoint -> arm(nonce,handle,displayEnum) -> show(nonce) -> repeated nonblocking readTerminal(nonce) -> independent one-way terminate(nonce) -> originalRemoteBinder.isBinderAlive()==false. Parent polling delays only pace scheduling; neither timeout nor cancellation nor terminal receipt is acknowledgement. Child readTerminal never waits on a Binder thread. Only one arm/show per process lifetime. Child terminates itself with killProcess(myPid()), never a stored remote PID.

## Required typed signatures

Suggested names indicate security shape, not an already implemented API:

    prepareOwnedPrimaryCipher(owner: BiometricOriginalOwner, mode: PrimaryBiometricMode): OwnedPlatformCipher
    prepareOwnedHiddenCipher(owner: BiometricOriginalOwner, spec: ExactHiddenBiometricSpec): OwnedHiddenBiometricRequest
    startProcessBiometricAuthentication(authority, originalAttempt, preparedCipher, producerSpec): PendingProcessAuthentication
    OwnedProcessBoundary.authenticateOnOriginalProducer(cipherBorrow, nonce, displayEnum): ProcessReceipt
    PendingProcessAuthentication.tryClaimReady(originalAttempt): OwnedAuthenticationKey?
    SecondaryController.finishPreparedBiometricAuthentication(): Boolean
    MainActivity.finishPreparedPrimaryBiometricAuthentication(): Boolean

No Cipher getter on PendingProcessAuthentication, no public raw-key result, no generic lambda taking arbitrary resource handles. Cipher borrow is synchronous, once-only and exact original. ProducerSpec is a closed trusted set: PrimaryUnlock, HiddenUnlock, PrimaryEnrollment, HiddenEnrollment, PrimarySensitive; not an arbitrary asynchronous callback. ProducerSpec's provider/store/secret children must be declared separately before implementation of each family.

## Precreation phases and physical census

Phase P, provider preparation: reserve explicit actual construction worker/invocation, KeyStore/SecretKey/provider references, partial Cipher and every nonce/snapshot/temp buffer BEFORE getInstance/getKey/generate/init/copy/decode/operationHandle. Attach immediately after each actual partial acquisition. Retire phase-only key/provider construction temporaries and actual construction worker outside all ranked gates, positively acknowledge before phase R. Retain exactly owned Cipher/request. Existing BiometricVaultKeyStore.key/cipher and AndroidSecondaryBiometricKeys do not supply this contract yet. Do not pretend a Cipher wrapper automatically owns their implicit providers. This is a mandatory production prerequisite.

Phase R, request-process use: a separately reserved exact NINE-child original, before acquiring provider client/endpoint/Parcels/terminator or creating child prompt:

| Child | Resource / independent obligation |
| --- | --- |
| client | unstable ContentProviderClient; actual close after its uses return |
| endpoint | exact remote Binder capability and positive hosting-process-death observation |
| prompt | helper platform prompt/CancellationSignal application graph |
| callback | helper bounded callback invocation/queued cell graph |
| rpc-data | parent arm/show/readTerminal outgoing Parcel |
| rpc-reply | parent arm/show/readTerminal reply Parcel |
| terminate-invocation | independently admitted cancellation RPC invocation |
| terminate-thread | actual independent termination Thread, joined after actual return |
| terminate-data | independent one-way termination Parcel; no reply Parcel |

Children endpoint/prompt/callback are separately charged and acknowledged against factual same-process death, not bundled into one physical token. They do not require separate native cancel calls that could block each other: death retires all child app objects. Individual child prompt construction state is still tracked: known-not-created is acknowledged only after exact constructor exit; late construction under revoked original never publishes. No extra handler/executor worker is created in child; a bounded direct callback executor only mutates primitive original metadata. A queued child executor requires explicit extra inventory and may invalidate this fit.

Retained results/input/invocation/actual producer Thread use the EXISTING FOUR-child authentication layout. Parent original producer3 does all endpoint acquisition, synchronous RPC, exact process-death observation and actual Cipher consumption. No second arm/observer worker, generic executor or implicit coroutine may be introduced. Process R cannot include or replace the auth result original. Native producer must bind/wipe late key output through its original result cell, including exceptions after doFinal; Native result preallocation/sink is preferable to unbound factory-local output escaping on later failure.

Peak conservative Hidden request: retained request3 + authentication4 + process9 =16. The already retired unlock-envelope slot makes actual live count smaller but is not needed for this conservative ceiling. Phase-P implicit provider/snapshot extras MUST have retired first. Existing enclosing Executor coordinator cannot be retained in this peak. For Primary, retained Cipher1 + authentication4 + process9 =14, leaving at most2 for an explicit coordinator; no room for undeclared jobs/providers/buffers.

After process9 retires, native consumption and all retained request/provider/temporary/store obligations must retire, then auth nonresult3 retires. Final parked result1 remains. Main UI receives only secret-free pending metadata. Any independently owned publication message/job must retire before final admission; do not use a callback retaining the result to bypass sole-result admission.

## Necessary async-four-child seam, not present in current code

Hidden cannot fit request3 + auth4 + process9 plus an extra outer Thread/Job. Introduce a narrowly branded async variant of the same exact four-child auth factory, rather than enlarging final-handoff layout. The construct phase attaches result/input/invocation/inert actual Thread before start and returns a private PendingProcessAuthentication facade immediately. It exposes readiness metadata only; no authority or raw result.

The producer starts once under its own start/revoked gate. Cancellation-before-start seals that exact Thread, never starts late. Producer finally only REQUESTS normal nonresult retirement; it is not actual return acknowledgement. Independent already reserved worker child closes/joins actual producer. Input and invocation have independent completion, preserving borrower-return wipe ordering. Pending facade becomes claimable only when result production finished and all nonresult actual supported acknowledgements AND release-method returns are successful. Hold the Thread tail in a regression to prove finally/request cannot make it ready.

ReleaseReservation.retirePhase currently requires constructor thread. Therefore a new private typed postconstruction retirement entry point is required, limited to exact private async factory identity, original reservation, expected four-child shape and nonresult indices. Never expose generic public phase retirement, unchecked indices, new manifest sizes or a blanket current-attempt exemption. Preallocate all phase signals/flags before Thread creation. A producer finishing while its constructor still runs must wait through bounded construction-return metadata before dispatching retirement; no late attachment.

This seam is a real prerequisite, not existing verified source. Independent review/TDD required. Existing synchronous ThreadAuthenticationKeyFactory and Task3A consumers remain unchanged unless an exact shared invariant demonstrably requires modification.

## Final caller: conflict resolved conservatively

Earlier argument FOR automatic Main message: CB1 permits bounded result-handoff metadata, so a result original could retain one preallocated metadata-only message, keeping its ticket charged through actual return even after key transfer. That avoids arbitrary callback hooks and cancel/retry queue flooding.

Decisive argument AGAINST treating this as accepted: CB1 clause2 includes app-created callbacks/queues; clause5 requires actual return; lines153–168 require all producer/prompt/provider/temp obligations quiescent and prohibit self-dependent promotion Jobs. The message is created for this attempt and is live when it admits. Existing source supplies no exception equating it to already-retired metadata. Keeping its ticket charged until later return does not satisfy pre-admission quiescence. Do not implement that as accepted or extend the owner's Keystore exception.

Use the conservative endpoint in task3-coordinator-design.md: a later real framework user Continue/Unlock click into a stable zero-argument facade. It creates no new perattempt Job/post/timer, captures no pending key/attempt/proof, synchronously checks parked original readiness and final authority/vault/sequence, then consumes sole owned result. Immediate clicks while actual retirement incomplete return neutral pending, no waiting on Main. Old action references remain inert after revoke. Root/product choice of this small extra interaction must be explicit in implementation.

Final action must be Native-free apart from the separately permitted existing short authorization boundary. Existing Hidden promote still calls store.biometricRecord/withOriginalSelected with real storage preparation. That Native/selection phase must be staged under its exact owned store plan and current revision guard before final click; never remove selected predecessor validation or cache disk state without a complete serialized-writer proof. This remains Task3B B/C/D, not future-phase work. Main replaceBrowserSession/reconcileAfterUnlock/recovery preparation likewise cannot be smuggled into a supposed Native-free finalizer; subsequent operations require new authenticated owned operations.

## Actual retirement order

1. Reserve all Phase-P children before provider work; construct/attach inert partials; complete actual provider-preparation worker return/join and temporary wipe. Retain original Cipher/request only.
2. Reserve auth4 and process9 under same exact attempt (not same original); perform source/capacity checks before start. No production acquisition if any manifest cannot fit. Reject late factories under original token.
3. Original producer opens unstable client and attaches it before call; obtains exact endpoint and attaches before next throwing step; constructs/attaches data/reply Parcels before writing operation handle; arms only after original owner/vault check.
4. Arm/show/readTerminal outside all ranked gates. Child never owns authority. Main background/revoke signals independent terminator. Producer cannot borrow Cipher after revocation. A borrowed Native call retains its key input until actual return.
5. Terminal success alone does not promote. Independently terminate exact helper, observe isBinderAlive false. Retire child endpoint/prompt/callback facts. Recycle data/reply after actual RPC return; keep terminate Parcel until its own invocation returned; join actual terminate Thread. Close retained unstable client after all client calls returned, outside locks. Wait original process9 terminal accounting, no future/dispatch shortcut.
6. Consume parent Cipher via original borrower only if still authorized; or if design consumes before killing helper, still wait all process retirement before final handoff. Wipe temps after actual Native return; close/quarantine provider/request and observe original positive supported app-handle/alias cleanup. Never claim internal Keystore close.
7. Producer finishes; nonresult3 retires through independent actual Thread join. Parked result ready only after all mandatory other originals terminal/nonfailed. No admitted epoch yet.
8. Real later user action rechecks exact original pending cell, attempt, authority epoch/route, selected vault/revision and sole-result condition at actual transfer. Cancel/replacement/stale result always closes original result, never another attempt.

## Partial failures / real limitations

- acquireUnstableContentProviderClient can block before endpoint exists. There is no supported exact remote cancellation capability yet. Independent cancel seals original/no auth permitted, but MUST NOT close a client still in use, kill a guessed PID, start another acquisition or call a generic alias cleanup as process proof. If late acquisition returns, attach it to original, obtain endpoint only for exact cleanup, terminate, observe death, close/ack. If never returns, keep worker/process uncertainty charged and deny future auth. CB1 explicitly allows hung-OS finite-service limitation; it does not promise successful teardown of a broken platform. This is unverified limitation, not a completed cleanup.
- Client acquired but endpoint call throws/returns malformed before identifying endpoint: no arm/show permitted. Retain uncertain host obligation. Do not infer death from generic RemoteException or treat every DeadObjectException as proof of entire host process death; use exact endpoint if later recoverable, else remain charged. Normal same-process call failures must not create authority.
- Provider construction may launch helper before returning endpoint. Initial helper state is inert and contains no handle. Never turn known no-auth into known no-process. An uncertain launched process remains an ownership obligation until exact supported evidence exists.
- Cancellation before helper startup is checked again on actual late endpoint; same original cleanup only. Parent process death leaves no authority; helper cannot authenticate anything without received operationHandle and must not restore requests. Parent death cleanup needs a separately audited exact parent-death observation if helper is already armed; do not casually add unowned DeathRecipient callbacks.
- Process restart yields a different Binder and process-static nonce domain. Old endpoint cannot be overwritten/reused; old isBinderAlive false cannot acknowledge new host. New host acquisition denied while original unresolved.
- Parent restart needs a cleanup-only preflight BEFORE fresh Cipher/provider preparation: the old :biometric singleton may still contain an armed old-parent request. A new parent cannot reset counters and ignore it. Private endpoint state must expose only bounded idle/occupied original nonce metadata to sameUID cleanup caller. An occupied old endpoint is terminated against that exact nonce, actual death observed and client/worker ownership acknowledged before a fresh request/process is created. Never re-arm that endpoint or interpret a new parent's attempt as ownership of old credentials. Preflight itself requires an explicit small no-secret client/endpoint/RPC/terminator manifest; cannot be an unowned bootstrap probe. No additional parent DeathRecipient is implied. If orphan retirement cannot be observed, fail closed before fresh provider acquisition.
- If terminate RPC or actual Thread cleanup fails/hangs, retain charges and deny fresh authentication. Independent physical dispatch is guaranteed by funded separate worker; it cannot guarantee a frozen OS/Binder implementation completes.
- Callback-free parent protocol removes Binder callback-return problem. It does not waive providerclient close, Parcel recycle, actual Thread joins, child app graph death or final UI resource ownership.

## Small implementation batches

1. Pure exact-nonce provider process protocol + disabled helper platform endpoint. Tests: single arm, late stale/replacement, no-authority receipt, readTerminal nonblocking, cancellation/death distinctions, no handle Bundle/log. Source review before Native parent wiring.
2. Provider preparation/retainedCipher ownership plus callback-free process9 factory under exact original; controlled blocking doubles for client acquisition/call/Parcel close/process death/termination independence. No automatic admission.
3. Narrow async exact4 producer and parked result + real user final action for one Primary then one Hidden path, retaining existing final-check logic and no generic queue. Complete store/provider/full peak census before enabling any family.
4. Independent exact-source review + complete relevant JVM/lint/Android test compilation. Real Android runtime for cross-process operationHandle, retained unstable-client foreground inheritance, helper death without parent death, system UI accessibility/background/retry and Fold. Runtime remains unavailable now; production gate remains DISABLED.

Conclusion: provider-only platform boundary itself is supported, but current source cannot safely enable it by replacing one backend class. Async exact4 producer, full provider partial construction, bounded final caller and store final-preparation remain concrete implementation prerequisites. No new exception, capacity increase or acceptance claim follows.
