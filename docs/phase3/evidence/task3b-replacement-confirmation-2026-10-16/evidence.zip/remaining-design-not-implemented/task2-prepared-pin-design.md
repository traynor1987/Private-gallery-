# Task 2 design preparation: exact Primary PIN mutations

Read-only source design against current private-gallery-task3-recovered. No source edits, tests, Gradle or subagents. This is an implementation proposal, not evidence of completed C/Task3B. Read SECURITY_CONTRACT.md, LOCK_ORDER.md, CLEANUP_CAPACITY.md and current PIN/recovery/preference/restore paths.

## Decision

Do not replace `commitAttempt { Native() }` with `checkAttempt(); Native()`. Use a fixed Primary credential mutation reservation, prepare exact immutable commands outside gates, admit those commands once under the originating authority, and retain their original ownership through actual completion. The admission action is Native-free; the durable command is not. Phase0 expressly permits an already-linearized commit to finish after revoke, but this does not authorize fresh commands or later session adoption.

A PIN-only CAS without migrating restore rollback and all other PIN writers is insufficient. A CAS also does not fund input/result/provider/worker resources. The existing recovery input/result migration is useful ownership infrastructure, not prepared-command authorization.

## Actual sites and constraints

| Path | Current implementation | Required migration |
|---|---|---|
| Setup | Main.installPinAuthenticatedKey(create=true) -> keys.create(pin), inside authenticatePin's synchronous producer | Exact PrimaryAuthAttempt and setup-purpose command; preserve empty PIN/recovery/biometric material and storage inventory checks. |
| Change | Main.changePin -> PrimaryKeySlots.changePin -> unlock(oldPin.copyOf()), compare operation.key, then pin.changePin | One CREDENTIALS operation; own the copy/result. Avoid the present second unwrap in pin.changePin. Prepare from the already authenticated VDEK and one reserved predecessor snapshot. |
| Offline recovery | Main.authenticateRecovery -> PrimaryKeySlots.recover -> generation commit callback -> pin.replacePinForRecoveredVault + biometric disable | Existing original Primary attempt plus original generation/route; replace arbitrary action callback with exact prepared command admission. Keep extra new-PIN retirement and unchanged branded result barrier. |
| Restore install | Main.restoreEncryptedBackup -> raw IO coroutine/input -> AndroidVaultRepository.restoreBackup -> generation commit -> installPinForRestoredVault | Exact restore attempt and bounded transaction original before opening input/stage; install command prepared outside gates. Existing raw coroutine/result/open path is not an acceptable owner. |
| Restore rollback | raw closure returned from installPinForRestoredVault, called in repository catch | Retained transaction-owned rollback token through final restore decision, not a closure that outlives serialization. Cleanup may execute after revoke but only against its original installed bytes. |

PinVaultKeyStore.create currently reads inventory and saves under storageLock/preferences; changePin holds preferences across unwrap, KDF and callback; replace/install/clearIfOwned hold preferences across Native work. AndroidVaultRepository.restoreBackup holds PRIMARY_IO_LOCK across archive IO, matching, generation callbacks, preference commits and rollback. Recovery generation lock encloses Native mutation. These are actual C blockers, not proposed new behavior. LOCK_ORDER rank10 disallows IO/callbacks while holding an application preference monitor; authority/storage gates cannot enclose waits/cleanup.

## Concrete internal types and file changes

Add `core/security/PrimaryCredentialMutation.kt`, specific to the existing Primary credential stores, not a generic callback runner:

- `internal object PrimaryCredentialMutationSlot` with one process-wide CAS identity. `claim(kind: Kind): Mutation` rejects overlap; kinds are SETUP, CHANGE_PIN, RECOVER, RESTORE, BIOMETRIC_ENROLL, BIOMETRIC_DISABLE, RECOVERY_SLOT. Scope checks precede claim; the original is already reserved/attached. Single-flight is intentionally conservative and does not introduce a queue/pool.
- `Mutation` owns only bounded metadata: immutable kind/identity, owner identity, state, fixed admitted command sequence, and rollback state. No Native work in CAS/state transitions. It cannot select another vault/path/provider. Do not use the Context or preferences object as a replaceable selector.
- `PreparedPrimaryPinWrite` stores exact already-created Editor plus exact encoded record and predecessor evidence. No public raw Editor, arbitrary action, or delayed supplier after admission. Commands are private to PinVaultKeyStore. `executeAdmitted()` runs once outside gates. `closeAcknowledged()` seals new entry and waits actual synchronous invocation return before clearing references/releasing the reservation.
- `PrimaryRestorePinInstallation` retains installed-record identity and transaction original; exposes only synchronous exact rollback or metadata `finishInstalled`, followed by real terminal retirement. It is not a bare `() -> Unit`.

PinVaultKeyStore should expose only internal owner-backed preparations (illustrative exact signatures):

```
prepareCreate(owner: PrimarySetupContext, pin: OwnedPinInput): PreparedPrimaryPinWrite
prepareChange(owner: PrimaryOperation, oldPin: OwnedPinInput, newPin: OwnedPinInput): PreparedPrimaryPinWrite
prepareRecovered(owner: PrimaryRecoveryContext, newPin: OwnedPinInput, key: RecoveryKeyBorrow): PreparedPrimaryPinWrite
prepareRestore(owner: PrimaryRestoreContext, newPin: OwnedPinInput, key: RestoreKeyBorrow): PreparedPrimaryPinWrite
```

These contexts are trusted fixed-kind wrappers around existing original owners, not free interfaces accepting caller-defined permission callbacks. Operations use their CREDENTIALS capability. Attempt contexts capture one PrimaryAuthAttempt plus the exact original resource; never obtain a current/replacement attempt or fabricate an unlocked operation.

PrimarySessionAuthority needs narrow typed admission methods, e.g. `admitPreparedRecovery(attempt, original, command)` / setup / restore. Under its existing gate, check exact pending attempt, expiry, kind, registered-original membership, nonretired/nonfailed state, and mark that exact prepared command admitted. Do not execute Native inside that method. Session mutation admission similarly uses the original operation.commit for metadata only. Do not expose a general `authorize(action)` helper that restores the original check-to-write gap.

PrimaryRecoveryAuthentication must supply a trusted recovery context to its synchronous producer instead of `((() -> Unit) -> Unit)`. Main's independent generation/route authorization also must mark the SAME prepared command under the existing generation gate, with consistent order generation -> Primary authority. Final nested action is metadata only; Native starts after both gates exit. If either predicate denies, no command executes. Never make two unrelated prechecks and assume their combination is atomic.

Main setup should gain the same typed attempt context instead of calling keys.create from a factory that cannot name its original attempt. Main recovery continues exact completeAuthentication and no raw open. Main restore must migrate to an exact Primary attempt/result handoff before its prepared install is considered supported; retain route/generation checks and deny stale UI callbacks separately.

Remove default `{ it() }` mutation callbacks and raw production writer overloads when actual call sites migrate. Update instrumentation fixtures to use real owner-backed paths, preserving negative compatibility/cross-vault/rollback tests. Do not leave a test-only unowned production mutation route.

## Reservation/predecessor rules across ALL writers

Acquire the shared credential token before reading predecessor state or doing expensive preparation. Hold it through admitted writes, outcome handling and rollback decision; release only after actual invocation/reference cleanup. Busy rejects before Native preparation. Every Primary PIN writer must participate, including create/change/recover/restore and rollback. Since setup eligibility also consults recovery/biometric preferences, those mutation paths must participate in the same reservation (or an explicit ordered, nonwaiting reservation group). Prefer one token and pass it internally for recovery's PIN+disable; do not recursively claim it.

Read the exact encrypted predecessor outside application locks while this reservation excludes writers. Validate fixed record shape and existing setup inventory semantics. Prepare all encoded values/editor objects outside gates. An exact command admitted before revoke may finish; a command not admitted before revoke cannot execute. No additional editor or KDF may be selected/created as a consequence of an admitted write flag.

The credential CAS is NOT a substitute for root serialization. Setup/restore empty-store checks and restore staging/rename touch Primary storage too. A typed fresh-install transaction reservation must exclude all competing setup/restore installers from before inventory/stage access to final decision. Existing protected media writes must already be excluded by locked authority plus actual cleanup; do not assert that until their ownership is evidenced. Retain only short predecessor/atomic-rename metadata sections under storageLock as needed. Moving the entire restore out of storageLock without replacement ownership is a blocker.

## Physical child census and phasing

The fixed16 pool is unchanged. Count actual buffers/handles, not just facade objects. Below is the explicit supported inventory to implement/verify, not a declaration that existing PinEnvelope currently satisfies it:

| Obligation | Children | Notes |
|---|---:|---|
| Existing authentication result / synchronous invocation / recovery-secret or setup PIN | 3 | Existing branded original unchanged; no extra surviving originals at final admission. |
| Recovery new-PIN input | 1 | Existing independently owned child. Change needs two owned PIN inputs; setup one is already in the three-child layout. |
| Exact prepared command and mutation-token lifetime | 1 | Sequential Editor operation; no supported independently blocking Editor.close. Actual invocation return, reference clearing and token release precede ack. |
| Decoded predecessor salt/nonce/ciphertext | 3 | Reserve before decode; wipe/release after unwrap before next phase. Reads cannot create unowned copies. |
| Authenticated working VDEK/result | 1 if separate | Reuse an already owned result/temporary-key borrower where valid; never count raw returned bytes as owned merely because a future result slot exists. |
| KDF input byte copy / wrapping-key output | 2 | Each actual array must be owned before allocation; release after synchronous crypto return. |
| Prepared salt / nonce / ciphertext | 3 | Exact encrypted output buffers; independently owned or an explicitly justified fixed nonblocking buffer cell with complete byte census, never a generic composite hiding blockers. |
| Active Cipher app reference / entropy provider app reference | up to 2 | Actual synchronous use return and supported app-reference retirement. No new Android-internal exception; implementation must document the precise provider boundary. |
| Restore rollback command capability | 1 | Separate if its cleanup can block independently of producer/other cleanup. Preclaim before installation, not on failure. |
| Worker, streams, ZIP/input, output, copy/manifest arrays, stage/root handles | additional | Actual restore inventory; cannot disappear inside the PIN command. |

The conservative recovery credential peak before phase releases is 3+1+1+3+1+2+3+2 = 16, with no room for an extra worker/provider/rollback child. Therefore phase retirement is mandatory, not optional: retire predecessor/old-key authentication temporaries before preparing new PIN envelope; retire KDF/provider intermediates before admission/persistence; retire command and both inputs before final result handoff. Where the authenticated key is already held by the result root, do not allocate a duplicate working key. Explicitly recalculate each route's measured peak after implementing the actual buffers/provider boundaries.

Existing PinEnvelope.create/changePin allocate their arrays and provider objects internally; merely putting one wrapper receipt around them does not establish this complete manifest. Add narrowly typed owned PIN preparation routines (same algorithms/parameters/encoding), or leave this provider ownership as a declared blocking prerequisite. SCrypt's actual supported provider boundary and internal arrays must be documented; no claim of universal native-memory wiping follows from reference clearing.

The existing result factory binds returned VDEK only after its callback finishes. For recovery's subsequent PIN KDF, immediately attach the actual recovered key to a funded typed producer-result/temporary cell before another throwing or blocking step. Add a trusted internal producer borrow if necessary; do not expose a raw result getter or relax the branded final handoff layout. Raw producer-local bytes with a finally wipe alone are not a complete precreation/partial-attachment proof.

Restore cannot use the above credential-only16 estimate as whole-route fit. Its current archive has raw InputStream/ZipInputStream, per-entry FileOutputStream,64KiB copy buffers, expandable manifest bytes and verification readers. Stage/read/verify must be sequential owned phases and their actual retirements precede installation where possible. If the concrete peak exceeds16, refuse before acquisition or phase resources; no quota increase/emergency owner.

## Restore rollback lifetime and failure semantics

Keep one restore transaction/token through archive verification, root decision, recovery-envelope install, PIN install and final completion decision. The PIN rollback capability is reserved BEFORE install. It remains attached even after successful PIN commit until the enclosing restore has made its durable outcome decision, not just until installPinForRestoredVault returns.

Rollback after revoke is cleanup authority only. It may compare the exact installed record and remove only that record, outside all gates, while the same transaction reservation excludes newer writers. It cannot restore a stale old PIN over a newer command. If comparison proves a different record, leave it untouched and fail closed/report mismatch; do not erase it. Prefer no future arbitrary closure: a typed original token executes rollback once and acknowledges actual compare/delete return. Main must not release this token merely because a result has been posted to UI.

There is an unavoidable distinction between durable transaction completion and session/UI acceptance. Once restored root+envelopes are committed and transaction ownership is finalized, later session rejection does not authorize deleting the installed winner; retain authenticated ciphertext and credentials for retry. If failure occurs before that transaction decision, perform the original rollback policy and retire rollback resources before releasing exclusion. Freeze this decision explicitly in metadata and tests.

SharedPreferences false/throw may leave changed in-memory state. Do not infer no write occurred. Mark the involved credential slot unavailable after an ambiguous failed write until a supported reconcile/readback establishes an allowed state; do not clear failure by creating a new store instance. A new per-process fixed-slot failure marker may be appropriate, consistent with existing FailClosedRecoveryPersistence, without changing disk format. Rollback failure remains charged/failed and blocks unsafe fresh admission. Successful cleanup after a failed persistence operation may retire honestly; it must not convert the operation into success. Keep primary error and suppress subsequent cleanup errors.

PIN and biometric/recovery preferences are separate files: no atomic multi-store transaction is supplied. Prepare exact commands up front and authorize a fixed sequence, but preserve truthful partial-failure reporting. In recovery, a successful PIN write followed by failed disable must not produce a session. Do not add a casual compensating old-PIN write; that is another durable command with its own ownership and failure semantics.

## Concrete execution order for the internal batch

1. Implement/test shared fixed credential reservation and exact prepared PIN command lifetime, with same-kind owned fake backend tests. No production path switches yet.
2. Add typed operation/Primary-attempt admission and owned preparation/result borrowing. Inventory/phase buffers and retain exact final single-result rule.
3. Migrate setup, change and recovery together with every conflicting PIN/biometric/recovery writer participating in exclusion. Remove arbitrary commit callbacks from these mutation surfaces; retain no default bypass.
4. Migrate restore installer AND its retained typed rollback in the same source batch; connect its actual original attempt/worker/input/result lifecycle. Keep root staging/verification prerequisites explicitly blocking until funded/phased. Do not expose a prepared install route backed only by the old generation callback.
5. Adapt existing actual Android fixtures (Phase1PrimarySlotsTest, VaultBackupRestoreTest, Phase0FrozenRestoreRehearsalTest, Phase2DomainAdaptersTest) and deterministic latch tests. Preserve format vectors and stale rollback ownership assertions, changing expected conflict timing only where the new documented single-flight scope intentionally rejects overlap.

Essential race tests: revoke before exact admission ->zero writes; admitted held commit ->prompt revoke but charged until actual return; recovery stale generic callback cannot write; two store instances cannot race setup/change/recovery/restore; restore install success then later transaction failure rolls back only its own record; late rollback cannot erase newer winner; failed/ambiguous preference write cannot masquerade as empty/configured success; final handoff denies until rollback/commands/inputs actually retire; all capacity failures precede respective allocations. Evidence must distinguish compile RED from actual behavioral failures.

## Hard blockers versus prerequisites

Hard production blockers today: Native under generation/preference/storage gates; generic recovery check-to-write gap; unsupported restore worker/input/raw key admission; bare rollback callback lifetime; alternate PIN writers bypassing any new token. These prevent claiming this task complete after a single helper edit.

Planned prerequisites: typed prepared contexts/commands, complete owned buffer/provider preparation, shared writer exclusion and restore transaction lifetime, per-route fixed16 phase census and failure-state policy. They are justified implementation work, not excuses to expand formats or waive app-resource retirement. This report authorizes no separate feature, resource exception or whole3B acceptance.
