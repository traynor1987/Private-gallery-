# Task 1 implementation report — replacement confirmation inputs

Base: `63e25dd865976a4798449a15504e8fece2a58348`. Local coherent commit: `128253051715c47c37ae1d13773f616f847fb446` (not pushed). Task3B Task1 only. Task3B remains partial/unaccepted, Phase3 NO-GO and production biometrics DISABLED. Independent controller review is pending; this report does not accept the component or full Task3B. No push, main/protected branch/PR59, release/signing, Task3C–H or Tasks4–8 action was performed.

## Implementation and files

- `app/src/main/java/uk/co/traynor/privategallery/core/domain/OwnedRecoveryConfirmation.kt`: focused, synchronous, internal callback family. It atomically reserves the exact two independent IO children `confirmation-master` and `confirmation-secret`, attaching inert `PendingSetupBuffer` cells before acquiring either payload. The stable 32-byte master snapshot is copied only inside the original RECOVERY operation's short commit. The exact 32-byte caller secret is adopted without copying. The nested active producers retain both buffers through actual synchronous consumer return, including cancellation and exceptions. No raw getter, transfer, queue or worker was added.
- `SecondaryController.kt`: replacement confirmation enters this family before store entry. UI sequence, original operation publication and disabled-biometric state remain unchanged.
- `SecondaryStore.kt`: replacement confirmation is now an internal four-argument consumer of explicitly borrowed master and secret. Every verification, possession comparison, recovery creation, prepare and select uses the stable master and exact secret. `secretSnapshot` and all raw `operation.key` Native reads were removed from this method. Owner/replacement checks, old selected token, RECOVERY scope, selected predecessor, pending's independent retirement wait and final original operation check remain.
- `SecondarySessionAuthority.kt`: a narrow `requireRecoveryConfirmationAdmission` check on the existing exact operation/epoch/lease/RECOVERY scope and existing cleanup state. It neither changes generic `authorized`, `createOwned`, `reserveAll` nor any capacity. The family checks it at ingress, within the bounded snapshot commit, before production/consumer admission and separately after actual terminal retirement.
- `app/src/test/.../SecondaryPendingStoreFixture.kt` and matching `app/src/androidTest/.../SecondaryPendingStoreFixture.kt`: test-only three-argument adapters use the same real two-child family. No unmanaged production overload remains.
- `app/src/test/.../OwnedRecoveryConfirmationTest.kt`: 12 deterministic focused tests covering real buffer identity/bytes, actual consumer return, cancellation, stale original/fresh authentication denial, atomic two-child capacity denial with 15/16 occupied, unsupported sizes, inherited authority gate denial, original exception preservation, actual cleanup callback return versus completed stage, consumer and retirement interruption, failed/incomplete prior family denial and ordinary live-owner coexistence.

The helper releases its same original and awaits its terminal acknowledgement or retained failure outside authority/resource/root gates before returning success. Failed release is checked while awaiting, with a 20-second upper bound. The exact operation is checked separately afterward. A supplied secret is wiped on every admission/terminal path only after its synchronous consumer has returned. Primary errors remain primary; retirement errors are suppressed. Consumer-thrown or inherited interruption is remembered, cleared only around mandatory retirement, and restored in the outer finally; a new interruption during the wait rejects success, restores status and retains unfinished original accounting.

## Source rationale for narrow cleanup denial

Inspection found `SecondarySessionAuthority.createOwned` checks the exact operation's epoch/lease and `ReleasePool.reserveAll` selects available slots; neither generically rejects another failed/retiring ticket in the same live epoch. Deterministic tests then proved this replacement helper could start another consumer after its earlier mandatory retirement had failed or had returned interrupted while cleanup was still held. Both failures were preserved before correction.

The authorized correction uses the existing `ReleasePool.hasUnacknowledgedRetirement` predicate on IO and presentation pools plus authority `cleanupFailed`. In `ReleaseCapacity.kt`, the pool predicate includes registry failure, outstanding retirement dispatches, or a ticket's `failure != null` / released-but-not-fully-returned state. An ordinary live, nonretiring original is not included. The new two-child original therefore remains admissible while live; a separate healthy concurrent original is also allowed. Final admission follows the new original's actual terminal slot return. The change deliberately does not rewrite global admission for other families, exempt active resources, reset failed pools, or confuse all current resources with unfinished retirement.

Fixed physical capacity16 is unchanged. `PendingSetupBuffer` and `ReleaseReservation.beginPendingBuffer` required no modifications: their existing typed exact-original admission and active-return acknowledgement provide the needed lifetime semantics. Cleanup callbacks and waits remain outside the new ranked gates. Existing broader store-root Native work is not resolved by this task.

## Exact Gradle commands and observed results

All commands ran serially from `/workspace/scratch/0881340dd615/private-gallery-task3-recovered`. No tested source was edited while Gradle was active. Every run's XML was copied before the next invocation could overwrite it. All evidence below is under `/root/.cache/private-gallery-task3b/`.

```bash
python3 /root/.cache/private-gallery-task3b/run.py task1-red-exact-secret :app:testDebugUnitTest --tests uk.co.traynor.privategallery.core.domain.OwnedRecoveryConfirmationTest
```

Genuine RED on unchanged production: 1 test, 1 failure, zero errors/skips. Exact caller secret remained nonzero after successful old store confirmation (`ArrayComparisonFailure`). Log `task1-red-exact-secret.log`, XML `task1-red-exact-secret-xml/`. This is a behavioral failure, not a compiler error.

```bash
python3 /root/.cache/private-gallery-task3b/run.py task1-green-owned-inputs :app:testDebugUnitTest --tests uk.co.traynor.privategallery.core.domain.OwnedRecoveryConfirmationTest --tests uk.co.traynor.privategallery.core.domain.PendingReplacementRetirementTest --tests uk.co.traynor.privategallery.core.domain.SecondaryControllerTest --tests uk.co.traynor.privategallery.core.domain.SecondaryControllerBiometricTest --tests uk.co.traynor.privategallery.core.domain.SecondaryStoreTest --tests uk.co.traynor.privategallery.core.domain.SecondaryCredentialRetirementTest
```

Initial GREEN: 44 tests, zero failures/errors/skips, Gradle exit0 (2m23s). Log `task1-green-owned-inputs.log`, XML `task1-green-owned-inputs-xml/`. This preceded the self-review corrections below and is not the final-source result.

```bash
python3 /root/.cache/private-gallery-task3b/run.py task1-red-consumer-interruption :app:testDebugUnitTest --tests uk.co.traynor.privategallery.core.domain.OwnedRecoveryConfirmationTest.consumerInterruptionPreservesTheOriginalThrowableAndInterruptStatus
```

Self-review RED: 1 test, 1 failure, zero errors/skips. The same consumer `InterruptedException` escaped with a cleared interrupt flag. Log `task1-red-consumer-interruption.log`, XML `task1-red-consumer-interruption-xml/`. The final test additionally holds actual cleanup return to prove restoration cannot bypass mandatory retirement.

```bash
python3 /root/.cache/private-gallery-task3b/run.py task1-red-failed-original-retry :app:testDebugUnitTest --tests uk.co.traynor.privategallery.core.domain.OwnedRecoveryConfirmationTest.sameHelperCannotRetryAfterItsOriginalMandatoryRetirementFailed --tests uk.co.traynor.privategallery.core.domain.OwnedRecoveryConfirmationTest.ordinaryConcurrentLiveOriginalDoesNotDenyConfirmation
```

Genuine RED: 2 tests, 1 failure, zero errors/skips. Retry after retained failed original admitted and completed a consumer instead of denying; ordinary concurrent live original passed. Log `task1-red-failed-original-retry.log`, XML `task1-red-failed-original-retry-xml/`.

```bash
python3 /root/.cache/private-gallery-task3b/run.py task1-red-held-original-retry :app:testDebugUnitTest --tests uk.co.traynor.privategallery.core.domain.OwnedRecoveryConfirmationTest.interruptedMandatoryRetirementPreservesInterruptAndAccountingUntilActualReturn
```

Genuine RED: 1 test, 1 failure, zero errors/skips. Retry after interrupted mandatory wait admitted a consumer while the earlier two actual cleanup callbacks were held. Log `task1-red-held-original-retry.log`, XML `task1-red-held-original-retry-xml/`.

```bash
python3 /root/.cache/private-gallery-task3b/run.py task1-final-focused :app:testDebugUnitTest --tests uk.co.traynor.privategallery.core.domain.OwnedRecoveryConfirmationTest --tests uk.co.traynor.privategallery.core.domain.PendingReplacementRetirementTest --tests uk.co.traynor.privategallery.core.domain.PendingSetupOwnershipTest --tests uk.co.traynor.privategallery.core.domain.PendingConfirmationBorrowTest --tests uk.co.traynor.privategallery.core.domain.SecondaryControllerTest --tests uk.co.traynor.privategallery.core.domain.SecondaryControllerBiometricTest --tests uk.co.traynor.privategallery.core.domain.SecondaryStoreTest --tests uk.co.traynor.privategallery.core.domain.SecondaryCredentialRetirementTest --tests uk.co.traynor.privategallery.core.domain.SecondarySessionAuthorityTest --tests uk.co.traynor.privategallery.core.security.OwnedPlaintextTest
```

Final GREEN: **82 tests, zero failures/errors/skips, exit0 (2m25s)**. Log `task1-final-focused.log`, XML `task1-final-focused-xml/`, per-class totals `task1-final-focused-summary.json`:

| Class | Tests |
| --- | ---: |
| OwnedRecoveryConfirmationTest | 12 |
| PendingReplacementRetirementTest | 1 |
| PendingSetupOwnershipTest | 8 |
| PendingConfirmationBorrowTest | 1 |
| SecondaryControllerTest | 8 |
| SecondaryControllerBiometricTest | 14 |
| SecondaryStoreTest | 7 |
| SecondaryCredentialRetirementTest | 5 |
| SecondarySessionAuthorityTest | 16 |
| OwnedPlaintextTest (Task3A) | 10 |

The 14 biometric controller regressions include cancellation during pointer promotion and uncertain selection without deleting the selected alias. The native host library path is configured by the Gradle test task. Existing unrelated Kotlin/deprecation/type warnings and SDK Platform-Tools/license warnings were printed; these were successful focused runs, not warning-free builds. No test assertions were weakened to pass an implementation defect.

## Controlled compiled repetitions

Command: `python3 /root/.cache/private-gallery-task3b/task1-repeat.py`. The saved script invokes the existing `RepeatJUnit` with the complete saved debug test classpath, absolute cached JDK and explicit `-Djava.library.path=app/build/host-staging-entropy`. Each method has its own `task1-repeat-<method>.log`. Final counts are recorded after execution below.

All **105/105 repetitions passed**, zero failures: held consumer cancellation20, actual callback return versus stage20, interrupted mandatory wait/held prior family denial20, consumer interruption with actual mandatory retirement20, failed-original retry denial5, ordinary concurrent live-original permission20. Each invocation exited0. These are compiled host-JVM repetitions, not additional Android/ART cases.

## Self-review and remaining concerns

Self-review checked all new production calls and the exact buffer/source identity, two precreation receipts, revocation versus admitted active-use ordering, no raw ownership getter, failed/incomplete original retention, no blanket current-resource denial, final same-original retirement plus exact operation admission, source-set-only adapters, existing selected predecessor, pending retirement outside root and final UI sequence/epoch guards. The consumer is trusted and synchronous; retaining either array or dispatching unjoined use is forbidden by its internal contract and no audited production caller does so. No application resource or worker was relabeled platform-managed. The only permitted platform-managed exception remains Android-internal Keystore retirement without public acknowledgement; this task makes no claim to observe that internal retirement.

Mandatory remaining Task3B work includes outer Executor queue/captured UI input ownership before worker/helper entry; `confirmPossession`'s temporary unwrapped master (currently finally-wipe only); complete provider/KDF/store/directory and other child manifests; existing root-held Native/cleanup work and global admission/ownership inventory. These are mandatory Task3B dependencies, not later-phase deferrals. The narrow family health check does not claim to repair generic live-epoch factory admission elsewhere.

No full JVM suite, lint, APK build, Android test compilation or Android runtime/ART/physical acceptance was run for this delta, as directed by the controller's bounded handoff. Host tests with synthetic maintenance keys are not Android-internal Keystore lifecycle evidence. Controller will handle independent review, broader verification and any needed Android compilation. Task3A production source and fixed pools were untouched; the relevant 10 Task3A tests passed on final source.

Final hygiene: `git diff --cached --check` passed before the local commit; working tree is clean after committing exactly the seven implementation/test files. The local SDD report is retained at its requested path. Final implementation/test SHA256 values are saved in `/root/.cache/private-gallery-task3b/task1-final-source-sha256.json`. No application/test source changed after the 82-test final Gradle run or the 105 compiled repetitions. Gradle lease is released for controller review/verification.
