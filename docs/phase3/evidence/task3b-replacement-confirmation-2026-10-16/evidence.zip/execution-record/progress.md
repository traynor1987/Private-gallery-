# SDD ledger — plan: docs/phase3/TASK3B_REMAINING_IMPLEMENTATION_PLAN_2026_10_16.md

Recovered implementation remains authoritative; no restart. Remote parent be82d965bc010b06da40486c5856ad434adb6a0a; initial-confirmation borrow batch is finishing verification/checkpoint before Task1 starts. Task3A passed; whole3B PARTIAL and biometrics DISABLED. Root performs one Gradle execution at a time. User explicitly authorizes security implementation/tests/recovery-branch pushes; no extra approval inferred from skill workflow.

## Preflight interface/conflict scan

| Tasks | Shared source/interface | Finding / disposition |
|---|---|---|
|1 /3|SecondaryController replacement submit and input captures|1 owns only entered synchronous family;3 must retain this and own earlier queue/capture lifetime. No exemption.|
|1 /4|SecondaryStore confirmation signature and Native borrowed arrays|4 must preserve same admitted buffers until actual Native return and existing pending retirement.|
|2 /3|Main/Primary authority original preparation and final result|3 must consume2's exact context, not create an ambient replacement or exempt a running coordinator.|
|2 /5|Primary providers/Main input/command manifests|5 must budget existing provider and durable obligations, not assume uncharged cipher/key temporaries.|
|3 /4|Secondary controller/result/selected store handoff|4's actual cleanup feeds3's sole-result barrier; Native cleanup cannot move into a deadlocking executor.|
|3 /5|Main/authorities producer/thread/Main dispatch|5 must use actual-return ownership, not Job/future completion; production gate remains disabled until acceptance.|
|4 /5|Secondary provider/store/selection cleanup|Preserve final selected predecessor and independent child accounting; platform exception only internalKeystore.|
|6 /1–5|Final source/test/review evidence|6 cannot accept partial scopes or old-source evidence as exact final verification.|
|1 self|Two buffer claims, consumer and regressions|Consistent. Key lease revocation requires own stable snapshot before Native, not just secret ownership.|
|2 self|All PIN writers and rollback vs exact prepared command|Must include restore completion handle; no partial writer exclusion claim. Refine against source before code.|
|3 self|Coordinator lifetime vs final key admission|Must retire nonresult coordinator first; no live-work exemption. Refine concrete phases before code.|
|4 self|Root serialization vs Native cleanup outside gates|Keep verified relative publication contract; actual cleanup phases require source-specific detachment before code.|
|5 self|Supported private-process candidate vs fixed16/runtime|Candidate only; inventory and real runtime proof mandatory. Compile/model/denial cannot enable.|
|6 self|PASS vs mandatory unresolved requirements|Only exact final whole-path evidence permitsPASS. No automatic3C.|

Ruling: Task1 reserves TWO existing IO children, not just the initially proposed secret child — SecondaryOperation.key is revoked/wiped and Native work needs a separately retained snapshot; cost if wrong is one extra charged slot/admission denial, never quota expansion.
Ruling: Task2–5 are implementation obligations but their detailed interfaces must be refined from actual prior-task source before dispatch — no speculative architecture or weakened contract; cost if wrong is additional bounded source analysis/rework, not unsafe enablement.

Task1: not started. Task2–6: not started. Initial confirmation source before Task1 is root's already-reviewed coherent batch, not redispatched.

Initial confirmation batch saved and independently read from GitHub at63e25dd865976a4798449a15504e8fece2a58348; exacttree348d623bf788c26a225a62290e817dbcb2c9dae3. ParentMAIN/protected/PR59 unchanged. Source/security final25 passed. Task1 BASE=63e25dd865976a4798449a15504e8fece2a58348. Existing isolated recovery checkout verified; no competing worktree or active Gradle.

Ruling: use a later ordinary framework-delivered zero-argument Continue action for staged authentication final admission instead of an automatically posted per-attempt finalizer — CB1 narrow keyhandoff metadata does not explicitly waive callback actual-return obligations; two reviewers now agree automatic proposal is unaccepted. The action borrows the private already-owned parked result only after positive producer retirement and rechecks exact original attempt/sequence/vault. Cost if wrong: one additional bounded user interaction/rework, no security exception or quota expansion. This is Task3B auth workflow implementation, not Task3C or biometric enablement.

Task1 implementation agent=/root/replacement_confirmation_implementation. First GREEN44/44 passed incl selected-alias cancellation. Self-review found consumer InterruptedException flag and same-family retry after failed cleanup questions; preserving deliberate RED evidence and fixing before independent review. Ruling: a reproduced same-family retry bypass must receive a narrow exact RECOVERY operation failed-retirement admission check, not global createOwned/ReleasePool/quota changes — it enforces this family mandatory-retirement denial while allowing ordinary concurrent live originals; cost if wrong is conservative same-session credential denial/rework, not unsafe fresh authority.
