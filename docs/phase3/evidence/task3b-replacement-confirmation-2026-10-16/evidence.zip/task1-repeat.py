import pathlib, subprocess
base = pathlib.Path('/root/.cache/private-gallery-task3b')
repo = pathlib.Path('/workspace/scratch/0881340dd615/private-gallery-task3-recovered')
classpath = (base/'debug-test-classpath.txt').read_text().strip()+':'+str(base)
methods = [
 ('cancellationPreservesBothBuffersUntilActualConsumerReturnAndDeniesLateSuccess', 20),
 ('completedBufferStagesCannotReplaceActualCleanupCallbackReturn', 20),
 ('interruptedMandatoryRetirementPreservesInterruptAndAccountingUntilActualReturn', 20),
 ('consumerInterruptionPreservesTheOriginalThrowableAndInterruptStatus', 20),
 ('sameHelperCannotRetryAfterItsOriginalMandatoryRetirementFailed', 5),
 ('ordinaryConcurrentLiveOriginalDoesNotDenyConfirmation', 20),
]
for method, count in methods:
    command = [str(base/'jdk/bin/java'), '-Djava.library.path=app/build/host-staging-entropy', '-cp', classpath,
               'RepeatJUnit', 'uk.co.traynor.privategallery.core.domain.OwnedRecoveryConfirmationTest', method, str(count)]
    with (base/('task1-repeat-'+method+'.log')).open('w') as log:
        result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    print(method, 'iterations', count, 'exit', result.returncode, flush=True)
    if result.returncode: raise SystemExit(result.returncode)
