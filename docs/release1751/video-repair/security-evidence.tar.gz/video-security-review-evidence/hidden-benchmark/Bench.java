import java.io.*;import java.util.*;import uk.co.traynor.privategallery.core.hidden.HiddenChunkStore;
public class Bench {
 static byte[] key=new byte[32];static String id="synthetic-performance-review";
 static HiddenChunkStore.Staged stored;static long bytes=16L*1024*1024;
 static long run(int block,boolean fresh)throws Exception {
  byte[] b=new byte[block];long start=System.nanoTime();HiddenChunkStore.Reader held=fresh?null:reader();
  try {for(long pos=0;pos<bytes;pos+=block){int n;if(fresh){try(HiddenChunkStore.Reader r=reader()){n=r.readAt(pos,b,0,block);}}else n=held.readAt(pos,b,0,block);
   if(n!=Math.min(block,bytes-pos))throw new AssertionError();for(int i=0;i<n;i++)if(b[i]!=(byte)((pos+i)%251))throw new AssertionError("plaintext mismatch");Arrays.fill(b,(byte)0);
  }}finally{if(held!=null)held.close();Arrays.fill(b,(byte)0);}return System.nanoTime()-start;
 }
 static HiddenChunkStore.Reader reader()throws Exception{return new HiddenChunkStore.Reader(stored.file,id,stored.size,stored.hash,stored.nonce,key,()->{});}
 public static void main(String[]args)throws Exception {
  File root=new File(args[0]);byte[] input=new byte[(int)bytes];for(int i=0;i<input.length;i++)input[i]=(byte)(i%251);
  stored=HiddenChunkStore.stage(root,id,new ByteArrayInputStream(input),key,()->{});Arrays.fill(input,(byte)0);
  System.out.println("java="+System.getProperty("java.version")+" provider="+javax.crypto.Cipher.getInstance("AES/GCM/NoPadding").getProvider().getName()+" sourceMiB=16 chunkBytes="+HiddenChunkStore.CHUNK_BYTES);
  run(65536,true);run(32768,true);
  for(int block:new int[]{65536,32768,16384})for(boolean fresh:new boolean[]{false,true}){
   long[] t=new long[3];for(int j=0;j<t.length;j++)t[j]=run(block,fresh);Arrays.sort(t);long calls=bytes/block;
   System.out.printf(Locale.ROOT,"block=%d reader=%s calls=%d opens=%d authenticatedChunkDecrypts=%d cryptoMiB=%d medianMs=%.2f MiBperSec=%.2f samplesMs=%s%n",block,fresh?"fresh-per-read":"reused",calls,fresh?calls:1,calls,calls*HiddenChunkStore.CHUNK_BYTES/1024/1024,t[1]/1e6,16/(t[1]/1e9),Arrays.toString(Arrays.stream(t).map(x->x/1000000).toArray()));
  }
  // Prove the post-decryption authority check rejects and clears output.
  final boolean[] allow={true};byte[] out=new byte[32];Arrays.fill(out,(byte)99);
  try(HiddenChunkStore.Reader r=new HiddenChunkStore.Reader(stored.file,id,stored.size,stored.hash,stored.nonce,key,()->{if(!allow[0])throw new IOException("revoked");})){
   allow[0]=false;try{r.readAt(0,out,0,out.length);throw new AssertionError("revocation accepted");}catch(IOException expected){System.out.println("revokedReaderRejected=true");}
  }
  Arrays.fill(key,(byte)0);stored.file.delete();
 }
}
