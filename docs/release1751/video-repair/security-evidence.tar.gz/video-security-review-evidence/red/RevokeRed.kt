import uk.co.traynor.privategallery.core.vault.*
import androidx.media3.datasource.*
import android.net.Uri
import java.io.ByteArrayInputStream
import java.io.File
fun field(value:Any,name:String):Any? = value.javaClass.getDeclaredField(name).apply{isAccessible=true}.get(value)
fun main(args:Array<String>) {
 val root=File(args[0]);val key=ByteArray(32){7};val plain=ByteArray(1024*1024+19){(it%197).toByte()}
 val stored=ChunkedVaultVideoStore.writeAndVerify("e31de763-94ed-424c-9d12-05c6bea56161",ByteArrayInputStream(plain),key,root)
 var authorised=true;var arm=false;var calls=0
 val session=VaultVideoSession(stored,key) {
  calls++;val observed=authorised
  if(arm) {authorised=false;arm=false}
  observed
 }
 val source=session.sourceFactory.createDataSource();val output=ByteArray(32){99}
 source.open(DataSpec(Uri.parse("memory://synthetic/video.mp4")));arm=true
 var rejected=false;var count:Int?=null
 try {count=source.read(output,0,output.size)}catch(expected:java.io.IOException){rejected=true}
 val wiped=output.all{it==0.toByte()};val plaintextMatches=output.contentEquals(plain.copyOfRange(0,32))
 println("allowedCalls=$calls authorisedAfterRead=$authorised readReturned=$count rejected=$rejected outputWiped=$wiped outputIsKnownPlaintext=$plaintextMatches")
 val reader=field(source,"reader")!!
 session.close()
 println("afterSessionClose sessionKeyWiped="+(field(session,"ownedKey") as ByteArray).all{it==0.toByte()}+" readerKeyStillLive="+(field(reader,"ownedKey") as ByteArray).any{it!=0.toByte()}+" readerPlainCacheBytes="+((field(reader,"cached") as ByteArray?)?.size ?: 0))
 source.close()
 println("afterDataSourceClose readerKeyWiped="+(field(reader,"ownedKey") as ByteArray).all{it==0.toByte()}+" readerCacheCleared="+(field(reader,"cached")==null))
 key.fill(0);plain.fill(0);output.fill(0);root.deleteRecursively()
 check(rejected && wiped) {"RED: revoke after precheck must reject read and wipe output; actual session returned plaintext"}
}
