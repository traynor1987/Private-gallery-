package androidx.media3.datasource
import android.net.Uri
interface TransferListener
class DataSpec(val uri:Uri,val position:Long=0,val length:Long=-1)
interface DataSource {fun interface Factory {fun createDataSource():DataSource};fun addTransferListener(listener:TransferListener);fun open(dataSpec:DataSpec):Long;fun read(buffer:ByteArray,offset:Int,length:Int):Int;fun getUri():Uri?;fun close()}
