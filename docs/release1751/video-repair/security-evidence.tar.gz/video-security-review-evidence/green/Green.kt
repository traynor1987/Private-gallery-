import uk.co.traynor.privategallery.core.vault.*
import androidx.media3.datasource.*
import android.net.Uri
import java.io.*
fun field(value:Any,name:String):Any?=value.javaClass.getDeclaredField(name).apply{isAccessible=true}.get(value)
fun main(args:Array<String>) {
 val root=File(args[0]);val key=ByteArray(32){7};val plain=ByteArray(1024*1024+19){(it%197).toByte()}
 try {
  val stored=ChunkedVaultVideoStore.writeAndVerify("e31de763-94ed-424c-9d12-05c6bea56161",ByteArrayInputStream(plain),key,root)
  var authorised=true;var arm=false;var calls=0
  val session=VaultVideoSession(stored,key) {calls++;val observed=authorised;if(arm){authorised=false;arm=false};observed}
  val source=session.sourceFactory.createDataSource();source.open(DataSpec(Uri.parse("memory://synthetic/video.mp4")))
  arm=true;val output=ByteArray(32){99};var rejected=false
  try{source.read(output,0,output.size)}catch(expected:IOException){rejected=true}
  check(rejected && output.all{it==0.toByte()}) {"revoked read must reject and wipe"}
  check(field(source,"reader")==null) {"revoked source must retire Reader"}
  println("PASS inFlightRevoke allowedCalls=$calls authority=$authorised rejected=$rejected outputWiped=true readerRetired=true")
  session.close();source.close()
  val live=VaultVideoSession(stored,key){true};val liveSource=live.sourceFactory.createDataSource();liveSource.open(DataSpec(Uri.parse("memory://synthetic/video.mp4")))
  val valid=ByteArray(32);check(liveSource.read(valid,0,valid.size)==32);check(valid.contentEquals(plain.copyOfRange(0,32)))
  val reader=field(liveSource,"reader")!!;val readerKey=field(reader,"ownedKey") as ByteArray;val cached=field(reader,"cached") as ByteArray
  check(readerKey.any{it!=0.toByte()} && cached.size==1048576 && cached.any{it!=0.toByte()})
  live.close()
  check((field(live,"ownedKey") as ByteArray).all{it==0.toByte()});check(readerKey.all{it==0.toByte()});check(cached.all{it==0.toByte()});check(field(reader,"cached")==null)
  check((field(live,"readers") as Set<*>).isEmpty())
  var closedRejected=false;try{liveSource.read(valid,0,valid.size)}catch(expected:IOException){closedRejected=true}
  check(closedRejected && valid.all{it==0.toByte()});liveSource.close();live.close()
  println("PASS sessionClose actualReaderKeyWiped=true actual1MiBCacheWiped=true registryEmpty=true laterReadRejectedAndWiped=true idempotentClose=true")
  RandomAccessFile(stored.file,"rw").use{it.seek(it.length()-1);val b=it.read();it.seek(it.length()-1);it.write(b xor 1)}
  val tamper=VaultVideoSession(stored,key){true};val ts=tamper.sourceFactory.createDataSource();ts.open(DataSpec(Uri.parse("memory://synthetic/video.mp4"),1024L*1024-8))
  val target=ByteArray(32){42};var tamperRejected=false;try{ts.read(target,0,target.size)}catch(expected:IOException){tamperRejected=true}
  check(tamperRejected && target.all{it==0.toByte()});tamper.close();ts.close()
  println("PASS genuineAEADTamper crossingChunkReadRejected=true requestedOutputWiped=true")
 }finally {key.fill(0);plain.fill(0);root.deleteRecursively()}
}
