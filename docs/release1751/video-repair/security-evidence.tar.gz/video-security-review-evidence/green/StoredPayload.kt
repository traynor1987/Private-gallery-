package uk.co.traynor.privategallery.core.vault
import java.io.File
data class StoredPayload(
    val id: String,
    val file: File,
    val plaintextSize: Long,
    val plaintextSha256: ByteArray,
    val nonce: ByteArray,
)
