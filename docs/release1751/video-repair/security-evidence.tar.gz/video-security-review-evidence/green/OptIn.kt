package androidx.annotation
@Target(AnnotationTarget.FILE,AnnotationTarget.CLASS,AnnotationTarget.FUNCTION) annotation class OptIn(val markerClass:Array<kotlin.reflect.KClass<*>>)
